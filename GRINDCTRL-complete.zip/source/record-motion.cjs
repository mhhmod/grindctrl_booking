// Deterministic video export of the shared diagrams; no real call or vendor system.
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process'),{once}=require('node:events');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'/workspace/grindctrl_booking/apps/web-next/node_modules/playwright');
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{
 const page=await browser.newPage({viewport:{width:1440,height:1100}});await page.setContent(fs.readFileSync(path.join(__dirname,'index.html'),'utf8'));await page.evaluate(()=>document.fonts.ready);await page.addStyleTag({content:'.canvas{border:0;border-radius:0;width:1280px;height:720px}'});
 const fps=20;
 for(const lang of ['en','ar']){
  await page.evaluate(l=>{setLocale(l);pause();},lang);
  const out=path.join(__dirname,'..',`grindctrl-executive-walkthrough-${lang}.mp4`);
  const encoder=spawn('ffmpeg',['-y','-loglevel','error','-f','image2pipe','-vcodec','png','-framerate',String(fps),'-i','pipe:0','-an','-vf','scale=1280:720','-c:v','libx264','-pix_fmt','yuv420p','-crf','19','-preset','fast','-movflags','+faststart',out],{stdio:['pipe','ignore','pipe']});
  let log='';encoder.stderr.on('data',b=>log+=b.toString());
  const completed=new Promise((resolve,reject)=>{encoder.once('error',reject);encoder.once('close',code=>code===0?resolve():reject(new Error(log)));});
  for(const slide of [2,4,6]){
   await page.evaluate(i=>{go(i);pause();setMotion(0);},slide);
   const ms=await page.evaluate(()=>duration());
   for(let frame=0;frame<Math.ceil((ms+500)*fps/1000);frame++){
    await page.evaluate(t=>setMotion(t),Math.min(ms,frame*1000/fps));
    const png=await page.locator('.scene:not([hidden]) .canvas').screenshot({type:'png',animations:'disabled'});
    if(!encoder.stdin.write(png))await once(encoder.stdin,'drain');
   }
  }
  encoder.stdin.end();await completed;console.log(lang+': animated workflow video exported (seven-event flow + employee workspace + business value; 21 seconds; 1280×720).');
 }
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
