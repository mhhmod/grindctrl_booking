"""Nine-slide executive proposal; one shared bilingual layout for editable slides and motion."""
from pathlib import Path
import json
ROOT=Path(__file__).parent
basis=json.loads((ROOT/'basis.json').read_text())
B=lambda en,ar:dict(en=en,ar=ar)
C=dict(bg='#f4f1eb',paper='#fcfaf6',ink='#23201d',muted='#69635c',line='#d5cfc6',accent='#ba4c24',green='#526750',soft='#e9e4dc',darkline='#675e55',white='#fcfaf6',darkcard='#302b26',sage='#e4e9df')
slides=[]
def add(s,kind,step=None,**attrs):
 e=dict(type=kind,step=step,**attrs);s['elements'].append(e);return e
def txt(s,x,y,w,h,en,ar=None,size=36,color=None,bold=False,align='start',ltr=False,step=None,role='main'):
 return add(s,'text',step,x=x,y=y,w=w,h=h,text=B(en,ar if ar is not None else en),size=size,color=color or (C['white'] if s['dark'] else C['ink']),bold=bold,align=align,ltr=ltr,role=role)
def rect(s,x,y,w,h,fill=None,line=None,radius=16,step=None):
 return add(s,'rect',step,x=x,y=y,w=w,h=h,fill=fill or C['paper'],line=line or C['line'],radius=radius)
def circle(s,x,y,d,fill=None,line=None,step=None):
 return add(s,'ellipse',step,x=x,y=y,w=d,h=d,fill=fill or C['soft'],line=line or fill or C['soft'])
def image(s,key,x,y,w,h,step=None):return add(s,'image',step,key=key,x=x,y=y,w=w,h=h)
def edge(s,x,y,x2,y2,step=None,color=None,width=5,arrow=True):return add(s,'line',step,x=x,y=y,x2=x2,y2=y2,color=color or C['accent'],width=width,arrow=arrow)
def badge(s,x,y,key,step=None,d=78,dark=False):
 circle(s,x,y,d,fill=C['paper'] if dark else C['soft'],step=step);image(s,key,x+15,y+15,d-30,d-30,step)
def mobile(s,key,en,ar,body,bodyar,step=0):s['mobile'].append(dict(key=key,title=B(en,ar),body=B(body,bodyar),step=step))
common=[B('This is a proposed first collaboration. GRINDCTRL has no existing Concrete/Centro relationship and has not delivered this integration. All contact, phone and ticket examples are fictional. The UI is an independent mock-up, not an official vendor screenshot.','ده مقترح لأول تعاون. مفيش علاقة حالية بين GRINDCTRL وكونكريت أو Centro، والربط لم يُنفَّذ. أسماء العملاء والأرقام والتذاكر أمثلة خيالية، والواجهة تصميم توضيحي وليست شاشة رسمية للأنظمة.'),B('The animation demonstrates the proposed sequence. Its timing is presentation pacing, not measured lookup latency. This deck and browser preview have no vendor connector, backend or live model.','الحركة تشرح ترتيب التجربة المقترحة. توقيتها خاص بالعرض، وليس قياسًا لسرعة البحث. العرض والمعاينة لا يشغّلان ربطًا بالأنظمة أو backend أو نموذج AI حي.')]
def slide(section,title,lead,indices,steps,dark=False,headline=64):
 notes=[]
 for n in indices:notes+=basis['slides'][n]['notes']
 s=dict(index=len(slides),section=section,title=title,lead=lead,dark=dark,elements=[],mobile=[],notes=notes+common,motion=dict(steps=steps,interval=1250,fade=550));slides.append(s)
 txt(s,48,28,900,28,section['en'],section['ar'],size=20,color=C['line'] if dark else C['muted'],bold=True,role='navigation')
 image(s,'brand-white' if dark else 'brand',1041,23,52,35)
 txt(s,1104,28,128,29,'GRINDCTRL',size=19,bold=True,ltr=True,role='navigation')
 txt(s,48,86,1184,164,title['en'],title['ar'],size=headline,bold=True,role='title')
 txt(s,48,254,1184,48,lead['en'],lead['ar'],size=32,color=C['line'] if dark else C['muted'])
 edge(s,48,665,1232,665,arrow=False,width=1,color=C['darkline'] if dark else C['line'])
 txt(s,48,682,1080,22,'PROPOSED COLLABORATION · ILLUSTRATIVE RECORDS','تعاون مقترح · سجلات توضيحية',size=15,color=C['line'] if dark else C['muted'],role='footnote')
 txt(s,1145,682,87,22,f'{len(slides):02d} / 09',size=15,align='end',ltr=True,color=C['line'] if dark else C['muted'],role='navigation')
 return s

# 1 — Cover: the value is visible before the sales narrative starts.
s=slide(B('CONCRETE · CUSTOMER SERVICE PROPOSAL','كونكريت · مقترح لخدمة العملاء'),B('Smarter customer calls\nfor Concrete.','مكالمات أذكى\nلعملاء كونكريت.'),B('Zoho Desk history, visible with the Genesys call.','تذاكر Zoho Desk تظهر مع مكالمة Genesys.'),[0],3,True,66)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('genesys-white','The call','المكالمة','Arrives in Genesys','توصل في Genesys'),
 ('zoho','The history','تاريخ العميل','From Zoho Desk','من Zoho Desk'),
 ('icon-actor','The conversation','المحادثة','Starts with context','تبدأ بمعلومات العميل')]):
 x=48+i*418
 rect(s,x,327,348,286,fill=C['darkcard'],line=C['darkline'],step=i)
 if key=='zoho':rect(s,x+27,350,154,68,fill=C['paper'],line=C['paper'],radius=10,step=i)
 if key=='icon-actor':badge(s,x+27,343,key,i,d=78,dark=True)
 else:image(s,key,x+27,360,220 if key=='genesys-white' else 139,46,i)
 txt(s,x+27,454,294,97,en,ar,size=38,bold=True,step=i)
 txt(s,x+27,558,294,43,body,bodyar,size=30,color=C['line'],step=i)
 if i<2:edge(s,x+360,465,x+399,465,i+1)
 mobile(s,key.replace('-white',''),en,ar,body,bodyar,i)

# 2 — Current friction: existing data, manual retrieval.
s=slide(B('01 · THE CURRENT PROBLEM','٠١ · المشكلة الحالية'),B('The information exists.\nThe employee has to find it.','المعلومات موجودة.\nبس الموظف لازم يبحث عنها.'),B('Manual phone-number search already finds the tickets.','البحث اليدوي برقم التليفون بيوصل للتذاكر بالفعل.'),[0,1],4)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('genesys','Receive\nthe call','استقبال\nالمكالمة','History hidden','بدون ظهور التذاكر'),
 ('icon-copy','Use the\nnumber','استخدام\nالرقم','Manual step','خطوة يدوية'),
 ('icon-search','Search\nZoho Desk','البحث في\nZoho Desk','Manual step','خطوة يدوية'),
 ('zoho','Read the\nhistory','قراءة\nالتذاكر','Existing records','سجلات موجودة')]):
 x=48+i*306
 rect(s,x,328,266,282,line=C['accent'] if i in (1,2) else C['line'],step=i)
 if key.startswith('icon'):badge(s,x+23,347,key,i,d=78)
 else:image(s,key,x+23,365,199 if key=='genesys' else 130,45,i)
 txt(s,x+23,444,220,97,en,ar,size=36,bold=True,step=i)
 txt(s,x+23,555,220,43,body,bodyar,size=29,color=C['muted'],step=i)
 if i<3:edge(s,x+275,477,x+296,477,i+1)
 mobile(s,key,en.replace('\n',' '),ar.replace('\n',' '),body,bodyar,i)
txt(s,48,622,1184,38,'The conversation starts with a search.','المحادثة بتبدأ بخطوة بحث.',size=31,color=C['accent'],bold=True)

# 3 — The complete causal animation: seven events, one understandable outcome.
s=slide(B('02 · THE PROPOSED EXPERIENCE','٠٢ · التجربة المقترحة'),B('Call arrives.\nContext appears alongside it.','المكالمة توصل.\nومعلومات العميل تظهر معاها.'),B('A caller-number lookup connects the two experiences.','البحث برقم المتصل يوصل المكالمة بتاريخ التذاكر.'),[0,2,3,4],7)
s['motion']['labels']=[B('Call arrives','المكالمة توصل'),B('Caller number','رقم المتصل'),B('Automatic search','بحث تلقائي'),B('History retrieved','جلب التذاكر'),B('Context on screen','معلومات العميل تظهر'),B('Conversation continues','المحادثة مستمرة'),B('Less manual searching','بحث يدوي أقل')]
rect(s,48,318,280,220,fill=C['ink'],line=C['ink'],step=0)
image(s,'genesys-white',72,340,216,49,0)
badge(s,72,406,'icon-call',0,d=70,dark=True)
txt(s,160,418,143,48,'Call in','مكالمة',size=32,color=C['white'],bold=True,step=0)
txt(s,72,483,228,43,'+20 ••• 410',size=33,color=C['white'],ltr=True,step=1)
edge(s,342,431,373,431,2)
rect(s,392,318,215,220,fill=C['soft'],line=C['soft'],step=2)
image(s,'zoho',418,337,137,47,2)
txt(s,415,409,172,78,'Auto\nsearch','بحث\nتلقائي',size=33,bold=True,step=2)
image(s,'icon-case',419,492,29,29,3)
txt(s,458,492,132,40,'History','التذاكر',size=29,color=C['green'],bold=True,step=3)
edge(s,621,431,652,431,4)
rect(s,672,318,560,220,step=4)
badge(s,696,339,'icon-actor',4,d=67)
txt(s,785,350,419,46,'Contact A','العميل A',size=37,bold=True,step=4)
rect(s,696,422,512,92,fill=C['soft'],line=C['soft'],radius=10,step=4)
txt(s,717,433,471,45,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=32,bold=True,step=4)
txt(s,717,477,471,39,'Branch review pending','بانتظار مراجعة الفرع',size=30,color=C['accent'],step=4)
rect(s,672,550,560,48,fill=C['ink'],line=C['ink'],radius=9,step=5)
txt(s,689,557,526,38,'“I can see your earlier ticket.”','«شايف التذكرة السابقة لحضرتك.»',size=29,color=C['white'],align='center',step=5)
rect(s,48,613,1184,44,fill=C['sage'],line=C['sage'],radius=8,step=6)
txt(s,66,616,1148,41,'Less searching. A more informed conversation.','بحث أقل. ومحادثة بمعلومات أوضح.',size=30,color=C['green'],bold=True,align='center',step=6)
for key,en,ar,body,bodyar,step in [
 ('genesys','The call arrives','المكالمة توصل','Assigned to the employee','وصلت للموظف',0),
 ('icon-call','The number is available','رقم المتصل ظاهر','Used to find a candidate record','للبحث عن سجل محتمل للعميل',1),
 ('zoho','Automatic Desk search','بحث تلقائي في Desk','No manual number search','بدون بحث يدوي بالرقم',2),
 ('icon-case','Ticket history retrieved','جلب التذاكر','Existing Desk records','سجلات Desk الموجودة',3),
 ('icon-actor','Context appears','معلومات العميل تظهر','Contact + ticket + latest note','العميل والتذكرة وآخر ملاحظة',4),
 ('icon-file','Continue informed','محادثة بمعلومات أوضح','“I can see your earlier ticket.”','«شايف التذكرة السابقة لحضرتك.»',5),
 ('icon-check','Less searching','بحث أقل','Better continuity in the conversation','استمرارية أفضل في المحادثة',6)]:mobile(s,key,en,ar,body,bodyar,step)

# 4 — Simple system roles; implementation choice stays honest in notes.
s=slide(B('03 · HOW IT WORKS','٠٣ · إزاي الربط يشتغل'),B('Make the existing systems\nwork together.','نخلي الأنظمة الموجودة\nتشتغل مع بعض.'),B('Bring Desk records into the employee’s call experience.','نوصل سجلات Desk لشاشة الموظف وقت المكالمة.'),[3,5],4)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('genesys','Call event','وصول المكالمة','Caller number','رقم المتصل'),
 ('brand','GRINDCTRL','GRINDCTRL','Caller context','ربط المعلومات'),
 ('zoho','Zoho Desk','Zoho Desk','Existing tickets','التذاكر الموجودة'),
 ('icon-actor','Employee','الموظف','Call + history','التذاكر مع المكالمة')]):
 x=48+i*306;rect(s,x,325,266,281,step=i)
 if key=='icon-actor':badge(s,x+23,347,key,i,d=78)
 elif key=='brand':image(s,key,x+23,348,95,68,i)
 else:image(s,key,x+23,357,204 if key=='genesys' else 129,48,i)
 txt(s,x+23,452,220,82,en,ar,size=35,bold=True,ltr=(key=='brand'),step=i)
 txt(s,x+23,551,220,47,body,bodyar,size=29,color=C['muted'],step=i)
 if i<3:edge(s,x+275,475,x+296,475,i+1)
 mobile(s,key,en,ar,body,bodyar,i)
txt(s,48,619,1184,42,'Start with the pop-up already listed in the contract.','نبدأ بالـpop-up المذكور بالفعل في العقد.',size=31,color=C['accent'],bold=True)

# 5 — Practical employee workspace: records, not invented AI output.
s=slide(B('04 · THE EMPLOYEE EXPERIENCE','٠٤ · تجربة الموظف'),B('See the history.\nPick up from the last update.','يشوف التذاكر.\nويكمل من آخر تحديث.'),B('Customer details. Previous tickets. Latest recorded note.','بيانات العميل. التذاكر السابقة. آخر ملاحظة مسجلة.'),[2,4],5)
rect(s,48,316,1184,313,radius=18)
rect(s,48,316,283,313,fill=C['ink'],line=C['ink'],radius=18,step=0)
image(s,'genesys-white',70,340,227,50,0)
badge(s,70,411,'icon-call',0,d=68,dark=True)
txt(s,154,425,152,45,'On call','في مكالمة',size=31,color=C['white'],step=0)
txt(s,70,496,237,49,'Contact A','العميل A',size=38,color=C['white'],bold=True,step=1)
txt(s,70,556,237,44,'+20 ••• 410',size=32,color=C['line'],ltr=True,step=1)
image(s,'zoho',357,337,139,49,2)
txt(s,521,347,190,47,'Desk history','تذاكر Desk',size=30,bold=True,step=2)
txt(s,357,408,360,42,'2 open · 1 closed','٢ مفتوحة · ١ مغلقة',size=31,color=C['muted'],step=2)
for y,en,ar in [(465,'T101 · Exchange','T101 · استبدال'),(543,'T098 · Product','T098 · منتج')]:
 rect(s,357,y,366,61,fill=C['soft'],line=C['soft'],radius=10,step=2)
 txt(s,374,y+12,332,46,en,ar,size=31,bold=True,step=2)
edge(s,748,342,748,604,color=C['line'],width=1,arrow=False)
txt(s,780,344,418,43,'LATEST RECORDED NOTE','آخر ملاحظة مسجلة',size=28,color=C['muted'],bold=True,step=3)
txt(s,780,414,418,95,'Branch review\nis still pending.','مراجعة الفرع\nلسه مطلوبة.',size=39,bold=True,step=3)
rect(s,780,548,425,56,fill=C['sage'],line=C['sage'],radius=10,step=4)
txt(s,795,559,395,43,'Continue from this update','نكمل من التحديث ده',size=30,color=C['green'],bold=True,align='center',step=4)
mobile(s,'genesys','Assigned call','المكالمة وصلت','Genesys call remains active','المكالمة مستمرة في Genesys',0)
mobile(s,'icon-actor','Contact A','العميل A','Caller candidate, not verified identity','سجل محتمل، وليس تحققًا من الهوية',1)
mobile(s,'zoho','2 open · 1 closed','٢ مفتوحة · ١ مغلقة','Existing Desk ticket history','تذاكر Desk الموجودة',2)
mobile(s,'icon-file','Latest recorded note','آخر ملاحظة مسجلة','Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',3)
mobile(s,'icon-check','Pick up from the last update','نكمل من آخر تحديث','No new promise or ticket status invented','بدون اختلاق وعود أو تغيير حالة التذكرة',4)

# 6 — The same call and data, a different retrieval experience.
s=slide(B('05 · BEFORE / AFTER','٠٥ · قبل وبعد'),B('Same caller. Same tickets.\nFewer manual steps.','نفس المتصل. نفس التذاكر.\nخطوات يدوية أقل.'),B('The change is in how the employee gets the information.','الفرق في إزاي الموظف يوصل للمعلومات.'),[1,2],4)
for j,(x,label,labelar) in enumerate([(48,'BEFORE','قبل'),(672,'PROPOSED AFTER','بعد الربط المقترح')]):
 rect(s,x,316,560,295,fill=C['paper'] if j==0 else C['sage'],line=C['line'] if j==0 else C['green'])
 txt(s,x+24,332,512,43,label,labelar,size=31,color=C['muted'] if j==0 else C['green'],bold=True)
 rows=[('icon-copy','Use the number','استخدام الرقم'),('icon-search','Search in Desk','بحث في Desk'),('icon-file','Find the last update','الوصول لآخر تحديث')] if j==0 else [('icon-case','History opens with the call','التذاكر تظهر مع المكالمة'),('icon-file','Read the last update','قراءة آخر تحديث'),('icon-actor','Continue with context','المتابعة بمعلومات أوضح')]
 for i,(key,en,ar) in enumerate(rows):
  y=391+i*69;image(s,key,x+24,y,42,42,i);txt(s,x+86,y+2,450,51,en,ar,size=32,bold=(j==1),step=i)
  mobile(s,key,label+': '+en,labelar+': '+ar,'Same existing records','نفس السجلات الموجودة',i)
txt(s,48,623,1184,39,'From finding the information to using it.','من البحث عن المعلومة لاستخدامها.',size=31,color=C['accent'],bold=True,step=3)

# 7 — Clear qualitative value; no invented numeric return.
s=slide(B('06 · VALUE FOR CONCRETE','٠٦ · القيمة لكونكريت'),B('Less searching.\nMore attention to the customer.','بحث أقل.\nوتركيز أكبر مع العميل.'),B('A practical improvement to the everyday call workflow.','تحسين عملي في شغل المكالمات اليومي.'),[1,5],3)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('icon-clock','Employee\nefficiency','كفاءة\nالموظف','Fewer manual steps','خطوات يدوية أقل'),
 ('icon-file','Follow-up\ncontinuity','استمرارية\nالمتابعة','Use the latest note','استخدام آخر ملاحظة'),
 ('icon-actor','Informed\nconversations','محادثات\nبمعلومات أوضح','Less starting over','تكرار أقل للشرح')]):
 x=48+i*418;rect(s,x,321,348,278,step=i);badge(s,x+26,343,key,i,d=78)
 txt(s,x+26,442,296,92,en,ar,size=37,bold=True,step=i)
 txt(s,x+26,551,296,44,body,bodyar,size=30,color=C['muted'],step=i)
 mobile(s,key,en.replace('\n',' '),ar.replace('\n',' '),body,bodyar,i)
txt(s,48,620,1184,39,'Expected benefits · validate in an agreed pilot.','فوائد متوقعة · نقيسها في تجربة نتفق عليها.',size=30,color=C['muted'])

# 8 — Future AI optional, after the basic experience works.
s=slide(B('07 · OPTIONAL NEXT LAYER','٠٧ · خطوة مستقبلية اختيارية'),B('Once context works,\nAI can add another layer.','بعد ما الربط يشتغل،\nنقدر نضيف طبقة AI.'),B('Future possibilities, separate from the first delivery.','إمكانيات مستقبلية، منفصلة عن التسليم الأول.'),[5],4)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('icon-file','Ticket summaries','ملخصات التذاكر','With links to source notes','بمراجع للملاحظات الأصلية'),
 ('icon-quality','Recurring issues','مشكلات متكررة','Patterns across tickets','أنماط عبر التذاكر'),
 ('icon-actor','Management view','لوحة للإدارة','See follow-up patterns','متابعة أنماط الخدمة'),
 ('icon-clock','Follow-up support','مساعدة في المتابعة','Prompts for employee review','اقتراحات يراجعها الموظف')]):
 x=48+(i%2)*624;y=315+(i//2)*165
 rect(s,x,y,560,145,step=i);badge(s,x+20,y+30,key,i,d=75)
 txt(s,x+115,y+18,425,52,en,ar,size=35,bold=True,step=i)
 txt(s,x+115,y+85,425,45,body,bodyar,size=29,color=C['muted'],step=i)
 mobile(s,key,en,ar,body,bodyar,i)

# 9 — A real first offer, with a responsible implementation route.
s=slide(B('08 · A FOCUSED FIRST COLLABORATION','٠٨ · بداية تعاون محددة'),B('Let the call begin\nwith customer context.','نخلي المكالمة تبدأ\nبمعلومات العميل.'),B('A clear operational improvement for Concrete.','تحسين واضح في تجربة موظف وعميل كونكريت.'),[4,5],3,True)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('icon-file','Check the\nexisting pop-up','نفحص\nالـpop-up الموجود','Check the gap','نحدد المشكلة الفعلية'),
 ('icon-link','Complete\nthe connection','نكمّل\nالربط','Supported options','بالطرق المدعومة'),
 ('icon-check','Test\nagreed calls','نختبر\nمكالمات متفق عليها','Context + fallback','نتأكد من النتائج والبدائل')]):
 x=48+i*418;rect(s,x,320,348,289,fill=C['darkcard'],line=C['darkline'],step=i)
 badge(s,x+26,341,key,i,d=78,dark=True)
 txt(s,x+26,440,296,94,en,ar,size=36,bold=True,step=i)
 txt(s,x+26,552,296,49,body,bodyar,size=29,color=C['line'],step=i)
 if i<2:edge(s,x+360,466,x+399,466,i+1)
 mobile(s,key,en.replace('\n',' '),ar.replace('\n',' '),body,bodyar,i)
txt(s,48,621,1184,39,'Customer context at the start of the conversation.','الموظف يبدأ بمعلومات العميل وتذاكره.',size=30,color=C['white'],bold=True)
# Keep visible business language short; the notes retain evidence, caveats and acceptance detail.
assert len(slides)==9
story=dict(title=B('GRINDCTRL · Smarter Customer Calls for Concrete','GRINDCTRL · مكالمات أذكى لعملاء كونكريت'),colors=C,slides=slides,sources=basis['sources'],fixtures=basis['fixtures'])
(ROOT/'story.json').write_text(json.dumps(story,ensure_ascii=False,indent=2))
print('9 executive slides generated; seven causal events on slide 3; bilingual editable diagrams.')
