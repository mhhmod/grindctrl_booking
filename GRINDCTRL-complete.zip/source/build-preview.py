from pathlib import Path
import json,base64
root=Path(__file__).parent
def safe(v):return json.dumps(v,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
assets={p.stem:'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode() for p in sorted((root/'assets').glob('*.png'))}
page=(root/'preview.html').read_text()
values={
 '__FONT_EN__':base64.b64encode((root/'assets/manrope.woff2').read_bytes()).decode(),
 '__FONT_AR__':base64.b64encode((root/'assets/arabic.woff2').read_bytes()).decode(),
 '__NOTICES__':(root/'THIRD-PARTY-NOTICES.md').read_text().replace('--','—'),
 '__STORY__':safe(json.loads((root/'story.json').read_text())),
 '__ASSETS__':safe(assets),'__CLIENT__':(root/'client.js').read_text()
}
for k,v in values.items():page=page.replace(k,v)
(root/'index.html').write_text(page)
(root.parent/'grindctrl-executive-proposal.html').write_text(page)
print('Bilingual motion preview built; pause/replay/step/show-all; offline and reduced-motion support.')
