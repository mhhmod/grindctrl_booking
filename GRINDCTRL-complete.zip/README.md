# GRINDCTRL — Smarter Customer Calls for Concrete

A nine-slide executive proposal based on the user's attached creative brief. English is the default, with a complete Arabic version and mirrored right-to-left diagrams. Native PowerPoint text, shapes, arrows and speaker notes remain editable.

## Review the proposal

- `grindctrl-executive-proposal-en.pptx` and `-ar.pptx`: open in PowerPoint and use **Slide Show / From Beginning**. Each slide reveals its workflow automatically; advance to the next slide when ready.
- `grindctrl-executive-proposal.html`: download and open in a modern browser. Works offline. Switch language, replay, pause, advance one event, or show the full diagram. Notes contain the factual basis and implementation qualifications. The desktop scene becomes readable cards on small screens.
- `grindctrl-executive-walkthrough-en.mp4` and `-ar.mp4`: a short silent demonstration of the seven-event flow, the employee workspace and the intended business value.
- `grindctrl-executive-proposal-en.pdf` and `-ar.pdf`: static, fully revealed slides for sharing or printing.

The HTML is a standalone file, not a hosted public URL. No website or original repository was changed.

## The story

1. Smarter customer calls for Concrete.
2. Existing history is found through manual phone-number search.
3. Call → number → automatic lookup → history → employee context → conversation → value.
4. The roles of Genesys, GRINDCTRL, Zoho Desk and the employee.
5. The proposed employee screen, with previous tickets and the latest recorded note.
6. Before and proposed after.
7. Expected employee, follow-up and customer benefits.
8. Future AI and management enhancements, clearly optional.
9. Check the existing pop-up, complete the supported connection, and test agreed calls.

## What is factual and what is proposed

The user reports that Zoho is used for ticketing, caller history does not automatically appear with the Genesys call, and manual phone-number search finds the tickets. This has not been independently tested. The November 2023 contract, PDF page 4, includes **“CRM URL pop up integration.”** It establishes contractual scope, not current operation or two-way synchronization.

GRINDCTRL has no existing Concrete/Centro relationship or completed implementation. This is a proposed first collaboration. The contact, masked phone number, tickets, statuses, employee reply and screen are fictional illustrations. No original private contract pages or financial terms are included in this package.

The initial improvement retrieves existing Desk records; AI is optional later. Start by inspecting the supported pop-up/configuration. Choose a supported native option or adapter only after confirming the actual gap, desktop, licensing and permissions. A phone match is a candidate association, not authentication. Shared numbers need employee choice; unknown numbers and lookup failures need clear fallbacks while the call continues. Read only records permitted to the employee.

There is no live vendor connector, backend, real call event or AI model in this presentation. No measured latency, savings, ROI, implementation duration, pricing or product validation is asserted. Animation duration is presentation pacing.

## Edit and rebuild

The `source/` directory contains:

- `story.py` / `story.json`: bilingual copy, native diagram coordinates, reveal steps and speaker notes.
- `basis.json`: previously established factual basis and illustrative fixtures.
- `build-pptx.py` / `timing.py`: editable 16:9 PowerPoint generation and native staggered entrance effects.
- `preview.html` / `client.js` / `build-preview.py`: offline bilingual SVG preview, semantic event labels, moving connectors and responsive layouts.
- `assets/`: vendor and GRINDCTRL marks, icons and fonts.
- `verify-export.cjs`: causal animation, controls, responsive layouts, clipping, offline behavior and PDF checks.
- `record-motion.cjs`: deterministic video export.
- `creative-brief.txt`: the user's supplied brief.
- `THIRD-PARTY-NOTICES.md`: source and license notices.

Run from `source/`, in this order:

```bash
python story.py
python prepare-fonts.py
python build-pptx.py
python build-preview.py
PLAYWRIGHT_MODULE=/absolute/path/to/playwright node verify-export.cjs
PLAYWRIGHT_MODULE=/absolute/path/to/playwright node record-motion.cjs
```

Requires Python with `python-pptx`, `Pillow`, `lxml`, `fontTools`, `brotli`; Node with Playwright; Chromium (`/usr/bin/chromium`); and FFmpeg. Font preparation writes a local Fontconfig configuration for native rendering. Assets contain the licensed Manrope Regular/Bold and IBM Plex Sans Arabic Medium fonts; install these when editing if exact typography is required.

## Validation

Both languages were reviewed as browser scenes and as rendered native PowerPoint slides. Browser checks cover all nine slides at widths 320, 390, 768, 1024, 1366 and 1440 pixels, with no horizontal overflow or clipped desktop text. Replay, pause, event stepping, semantic event labels, full reveal, keyboard navigation, reduced-motion behavior, notes and offline operation were checked.

Both PDFs have nine populated pages. Native slide text bounds and targets were checked. All 164 entrance effects in each deck survived a LibreOffice import/export round trip. Native previews were rendered with LibreOffice; playback in Microsoft PowerPoint, Google Slides and Keynote was not directly tested. The browser and video provide direct motion review. PDF copies are static.

## العربية

عرض جديد من ٩ شرائح يشرح تحسينًا محددًا: تظهر سجلات العميل وتذاكر Zoho Desk مع مكالمة Genesys بدل خطوة البحث اليدوي. العرض يقارن الوضع الحالي بالمقترح، ويعرض شاشة موظف توضيحية والقيمة المتوقعة، ثم إضافات AI المستقبلية الاختيارية.

للحركة افتح PowerPoint في وضع **Slide Show**، أو افتح ملف HTML في المتصفح بعد تنزيله، أو شغّل الفيديو. زر اللغة يبدّل بين العربية والإنجليزية، وأزرار المعاينة تتيح الإعادة والإيقاف والتقدم خطوة بخطوة.

ده مقترح لأول تعاون، ببيانات خيالية، والربط الحي مرحلة تنفيذ لاحقة. أول خطوة تنفيذية هي فحص الـpop-up المذكور في العقد والإعدادات الموجودة، وبعدها استكمال الربط المناسب واختباره بمكالمات متفق عليها.
