from pathlib import Path
from io import BytesIO
import json,zipfile
from PIL import Image
from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from timing import attach_timing

root=Path(__file__).parent
story=json.loads((root/'story.json').read_text())
EMU=9525
def unit(n):return round(n*EMU)
def color(s):return RGBColor.from_string(s.lstrip('#').upper())

for locale in ('en','ar'):
    p=Presentation();p.slide_width=unit(1280);p.slide_height=unit(720)
    p.core_properties.title=story['title'][locale]
    p.core_properties.subject='Reported caller-context gap: Genesys call assignment and Zoho Desk ticket lookup. Proposed workflow; fictional records.'
    p.core_properties.author='GRINDCTRL'
    for source in story['slides']:
        s=p.slides.add_slide(p.slide_layouts[6])
        targets=[]
        s.background.fill.solid();s.background.fill.fore_color.rgb=color(story['colors']['ink'] if source['dark'] else story['colors']['bg'])
        for e in source['elements']:
            if e['type']=='line':
                x1=1280-e['x'] if locale=='ar' else e['x'];x2=1280-e['x2'] if locale=='ar' else e['x2']
                shape=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,unit(x1),unit(e['y']),unit(x2),unit(e['y2']))
                shape.line.color.rgb=color(e['color']);shape.line.width=Pt(e['width']*.75)
                if e.get('arrow'):
                    line=shape._element.spPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ln')
                    arrow=OxmlElement('a:tailEnd');arrow.set('type','triangle');arrow.set('w','sm');arrow.set('len','sm');line.append(arrow)
                if e.get('step') is not None:targets.append((shape.shape_id,e['step']))
                continue
            x=1280-e['x']-e['w'] if locale=='ar' else e['x']
            if e['type'] in ('rect','ellipse'):
                shape=s.shapes.add_shape(MSO_SHAPE.OVAL if e['type']=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if e['radius'] else MSO_SHAPE.RECTANGLE,unit(x),unit(e['y']),unit(e['w']),unit(e['h']))
                if e.get('radius'):shape.adjustments[0]=min(.12,e['radius']/min(e['w'],e['h']))
                shape.fill.solid();shape.fill.fore_color.rgb=color(e['fill']);shape.line.color.rgb=color(e['line']);shape.line.width=Pt(.75)
            elif e['type']=='image':
                file=root/'assets'/f'{e["key"]}.png'
                iw,ih=Image.open(file).size;scale=min(e['w']/iw,e['h']/ih);w,h=iw*scale,ih*scale
                shape=s.shapes.add_picture(str(file),unit(x+(e['w']-w)/2),unit(e['y']+(e['h']-h)/2),unit(w),unit(h))
            elif e['type']=='text':
                shape=s.shapes.add_textbox(unit(x),unit(e['y']),unit(e['w']),unit(e['h']))
                frame=shape.text_frame;frame.clear();frame.word_wrap=True
                frame.margin_left=frame.margin_right=frame.margin_top=frame.margin_bottom=0
                frame.vertical_anchor=MSO_ANCHOR.TOP
                for i,line in enumerate(e['text'][locale].split('\n')):
                    para=frame.paragraphs[0] if i==0 else frame.add_paragraph()
                    alignment=e['align']
                    if alignment=='center':para.alignment=PP_ALIGN.CENTER
                    elif alignment=='end':para.alignment=PP_ALIGN.LEFT if locale=='ar' else PP_ALIGN.RIGHT
                    else:para.alignment=PP_ALIGN.RIGHT if locale=='ar' else PP_ALIGN.LEFT
                    para.space_before=para.space_after=Pt(0);para.line_spacing=Pt(e['size']*.75*1.12)
                    para._p.get_or_add_pPr().set('rtl','1' if locale=='ar' and not e['ltr'] else '0')
                    run=para.add_run();run.text=line;run.font.size=Pt(e['size']*.75)
                    # Latin IDs/numbers use Manrope; Arabic text uses the explicit CS face.
                    run.font.name='Manrope'
                    run.font.bold=e['bold'];run.font.color.rgb=color(e['color'])
                    run._r.get_or_add_rPr().set('lang','ar-EG' if locale=='ar' else 'en-US')
                    if locale=='ar':
                        script=OxmlElement('a:cs');script.set('typeface','IBM Plex Sans Arabic Medium');run._r.get_or_add_rPr().append(script)
            if e.get('step') is not None:targets.append((shape.shape_id,e['step']))
        # Suppress inherited theme shadows so the workflow stays crisp and flat.
        for sh in s.shapes:
            props=sh._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
            if props is not None:
                effect=props.find('{http://schemas.openxmlformats.org/drawingml/2006/main}effectLst')
                if effect is None:props.append(OxmlElement('a:effectLst'))
            style=sh._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}style')
            if style is not None:
                effect=style.find('{http://schemas.openxmlformats.org/drawingml/2006/main}effectRef')
                if effect is not None:effect.set('idx','0')
        attach_timing(s,targets,source['motion'])
        notes=[n[locale] for n in source['notes']]
        notes+=['SOURCES (PDF pages):']+[item['file']+' — '+', '.join(map(str,item['pages']))+' — '+item['supports'][locale] for item in story['sources']]
        notes+=['No existing Concrete/Centro relationship. All sample records are fictional. No live connector. Reported workflow has not been independently tested.']
        s.notes_slide.notes_text_frame.text='\n\n'.join(notes)
    dest=root.parent/f'grindctrl-light-proposal-{locale}.pptx';p.save(dest)
    # Verify native text and diagrams, speaker notes and shape bounds in the actual archive.
    reopened=Presentation(dest)
    assert len(reopened.slides)==len(story['slides'])
    for i,s in enumerate(reopened.slides):
        assert sum(1 for sh in s.shapes if sh.has_text_frame)>=7
        assert 'fiction' in s.notes_slide.notes_text_frame.text.lower() or 'خيال' in s.notes_slide.notes_text_frame.text
        for sh in s.shapes:
            assert sh.left>=0 and sh.top>=0 and sh.left+sh.width<=p.slide_width+unit(1) and sh.top+sh.height<=p.slide_height+unit(1),(locale,i,sh.left,sh.top)
    with zipfile.ZipFile(dest) as z:
        assert len([n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')])==len(story['slides'])
    print(locale, f"PowerPoint: {len(story['slides'])} light-theme slides with native staggered entrance animations; text/shapes/notes/targets/bounds verified.")
