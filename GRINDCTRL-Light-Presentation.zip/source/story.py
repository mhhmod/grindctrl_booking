"""GRINDCTRL light executive deck: product UI first, restrained type and native motion."""
from pathlib import Path
import json
ROOT=Path(__file__).parent
basis=json.loads((ROOT/'basis.json').read_text())
B=lambda en,ar:dict(en=en,ar=ar)
C=dict(bg='#fafaf7',paper='#ffffff',ink='#29302d',muted='#68716b',line='#e3e7e1',accent='#9f5836',green='#54745c',soft='#f3f5f1',sage='#eef4eb',warm='#f8f1e8',shadow='#eff1ec',white='#ffffff',darkline='#e3e7e1')
slides=[]
def add(s,kind,step=None,**attrs):
 e=dict(type=kind,step=step,**attrs);s['elements'].append(e);return e
def txt(s,x,y,w,h,en,ar=None,size=22,color=None,bold=False,align='start',ltr=False,step=None,role='main'):
 return add(s,'text',step,x=x,y=y,w=w,h=h,text=B(en,ar if ar is not None else en),size=size,color=color or C['ink'],bold=bold,align=align,ltr=ltr,role=role)
def rect(s,x,y,w,h,fill=None,line=None,radius=12,step=None):
 return add(s,'rect',step,x=x,y=y,w=w,h=h,fill=fill or C['paper'],line=line or C['line'],radius=radius)
def circle(s,x,y,d,fill=None,line=None,step=None):
 return add(s,'ellipse',step,x=x,y=y,w=d,h=d,fill=fill or C['soft'],line=line or fill or C['soft'])
def image(s,key,x,y,w,h,step=None):return add(s,'image',step,key=key,x=x,y=y,w=w,h=h)
def edge(s,x,y,x2,y2,step=None,color=None,width=2,arrow=True):return add(s,'line',step,x=x,y=y,x2=x2,y2=y2,color=color or C['accent'],width=width,arrow=arrow)
def divider(s,x,y,x2,y2,step=None):return edge(s,x,y,x2,y2,step,color=C['line'],width=1,arrow=False)
def icon(s,key,x,y,step=None,d=46,bg=None):
 circle(s,x,y,d,fill=bg or C['soft'],step=step);image(s,key,x+10,y+10,d-20,d-20,step)
def panel(s,x,y,w,h,step=None,shadow=False):
 if shadow:rect(s,x+1,y+5,w,h,fill=C['shadow'],line=C['shadow'],radius=16,step=step)
 return rect(s,x,y,w,h,radius=16,step=step)
def mobile(s,key,en,ar,body,bodyar,step=0):s['mobile'].append(dict(key=key,title=B(en,ar),body=B(body,bodyar),step=step))
common=[B('Proposed first collaboration. GRINDCTRL has no existing Concrete/Centro relationship or completed implementation. All contacts, masked phone numbers, tickets, notes, statuses and conversation examples are fictional. Screens are independent proposed workspace mock-ups, not official vendor screenshots.','مقترح لأول تعاون. مفيش علاقة حالية أو تنفيذ سابق لـGRINDCTRL مع كونكريت أو Centro. كل العملاء والأرقام والتذاكر والملاحظات والحالات والمحادثات أمثلة خيالية. الشاشات واجهات مقترحة مستقلة، وليست لقطات رسمية للأنظمة.'),B('Motion demonstrates event order, not measured system speed. This presentation has no live vendor connector, backend or AI model. Caller-number association suggests a contact; it is not authentication. Existing employee permissions and caller-verification procedures apply.','الحركة توضح ترتيب الأحداث، وليست قياسًا لسرعة الأنظمة. العرض لا يشغّل ربطًا حيًا أو backend أو نموذج AI. الرقم يشير لسجل محتمل للعميل ولا يثبت هويته. تُطبّق صلاحيات الموظف وإجراءات التحقق من المتصل.')]
def slide(section,title,lead,indices,steps,cover=False):
 notes=[]
 for i in indices:notes+=basis['slides'][i]['notes']
 s=dict(index=len(slides),section=section,title=title,lead=lead,dark=False,elements=[],mobile=[],notes=notes+common,motion=dict(steps=steps,interval=1250,fade=500));slides.append(s)
 image(s,'brand',60,29,43,32)
 txt(s,115,34,154,27,'GRINDCTRL',size=17,bold=True,ltr=True,role='navigation')
 txt(s,782,35,438,26,section['en'],section['ar'],size=14,color=C['muted'],align='end',role='navigation')
 if not cover:
  txt(s,60,94,1160,64,title['en'],title['ar'],size=42,bold=True,role='title')
  txt(s,60,166,1160,38,lead['en'],lead['ar'],size=21,color=C['muted'])
 divider(s,60,672,1220,672)
 txt(s,60,686,1000,23,'CONCRETE · PROPOSED COLLABORATION','كونكريت · تعاون مقترح',size=12,color=C['muted'],role='footnote')
 txt(s,1132,684,88,25,f'{len(slides):02d} / 09',size=14,color=C['muted'],ltr=True,align='end',role='navigation')
 return s

def avatar(s,x,y,step=None,d=48):
 circle(s,x,y,d,fill=C['sage'],step=step)
 txt(s,x,y+8,d,d-4,'A',size=23,color=C['green'],bold=True,align='center',ltr=True,step=step)
def state(s,x,y,w,en,ar,step=None):
 circle(s,x,y+7,7,fill=C['green'],step=step)
 txt(s,x+17,y,w-17,29,en,ar,size=17,color=C['green'],step=step)

def compact_workspace(s,x,y,w=566,h=443):
 panel(s,x,y,w,h,shadow=True)
 image(s,'genesys',x+26,y+22,136,33,0)
 state(s,x+w-165,y+28,142,'Incoming call','مكالمة واردة',0)
 divider(s,x,y+79,x+w,y+79)
 avatar(s,x+26,y+104,1)
 txt(s,x+88,y+105,w-135,40,'Contact A','العميل A',size=26,bold=True,step=1)
 txt(s,x+88,y+144,w-135,30,'+20 ••• 410',size=19,color=C['muted'],ltr=True,step=1)
 divider(s,x+26,y+200,x+w-26,y+200)
 image(s,'zoho',x+26,y+219,92,32,2)
 txt(s,x+135,y+222,w-162,32,'Ticket history','تاريخ التذاكر',size=20,bold=True,step=2)
 rect(s,x+26,y+270,w-52,73,fill=C['sage'],line=C['sage'],radius=9,step=2)
 txt(s,x+43,y+279,w-86,32,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=22,bold=True,step=2)
 txt(s,x+43,y+313,w-86,25,'Waiting on the branch','بانتظار الفرع',size=16,color=C['green'],step=2)
 txt(s,x+26,y+365,w-52,25,'LATEST NOTE','آخر ملاحظة',size=13,color=C['muted'],bold=True,step=3)
 txt(s,x+26,y+391,w-52,35,'Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',size=21,step=3)

# 1: editorial cover, with one polished product window.
s=slide(B('CUSTOMER SERVICE PROPOSAL','مقترح لخدمة العملاء'),B('Customer context,\nwith every call.','معلومات العميل،\nمع كل مكالمة.'),B('Zoho Desk history, ready with the Genesys call.','تذاكر Zoho Desk تظهر مع مكالمة Genesys.'),[0],4,True)
txt(s,60,166,493,34,'FOR CONCRETE','لكونكريت',size=16,color=C['accent'],bold=True)
txt(s,60,217,503,141,s['title']['en'],s['title']['ar'],size=50,bold=True,role='title')
txt(s,60,381,483,83,'Bring existing service history\ninto the employee’s call experience.','نوصل تاريخ الخدمة الموجود\nللموظف وقت المكالمة.',size=24,color=C['muted'])
image(s,'genesys',60,515,162,42)
edge(s,245,536,280,536,color=C['line'],width=2,arrow=False)
image(s,'zoho',306,514,106,43)
txt(s,60,585,503,32,'A focused first collaboration.','بداية تعاون محددة وواضحة.',size=19,color=C['muted'])
compact_workspace(s,654,150,566,453)
mobile(s,'genesys','A call arrives','المكالمة توصل','In the employee’s Genesys workspace','في شاشة الموظف على Genesys',0)
mobile(s,'icon-actor','The caller’s context','معلومات المتصل','Contact and phone-number match','سجل العميل ومطابقة الرقم',1)
mobile(s,'zoho','Existing Desk history','تذاكر Desk الموجودة','Open tickets and the latest recorded note','التذاكر المفتوحة وآخر ملاحظة مسجلة',2)
mobile(s,'icon-file','Start from the latest update','نبدأ من آخر تحديث','Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',3)

# 2: one coherent application frame, with the manual lookup clearly visible.
s=slide(B('01 · CURRENT WORKFLOW','٠١ · الوضع الحالي'),B('The history exists. Finding it takes a manual step.','التذاكر موجودة. الوصول لها بيحتاج بحث يدوي.'),B('The employee can already find previous tickets by searching the phone number.','الموظف يقدر يوصل للتذاكر السابقة بالبحث برقم التليفون.'),[0,1],4)
panel(s,60,238,1160,353,shadow=True)
txt(s,86,258,718,35,'The call and the service history','المكالمة وتاريخ الخدمة',size=19,bold=True)
txt(s,880,262,314,28,'REPORTED WORKFLOW','بحسب إفادة المستخدم',size=13,color=C['muted'],align='end')
divider(s,60,304,1220,304)
image(s,'genesys',86,327,145,34,0)
icon(s,'icon-call',86,399,0,d=49,bg=C['sage'])
txt(s,150,401,251,39,'Customer calling','العميل بيتصل',size=24,bold=True,step=0)
txt(s,86,472,316,40,'+20 ••• 410',size=28,ltr=True,step=1)
txt(s,86,528,316,29,'Call assigned to employee','المكالمة وصلت للموظف',size=17,color=C['muted'],step=0)
edge(s,421,470,479,470,2,width=2.5)
txt(s,411,510,99,27,'Manual','يدوي',size=15,color=C['accent'],align='center',step=2)
divider(s,510,328,510,563)
image(s,'zoho',540,325,98,36,0)
txt(s,659,332,510,31,'Desk · ticket history','Desk · تاريخ التذاكر',size=21,bold=True,step=0)
rect(s,540,391,652,54,fill=C['paper'],line=C['accent'],radius=8,step=2)
image(s,'icon-search',557,407,23,23,2)
txt(s,597,404,418,32,'Search: +20 ••• 410','بحث: +20 ••• 410',size=21,ltr=True,step=2)
rect(s,1092,399,91,38,fill=C['warm'],line=C['warm'],radius=6,step=2)
txt(s,1096,405,83,30,'Search','بحث',size=17,color=C['accent'],bold=True,align='center',step=2)
divider(s,540,470,1192,470,3)
image(s,'icon-case',540,494,29,29,3)
txt(s,589,489,588,34,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=23,bold=True,step=3)
txt(s,589,529,588,30,'Latest update: branch review pending','آخر تحديث: بانتظار مراجعة الفرع',size=18,color=C['muted'],step=3)
txt(s,60,617,1160,38,'The employee searches before they can pick up the previous conversation.','الموظف بيبحث الأول عشان يقدر يكمل المتابعة السابقة.',size=21,color=C['muted'])
for key,en,ar,body,bodyar,i in [('genesys','Receive the call','استقبال المكالمة','Previous tickets do not pop up automatically','التذاكر السابقة لا تظهر تلقائيًا',0),('icon-call','Use the caller’s number','استخدام رقم المتصل','The phone-number search already works','البحث بالرقم شغّال بالفعل',1),('icon-search','Search in Zoho Desk','البحث في Zoho Desk','A manual employee step','خطوة بيعملها الموظف بنفسه',2),('zoho','Read the latest update','قراءة آخر تحديث','Continue after finding the ticket','نكمل بعد الوصول للتذكرة',3)]:mobile(s,key,en,ar,body,bodyar,i)

# 3: six stages; the same workspace gains contextual records.
s=slide(B('02 · PROPOSED EXPERIENCE','٠٢ · التجربة المقترحة'),B('The call arrives. The context comes with it.','المكالمة توصل. ومعلومات العميل تظهر معاها.'),B('The caller’s number triggers the lookup in Zoho Desk.','رقم المتصل يبدأ البحث تلقائيًا في Zoho Desk.'),[0,2,3,4],6)
s['motion']['labels']=[B('Call arrives','المكالمة توصل'),B('Caller number','رقم المتصل'),B('Automatic lookup','بحث تلقائي'),B('Ticket history found','الوصول للتذاكر'),B('Employee sees context','الموظف يشوف المعلومات'),B('Conversation continues','المحادثة مستمرة')]
panel(s,60,237,1160,350,shadow=True)
image(s,'genesys',86,258,145,36,0)
state(s,263,266,530,'Call assigned to employee','المكالمة وصلت للموظف',0)
txt(s,914,268,282,27,'PROPOSED WORKSPACE','شاشة موظف مقترحة',size=13,color=C['muted'],align='end')
divider(s,60,316,1220,316)
icon(s,'icon-call',88,366,0,d=56,bg=C['sage'])
txt(s,88,447,290,42,'+20 ••• 410',size=29,ltr=True,step=1)
txt(s,88,501,290,31,'Caller number available','رقم المتصل متاح',size=18,color=C['muted'],step=1)
edge(s,390,445,485,445,2,color=C['green'],width=2.5)
txt(s,382,393,112,28,'Auto lookup','بحث تلقائي',size=16,color=C['green'],bold=True,align='center',step=2)
divider(s,510,339,510,559)
image(s,'zoho',540,341,94,34,3)
txt(s,654,344,533,31,'Desk records found','تم الوصول لسجلات Desk',size=21,bold=True,step=3)
rect(s,540,399,305,133,fill=C['soft'],line=C['soft'],radius=10,step=3)
txt(s,558,415,269,26,'T101','T101',size=16,color=C['muted'],bold=True,ltr=True,step=3)
txt(s,558,448,269,35,'Exchange follow-up','متابعة استبدال',size=22,bold=True,step=3)
txt(s,558,491,269,30,'Waiting on branch','بانتظار الفرع',size=18,color=C['accent'],step=3)
avatar(s,875,403,4,d=40)
txt(s,931,406,252,33,'Contact A','العميل A',size=23,bold=True,step=4)
txt(s,875,459,313,27,'LATEST RECORDED NOTE','آخر ملاحظة مسجلة',size=13,color=C['muted'],bold=True,step=4)
txt(s,875,488,313,70,'Branch review is\nstill pending.','مراجعة الفرع\nلسه مطلوبة.',size=21,step=4)
image(s,'icon-actor',76,615,29,29,5)
txt(s,122,610,1090,43,'“I can see your earlier ticket. The branch review is still pending.”','«شايف التذكرة السابقة لحضرتك. مراجعة الفرع لسه مطلوبة.»',size=22,color=C['green'],step=5)
for i,(key,en,ar,body,bodyar) in enumerate([('genesys','Call arrives','المكالمة توصل','Assigned to the employee','وصلت للموظف'),('icon-call','Caller number is available','رقم المتصل ظاهر','Used to find a candidate contact','للبحث عن سجل محتمل للعميل'),('icon-search','Lookup starts automatically','البحث يبدأ تلقائيًا','Search existing Desk records','بحث في سجلات Desk الموجودة'),('zoho','Ticket history is found','تم الوصول للتذاكر','T101 · Exchange follow-up','T101 · متابعة استبدال'),('icon-file','Context appears','معلومات العميل تظهر','Contact, ticket and latest note','العميل والتذكرة وآخر ملاحظة'),('icon-actor','Continue with context','نكمل بمعلومات أوضح','“The branch review is still pending.”','«مراجعة الفرع لسه مطلوبة.»')]):mobile(s,key,en,ar,body,bodyar,i)

# 4: one calm architecture canvas, without four heavy boxed cards.
s=slide(B('03 · HOW IT WORKS','٠٣ · إزاي الربط يشتغل'),B('Connect the call to the service history.','نوصل المكالمة بتاريخ الخدمة.'),B('Each system keeps its role. GRINDCTRL completes the workflow.','كل نظام بيكمل دوره. وGRINDCTRL يكمّل الربط بينهم.'),[3,5],4)
panel(s,60,241,1160,363,shadow=True)
centers=[200,490,780,1070]
for i,(cx,key,en,ar,body,bodyar) in enumerate(zip(centers,['genesys','brand','zoho','icon-actor'],['Genesys','GRINDCTRL','Zoho Desk','Employee view'],['Genesys','GRINDCTRL','Zoho Desk','شاشة الموظف'],['Caller number','Connect the context','Existing tickets','History with the call'],['رقم المتصل','ربط معلومات العميل','التذاكر الموجودة','التذاكر مع المكالمة'])):
 if key=='genesys':image(s,key,cx-86,315,172,42,i)
 elif key=='brand':image(s,key,cx-37,301,74,65,i)
 elif key=='zoho':image(s,key,cx-59,310,118,47,i)
 else:icon(s,key,cx-29,302,i,d=58,bg=C['sage'])
 txt(s,cx-120,393,240,38,en,ar,size=23,bold=True,align='center',ltr=key in ('genesys','brand','zoho'),step=i)
 txt(s,cx-131,441,262,38,body,bodyar,size=19,color=C['muted'],align='center',step=i)
 if i<3:edge(s,cx+112,338,cx+176,338,i+1,color=C['green'],width=2)
 mobile(s,key,en,ar,body,bodyar,i)
divider(s,88,515,1192,515)
image(s,'icon-link',89,545,27,27)
txt(s,133,539,1049,52,'Start with the contracted pop-up; choose the supported connection after checking the setup.','نبدأ بالـpop-up المذكور في العقد، ونحدد طريقة الربط المدعومة بعد فحص الإعدادات.',size=20,color=C['muted'])

# 5: premium, believable employee app. One window, three aligned panes.
s=slide(B('04 · THE EMPLOYEE EXPERIENCE','٠٤ · تجربة الموظف'),B('See the history. Continue from the latest update.','يشوف التذاكر. ويكمل من آخر تحديث.'),B('Customer details, previous tickets and follow-up context in one view.','بيانات العميل والتذاكر السابقة ومعلومات المتابعة في شاشة واحدة.'),[2,4],5)
panel(s,60,235,1160,404,shadow=True)
image(s,'genesys',84,253,133,32,0)
txt(s,245,258,486,33,'Service workspace','شاشة خدمة العملاء',size=20,bold=True)
state(s,1047,260,149,'Call active','المكالمة مستمرة',0)
divider(s,60,305,1220,305)
divider(s,350,305,350,600)
divider(s,733,305,733,600)
# Customer pane.
txt(s,84,327,235,24,'CUSTOMER','العميل',size=13,color=C['muted'],bold=True,step=1)
avatar(s,84,367,1,d=43)
txt(s,142,368,184,36,'Contact A','العميل A',size=24,bold=True,step=1)
txt(s,142,407,184,31,'+20 ••• 410',size=18,color=C['muted'],ltr=True,step=1)
txt(s,84,468,239,31,'Matched by caller number','مطابقة برقم المتصل',size=17,color=C['muted'],step=1)
divider(s,84,517,325,517,1)
txt(s,84,540,102,33,'2 open','٢ مفتوحة',size=22,bold=True,step=2)
txt(s,211,540,114,33,'1 closed','١ مغلقة',size=20,color=C['muted'],align='end',step=2)
# History pane.
image(s,'zoho',373,324,86,32,2)
txt(s,478,328,231,32,'Ticket history','تاريخ التذاكر',size=20,bold=True,step=2)
txt(s,374,380,159,28,'Open tickets (2)','تذاكر مفتوحة (٢)',size=16,color=C['green'],bold=True,step=2)
txt(s,571,380,139,28,'All history (3)','كل التذاكر (٣)',size=16,color=C['muted'],align='end',step=2)
divider(s,373,414,710,414,2)
rect(s,367,428,352,93,fill=C['sage'],line=C['sage'],radius=9,step=2)
txt(s,384,441,318,25,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=20,bold=True,step=2)
state(s,384,483,318,'Waiting on branch','بانتظار الفرع',2)
txt(s,384,541,318,32,'T102 · Product enquiry','T102 · استفسار عن منتج',size=20,step=2)
txt(s,384,578,318,24,'Open','مفتوحة',size=15,color=C['muted'],step=2)
# Selected record and source note.
txt(s,761,327,430,36,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=22,bold=True,step=3)
txt(s,761,373,430,27,'LATEST RECORDED NOTE','آخر ملاحظة مسجلة',size=13,color=C['muted'],bold=True,step=3)
rect(s,755,410,438,99,fill=C['soft'],line=C['soft'],radius=9,step=3)
txt(s,776,429,396,71,'Branch review is\nstill pending.','مراجعة الفرع\nلسه مطلوبة.',size=25,bold=True,step=3)
image(s,'icon-file',762,539,24,24,4)
txt(s,800,537,390,32,'Continue from this update','نكمل من التحديث ده',size=20,color=C['green'],bold=True,step=4)
txt(s,761,578,430,25,'Recorded in Zoho Desk','مسجلة في Zoho Desk',size=15,color=C['muted'],step=4)
divider(s,60,608,1220,608)
txt(s,85,616,671,22,'Existing Desk records · Call stays active','سجلات Desk الموجودة · المكالمة مستمرة',size=13,color=C['muted'])
txt(s,819,616,376,22,'ILLUSTRATIVE WORKSPACE','واجهة توضيحية',size=12,color=C['muted'],align='end')
mobile(s,'genesys','The call stays active','المكالمة مستمرة','An employee workspace for the call','شاشة الموظف أثناء المكالمة',0)
mobile(s,'icon-actor','Customer details','بيانات العميل','Contact A · caller-number match','العميل A · مطابقة برقم المتصل',1)
mobile(s,'zoho','Ticket history','تاريخ التذاكر','2 open tickets · 1 closed ticket','تذكرتين مفتوحتين · تذكرة مغلقة',2)
mobile(s,'icon-file','Latest recorded note','آخر ملاحظة مسجلة','Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',3)
mobile(s,'icon-check','Continue the follow-up','استكمال المتابعة','Read the source note before responding','قراءة الملاحظة الأصلية قبل الرد',4)

# 6: side-by-side flows inside one aligned surface.
s=slide(B('05 · BEFORE / AFTER','٠٥ · قبل وبعد'),B('The same information. A better start.','نفس المعلومات. بداية أفضل للمكالمة.'),B('Fewer manual retrieval steps before an informed response.','خطوات بحث يدوية أقل قبل الرد بمعلومات واضحة.'),[1,2],4)
panel(s,60,239,1160,363,shadow=True)
divider(s,640,264,640,577)
txt(s,92,265,504,35,'Before','قبل',size=25,bold=True)
txt(s,677,265,504,35,'Proposed after','بعد الربط المقترح',size=25,color=C['green'],bold=True)
for col,x in enumerate([92,677]):
 rows=[('icon-call','Receive the call','استقبال المكالمة'),('icon-search','Search manually','البحث يدويًا'),('icon-case','Find the right ticket','الوصول للتذكرة المناسبة'),('icon-file','Read the latest update','قراءة آخر تحديث')] if col==0 else [('icon-call','Receive the call','استقبال المكالمة'),('icon-case','Customer context appears','ظهور معلومات العميل'),('icon-file','Read the latest update','قراءة آخر تحديث'),('icon-actor','Continue with context','استكمال الحديث بمعلومات أوضح')]
 for i,(key,en,ar) in enumerate(rows):
  yy=323+i*64
  icon(s,key,x,yy,i,d=38,bg=C['soft'] if col==0 else C['sage'])
  if i<3:divider(s,x+19,yy+41,x+19,yy+57,i+1)
  txt(s,x+58,yy+3,447,37,en,ar,size=23,bold=col==1 and i==1,step=i)
  mobile(s,key,('Before: ' if col==0 else 'After: ')+en,('قبل: ' if col==0 else 'بعد: ')+ar,'Same caller and existing records','نفس المتصل والسجلات الموجودة',i)
txt(s,60,625,1160,33,'Spend less of the call finding the context.','وقت أقل من المكالمة يروح في البحث عن المعلومات.',size=21,color=C['green'])

# 7: a contextual conversation is the hero visual; three business outcomes.
s=slide(B('06 · VALUE FOR CONCRETE','٠٦ · القيمة لكونكريت'),B('More attention to the customer.','تركيز أكبر مع العميل.'),B('Practical benefits for the employee and the service experience.','فوائد عملية للموظف وتجربة خدمة العميل.'),[1,5],3)
panel(s,60,244,544,334,shadow=True)
avatar(s,89,277,0,d=42)
txt(s,146,282,421,35,'A conversation with context','محادثة بمعلومات واضحة',size=22,bold=True,step=0)
rect(s,88,347,488,131,fill=C['sage'],line=C['sage'],radius=12,step=0)
txt(s,111,368,444,93,'“I can see your earlier ticket.\nThe branch review is\nstill pending.”','«شايف التذكرة السابقة لحضرتك.\nمراجعة الفرع\nلسه مطلوبة.»',size=23,step=0)
image(s,'zoho',89,514,83,28,0)
txt(s,194,515,381,32,'Grounded in the recorded note','بناءً على الملاحظة المسجلة',size=18,color=C['muted'],step=0)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('icon-clock','Less manual searching','بحث يدوي أقل','Fewer steps before the informed response.','خطوات أقل قبل الرد بمعلومات واضحة.'),
 ('icon-file','Faster case understanding','فهم أسرع للحالة','The latest ticket note is already in view.','آخر ملاحظة في التذكرة ظاهرة للموظف.'),
 ('icon-actor','Smoother follow-up','متابعة أسهل','Continue from the existing service record.','نكمل من سجل الخدمة الموجود.')]):
 yy=259+i*112;icon(s,key,657,yy+3,i,d=44)
 txt(s,721,yy,487,39,en,ar,size=25,bold=True,step=i)
 txt(s,721,yy+48,487,50,body,bodyar,size=18,color=C['muted'],step=i)
 if i<2:divider(s,721,yy+93,1220,yy+93)
 mobile(s,key,en,ar,body,bodyar,i)
txt(s,60,622,1160,32,'Expected benefits · measure the change in an agreed pilot.','فوائد متوقعة · نقيس التغيير في تجربة نتفق عليها.',size=18,color=C['muted'])

# 8: one future roadmap surface, four restrained and connected areas.
s=slide(B('07 · OPTIONAL NEXT LAYER','٠٧ · خطوة مستقبلية اختيارية'),B('A foundation for future improvements.','أساس لإضافات مستقبلية مفيدة.'),B('Optional capabilities, scoped separately from the first delivery.','إمكانيات اختيارية، نتفق على نطاقها بشكل منفصل عن التسليم الأول.'),[5],4)
panel(s,60,244,1160,358,shadow=True)
divider(s,640,270,640,578);divider(s,87,423,1193,423)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('icon-file','AI ticket summaries','ملخصات AI للتذاكر','Short summaries with links to the original notes.','ملخصات قصيرة بمراجع للملاحظات الأصلية.'),
 ('icon-quality','Recurring issue detection','اكتشاف المشكلات المتكررة','Find patterns across existing service tickets.','اكتشاف أنماط عبر تذاكر الخدمة الموجودة.'),
 ('icon-actor','Management visibility','رؤية أوضح للإدارة','A clearer view of service and follow-up patterns.','رؤية أوضح لأنماط الخدمة والمتابعة.'),
 ('icon-clock','Follow-up support','مساعدة في المتابعة','Suggested next steps for employee review.','اقتراحات للخطوات التالية يراجعها الموظف.')]):
 x=91+(i%2)*580;y=277+(i//2)*176
 icon(s,key,x,y,i,d=44)
 txt(s,x+66,y+2,460,40,en,ar,size=24,bold=True,step=i)
 txt(s,x+66,y+56,460,72,body,bodyar,size=19,color=C['muted'],step=i)
 mobile(s,key,en,ar,body,bodyar,i)
txt(s,60,626,1160,32,'The first delivery stays focused on caller context.','التسليم الأول يركز على ظهور معلومات المتصل.',size=19,color=C['muted'])

# 9: spacious, light closing and an actionable implementation route.
s=slide(B('08 · A FOCUSED FIRST COLLABORATION','٠٨ · بداية تعاون محددة'),B('Start the call\nwith customer context.','نبدأ المكالمة\nبمعلومات العميل.'),B('A practical improvement to the everyday service workflow.','تحسين عملي في شغل خدمة العملاء اليومي.'),[4,5],3,True)
txt(s,60,168,526,30,'THE FIRST DELIVERY','التسليم الأول',size=16,color=C['accent'],bold=True)
txt(s,60,225,544,132,s['title']['en'],s['title']['ar'],size=46,bold=True,role='title')
txt(s,60,386,490,78,'A better start for the employee.\nBetter continuity for the customer.','بداية أوضح للموظف.\nواستمرارية أفضل للعميل.',size=24,color=C['muted'])
image(s,'genesys',60,519,159,41);image(s,'zoho',275,519,105,41)
panel(s,650,166,570,412,shadow=True)
for i,(key,en,ar,body,bodyar) in enumerate([
 ('icon-file','Check the existing pop-up','نفحص الـpop-up الموجود','Confirm how the current setup behaves.','نتأكد من طريقة عمل الإعدادات الحالية.'),
 ('icon-link','Complete the supported connection','نكمّل الربط المدعوم','Choose the right native option or adapter.','نحدد الإعداد المناسب أو وسيط الربط.'),
 ('icon-check','Test agreed calls','نختبر مكالمات متفق عليها','Verify the context and the fallback behavior.','نتأكد من المعلومات والتعامل مع الاستثناءات.')]):
 y=201+i*121
 icon(s,key,679,y,i,d=47,bg=C['sage'])
 if i<2:divider(s,702,y+53,702,y+106,i+1)
 txt(s,746,y+1,443,44,en,ar,size=23,bold=True,step=i)
 txt(s,746,y+49,443,56,body,bodyar,size=18,color=C['muted'],step=i)
 mobile(s,key,en,ar,body,bodyar,i)
txt(s,60,614,1160,38,'Existing systems. Existing records. A more informed conversation.','أنظمة موجودة. وسجلات موجودة. ومحادثة بمعلومات أوضح.',size=21,color=C['green'])

assert len(slides)==9 and all(not s['dark'] for s in slides)
# Enforce light surfaces across the native deck (small status dots and text are accents).
for s in slides:
 for e in s['elements']:
  if e['type']=='rect':
   rgb=[int(e['fill'][i:i+2],16) for i in (1,3,5)]
   assert min(rgb)>=225,(s['index'],e['fill'])
  if e['type']=='text':assert e['size']<=50
story=dict(title=B('GRINDCTRL · Customer context, with every call','GRINDCTRL · معلومات العميل مع كل مكالمة'),colors=C,slides=slides,sources=basis['sources'],fixtures=basis['fixtures'])
(ROOT/'story.json').write_text(json.dumps(story,ensure_ascii=False,indent=2))
print('9 light-only slides: product workspaces, controlled typography, 6 causal events, bilingual notes.')
