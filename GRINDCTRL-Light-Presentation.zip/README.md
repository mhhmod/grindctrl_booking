# GRINDCTRL — Customer context, with every call

A complete light-theme redesign of the nine-slide Concrete proposal. The new visual system uses warm off-white surfaces, white product windows, soft dividers, restrained sage/copper accents, controlled typography and an integrated employee workspace.

## Open the files

- English and Arabic PowerPoint: use **Slide Show / From Beginning** to see each slide's sequence. Text, shapes, diagrams and notes remain editable.
- English and Arabic PDF: static slides, fully revealed.
- Bilingual HTML: download and open in a browser. Works offline with language switching, replay, pause, next event, full reveal and source notes. Small screens use readable cards.
- English and Arabic MP4: a short, silent walkthrough of the call-to-context sequence, the employee screen and intended business value.

## Story

1. Customer context, with every call.
2. Existing ticket history currently requires manual phone-number search.
3. Call → caller number → automatic lookup → Desk history → employee context → informed conversation.
4. Genesys, GRINDCTRL, Zoho Desk and the employee view.
5. A proposed product-style workspace: customer, open tickets and the last recorded note.
6. Before and proposed after, with aligned four-step flows.
7. Less searching, earlier case understanding and smoother follow-up.
8. Optional future AI and management capabilities.
9. Inspect the existing pop-up, complete the supported connection and test agreed calls.

## Grounding and scope

The user reports that Zoho is used for ticketing, automatic caller context does not appear with the Genesys call, and manual phone-number search finds the previous tickets. These observations have not been independently tested. The November 2023 contract, PDF page 4, includes “CRM URL pop up integration.” This establishes scope, not current functionality or two-way synchronization.

This is a proposed first collaboration. GRINDCTRL has no existing Concrete/Centro relationship or completed implementation. The contact, masked phone, ticket IDs, note, statuses and employee reply are fictional illustrations. No original contract scans, private prices or personal customer records are included.

Start by checking the existing supported pop-up and configuration. Choose a native option or adapter after verifying the actual desktop, permissions and capabilities. A caller-number match is not authentication. Live acceptance must include shared numbers, unknown/missing numbers, unavailable lookup and employee record permissions while the call continues. The deck illustrates successful lookup; it does not claim to implement these integrations.

The first delivery is caller context. AI summaries and management views are future options. No live connector, backend or model runs in this deck. No ROI, savings, measured latency, price or delivery date is asserted. Animation timing is explanatory pacing.

## Source and rebuild

`source/` contains the bilingual story, shared layout, native PowerPoint builder, animation XML builder, preview template/client, font preparation, assets/licenses, browser validation and deterministic video exporter. `creative-brief.txt` records the user's supplied request. `validation.json` records the completed checks.

From `source/`:

```bash
python story.py
python prepare-fonts.py
python build-pptx.py
python build-preview.py
PLAYWRIGHT_MODULE=/absolute/path/to/playwright node verify-export.cjs
PLAYWRIGHT_MODULE=/absolute/path/to/playwright node record-motion.cjs
```

Requires Python with python-pptx, Pillow, lxml, fontTools and brotli; Node with Playwright; Chromium at `/usr/bin/chromium`; FFmpeg. Font assets include licensed Manrope Regular/Bold and IBM Plex Sans Arabic Medium. Install these when editing for exact typography.

## Validation and viewing limits

The design was inspected as browser scenes and as native PowerPoint slides rendered through LibreOffice. Both languages cover nine populated PDF pages. All large surfaces are light; no slide or UI card uses a dark theme. Native slide bounds and animation targets are checked, and entrance effects are compared after a LibreOffice round trip.

Browser checks cover all nine slides in both languages at 320, 390, 768, 1024, 1366 and 1440 pixels: no horizontal overflow or clipped desktop text; controls, causal ordering, semantic stage labels, matching arrowheads, offline behavior, RTL navigation and reduced-motion behavior pass.

Microsoft PowerPoint, Google Slides and Keynote playback were not directly tested. Native effects remain in the editable PPTX; browser preview and MP4 show the motion directly. PDF copies are static. The HTML download is not a hosted website.

## العربية

نسخة جديدة من ٩ شرائح بثيم فاتح بالكامل، وعناوين متزنة ومساحات أوضح. الشاشة الأساسية تجمع بيانات العميل والتذاكر وآخر ملاحظة في واجهة خدمة عملاء واحدة. الحركة تشرح ست خطوات من وصول المكالمة لحد استكمال الحديث بمعلومات العميل.

شغّل PowerPoint في وضع Slide Show، أو نزّل ملف HTML وافتحه في المتصفح، أو شغّل الفيديو. العرض مقترح لأول تعاون، والسجلات خيالية؛ الربط الحي مرحلة تنفيذ لاحقة. إضافات AI والإدارة اختيارية ومفصولة عن التسليم الأول.
