# GRINDCTRL — Premium V2 / editable production project

A new Remotion/React/TypeScript production. The rejected SVG/state-JPEG renderer is not part of this engine. Three 150-second 1080p/30fps compositions, each 4500 frames, using the original approved English voice recordings.

## Render / edit

Use Node 22+ (tested 24), npm, Python 3 for QA, and FFmpeg/FFprobe on PATH. Install project packages with `npm ci`.

- `npm run studio` opens Remotion Studio for scene/timeline edits.
- `npm run render -- 01` exports Film 01; use 02 or 03 for the others. Output in renders/.
- `npm run render -- 03 --proof` exports a short actual narrated motion proof.
- `npm run preview:build` creates standalone synchronized HTML files in previews/. These contain all required images, font and audio; download and open an HTML file locally. A GitHub raw file URL is a download, not a hosted app. Direct file:// navigation is blocked by the managed browser used here; self-contained playback is tested through localhost. If your browser blocks local files, serve the folder with `python -m http.server` and open its localhost URL.
- `npm run typecheck` validates React/TypeScript source.
- Chrome/Chromium is selected with GRINDCTRL_CHROMIUM_PATH. Linux /usr/bin/chromium is detected; otherwise Remotion's supported browser handling is used. No Docker or GPU-dependent 3D renderer is required.

## Source map

- src/design-system: colour/type tokens and local font.
- src/components: native editable call/contact/ticket/activity/note/product/chat/inbox elements and custom consistent icons.
- src/motion: deterministic interpolation, damped springs, camera/cursor and measured speech-cue lookup.
- src/scenes/film01–03: 12 major compositions per film; each scene owns its shot-specific layout/state logic.
- src/compositions/Film.tsx: shared 4500-frame clock, scene boundaries, captions and one mixed audio source per film. The finishing pass copies H.264 unchanged and uses the approved mix to set both streams and the container to exactly 150.000 seconds.
- public/approved: supplied brand/vendor marks and licensed Geist font.
- public/generated: new fictional navy linen product and same-person before/result portraits.
- public/audio: unchanged original MP3s and 150-second narration/music mixes.
- timelines: actual CTC word timestamps/scores, event cues, SRT, narration placement and visual-shot maps.
- research, reviews and qa: stack, evidence, provenance, actual comparisons and technical/creative review.

To re-finish music/levels independently, install soundfile/numpy and run scripts/rebuild-audio.py. The source MP3s and narration-segment sample hashes remain authoritative. This optional rebuild can change the mix; it does not generate voice, alter speed or truncate words. Editing UI/camera/type does not require rebuilding the rendering engine.

## QA commands

Install requirements-qa.txt. For preview automation run a local HTTP server from this directory on 127.0.0.1:8894, then `npm run qa:preview`. Playwright is pinned locally; use an available Chromium executable. `python scripts/qa-media.py 01` fully decodes/inspects a completed film and checks original speech correlations. `node scripts/qa-playback.cjs 01` performs a complete natural-rate unmuted software playback. Frame-parity tools compare actual MP4 frames with the standalone HTML preview.

Alignment is optional for ordinary editing/rendering: measured JSON already exists. To recompute it, use torch/torchaudio 2.6.0 CPU in a separate environment; scripts/align-audio.py downloads the official English ASR model to GRINDCTRL_ALIGN_MODEL_DIR or .alignment-cache. No narration is sent to an external speech service and no new voice is generated.

## Evidence and rights

Concrete films are proposals, not an implemented GRINDCTRL client case. UI/customer/call/order records are illustrative. Original call-note authorship is preserved. Call notes, ticket updates and AI summaries remain distinct records. Film 03 product photography is synthetic, not a live try-on benchmark or actual Concrete merchandise. See research/EVIDENCE_AND_UI_FIDELITY.md and ASSET_PROVENANCE.md.

Geist's SIL OFL and Remotion's original license are included. Remotion has entity-size-dependent commercial licensing, not a blanket MIT license; no subscription purchase or owner's-license verification is claimed. See STACK_DECISION.md.

## Distribution

Finished MP4s are separate primary downloads; this source package avoids duplicating them. The artifact branch is mhhmod/grindctrl_booking / grindctrl-premium-v2-three-films-2026-10-22. It does not modify main or deploy the production application. The baseline remains on grindctrl-premium-concrete-three-films-2026-10-22.
