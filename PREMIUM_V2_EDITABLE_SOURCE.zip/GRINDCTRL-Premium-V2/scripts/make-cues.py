from pathlib import Path
import json,csv,re
D=Path(__file__).resolve().parent.parent
requests={
'01': [('call_answer','ANSWERS',5),('manual_copy','COPY',22.4),('manual_search','SEARCH',23.9),('authorized_lookup','AUTHORIZED',43.3),('valid_match','MATCH',46.7),('screen_pop','OPENS',48.3),('contact_record','CONTACT',50.86),('previous_tickets','PREVIOUS',52.1),('ticket_status','STATUSES',54.2),('latest_update','LATEST',55.4),('pending_review','PENDING',66),('multiple_matches','SEVERAL',79.5),('manual_fallback','MANUAL',86),('lookup_failure','FAILS',89),('call_continues','CONTINUE',91),('existing_genesys','GENESYS',98.4785),('existing_zoho','ZOHO',99.3223),('proposal_status','INTEGRATION',101.7979),('proposed_context','PROPOSING',104.0923),('connect_context','CONNECT',105.757),('context_ready','READY',141.5)],
'02': [('lookup_number','LOOKUP',28),('reliable_match','MATCH',30),('customer_name','NAME',33),('email','EMAIL',35.5),('missing_field','UNAVAILABLE',39),('lifestyle','LIFESTYLE',44.8),('prestige','PRESTIGE',45.8),('elite','ELITE',46.5),('trusted_source','TRUSTED',50),('call_timeline','TIMELINE',64.5),('call_date','DATE',68),('specific_note','NOTES',70),('open_call','OPENS',82),('write_note','RECORDS',96.1),('note_owner','CALL',101.3),('future_continuity','CONTINUITY',138)],
'03': [('select_garment','SELECTS',24),('try_on_click','TAPS',26),('photo_upload','UPLOADS',28),('preview_generation','GENERATES',32),('style_preview','STYLE',41),('fit_limit','GUARANTEE',44),('open_chat','OPENS',67),('store_knowledge','INFORMATION',72.5),('handoff','HANDS',81.5),('handoff_reason','REASON',82.3),('shared_inbox','INBOX',85.5),('assign','ASSIGNS',86.4),('private_note','NOTE',88.1),('human_reply','REPLIES',88.8),('read_only','READ',95.6),('team_control','CONTROL',132),('brand','GRIND',142)],
}
films=json.loads((D/'timelines/approved-audio-and-captions.json').read_text());cue_map={}
for film in films:
 n=film['id'];words=json.loads((D/'timelines/ctc-alignment'/(n+'-words.json')).read_text())['words'];events=[]
 for key,word,near in requests[n]:
  candidates=[w for w in words if w.get('word')==word and w.get('start_sec') is not None]
  if not candidates:raise ValueError((n,key,word))
  chosen=min(candidates,key=lambda w:abs(w['start_sec']-near))
  if abs(chosen['start_sec']-near)>4:raise ValueError((n,key,chosen))
  events.append({'event':key,'phrase_trigger':chosen['phrase_text'],'word_trigger':word,'start_sec':chosen['start_sec'],'end_sec':chosen['end_sec'],'source_start_sec':chosen['source_start_sec'],'source_end_sec':chosen['source_end_sec'],'frame':round(chosen['start_sec']*30),'ctc_score':chosen['mean_ctc_score'],'verification':'automated waveform forced alignment; not a human-certified word boundary'})
 events.sort(key=lambda event:event['start_sec'])
 cue_map[n]=events
 # Refine subtitle edges from actual aligned words, keeping original spoken text.
 for cap in film['captions']:
  hits=[w for w in words if w.get('start_sec') is not None and cap['start']<=((w['start_sec']+w['end_sec'])/2)<cap['end']]
  if hits:
   cap.setdefault('old_phrase_start',cap['start']);cap.setdefault('old_phrase_end',cap['end']);cap['start']=max(0,hits[0]['start_sec']-.045);cap['end']=min(150,hits[-1]['end_sec']+.08);cap['timing_method']='local CTC forced alignment; phrase text reconciled to approved script spelling'
 for i in range(len(film['captions'])-1):film['captions'][i]['end']=min(film['captions'][i]['end'],film['captions'][i+1]['start']-.02)
 def ts(t):
  m=round(t*1000);return f'{m//3600000:02d}:{m//60000%60:02d}:{m//1000%60:02d},{m%1000:03d}'
 (D/'timelines'/(n+'.srt')).write_text('\n\n'.join(str(i+1)+'\n'+ts(c['start'])+' --> '+ts(c['end'])+'\n'+c['text'] for i,c in enumerate(film['captions']))+'\n')
 with (D/'timelines'/(n+'-phrase-to-visual-cues.csv')).open('w') as f:
  w=csv.DictWriter(f,fieldnames=events[0].keys());w.writeheader();w.writerows(events)
(D/'timelines/actual_audio_cues.json').write_text(json.dumps(cue_map,indent=2))
(D/'timelines/approved-audio-and-captions.json').write_text(json.dumps(films,indent=2))
for n,evs in cue_map.items():
 for e in evs:print(n,e['event'],round(e['start_sec'],3),round(e['ctc_score'],2))
