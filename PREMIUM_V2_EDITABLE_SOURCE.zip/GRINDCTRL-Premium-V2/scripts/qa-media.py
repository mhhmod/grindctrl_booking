from pathlib import Path
import sys,json,subprocess,hashlib,re
import numpy as np
from scipy.signal import correlate
D=Path(__file__).resolve().parent.parent
NAMES={'01':'01_Concrete_Genesys_ZohoDesk_PREMIUM_V2','02':'02_Concrete_Customer360_CallActivities_PREMIUM_V2','03':'03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2'}
films=json.loads((D/'timelines/approved-audio-and-captions.json').read_text())
for f in films:
 n=f['id']
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 p=D/'renders'/(NAMES[n]+'.mp4');assert p.is_file()
 meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)]));v=next(s for s in meta['streams'] if s['codec_type']=='video');a=next(s for s in meta['streams'] if s['codec_type']=='audio')
 frames=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','json',str(p)]))['streams'][0]['nb_read_frames']
 assert int(frames)==4500 and v['width']==1920 and v['height']==1080 and v['avg_frame_rate']=='30/1' and v['codec_name']=='h264' and a['codec_name']=='aac'
 assert float(v['duration'])==150 and float(a['duration'])==150 and float(meta['format']['duration'])==150
 decode=subprocess.run(['ffmpeg','-hide_banner','-v','warning','-xerror','-i',str(p),'-f','null','-'],capture_output=True,text=True);assert decode.returncode==0,decode.stderr
 log=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-vn','-f','null','-'],capture_output=True,text=True,check=True).stderr;volume=json.JSONDecoder().raw_decode(log[log.rfind('{'):])[0]
 def pcm(file):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(file),'-ar','44100','-ac','1','-f','f32le','-']),dtype='<f4')
 original=pcm(D/'public/audio'/f['source_audio']);encoded=pcm(p);mixed=pcm(D/'public/audio'/(n+'-approved-mix.m4a'));checks=[]
 assert hashlib.sha256((D/'public/audio'/f['source_audio']).read_bytes()).hexdigest()==f['source_sha256']
 for seg in f['narration_segments']:
  start=seg['source_start_sec'];end=seg['source_end_sec'];
  for point in np.linspace(start+.4,end-1.1,max(3,round((end-start)/9))):
   # Choose a voiced slice in a local window; do not correlate silence.
   st=round(point*44100);size=round(.6*44100);opts=[]
   for shift in np.arange(0,.8,.1):
    at=st+round(shift*44100)
    if at+size<=round(end*44100):opts.append((np.mean(original[at:at+size]**2),at))
   if not opts:continue
   _,st=max(opts);target=round((seg['target_start_sec']+st/44100-start)*44100);ref=original[st:st+size].astype('float64');got=encoded[max(0,target-800):target+size+800].astype('float64');cc=correlate(got,ref,mode='valid',method='fft');lag=int(np.argmax(cc))-800;part=encoded[target+lag:target+lag+size].astype('float64');corr=float(np.corrcoef(ref,part)[0,1]);checks.append({'source_sec':st/44100,'target_sec':target/44100,'lag_samples':lag,'correlation':corr})
 assert min(x['correlation'] for x in checks)>.93,checks
 assert max(abs(x['lag_samples']) for x in checks)<100,checks
 assert float(volume['input_tp'])<=-.5
 assert len(encoded)>=149.97*44100
 blacklog=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-vf','blackdetect=d=0.1:pix_th=0.05:pic_th=0.99','-an','-f','null','-'],capture_output=True,text=True,check=True).stderr
 blacks=re.findall(r'black_start:[^\n]+',blacklog);assert not blacks,blacks
 result={'film':n,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'video':{'width':v['width'],'height':v['height'],'fps':v['avg_frame_rate'],'codec':v['codec_name'],'duration':float(v['duration']),'decoded_frames':int(frames)},'audio':{'duration':float(a['duration']),'codec':a['codec_name'],'channels':a['channels'],'sample_rate':a['sample_rate'],'lufs':float(volume['input_i']),'true_peak_dbtp':float(volume['input_tp']),'lra':float(volume['input_lra']),'original_voice_windows':checks,'max_alignment_lag_samples':max(abs(x['lag_samples']) for x in checks),'minimum_original_voice_correlation':min(x['correlation'] for x in checks)},'full_decode_errors':decode.stderr,'black_sequences':blacks,'source_sha256':f['source_sha256'],'source_seconds':f['source_duration'],'human_audition':False}
 (D/'qa'/(n+'-MEDIA_QA.json')).write_text(json.dumps(result,indent=2));print(n,'MEDIA PASS',result['video'],result['audio']['lufs'],result['audio']['max_alignment_lag_samples'],flush=True)
