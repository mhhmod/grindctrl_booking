const fs = require("fs");
const { chromium } = require("playwright");
const root = require("path").resolve(__dirname, "..");
(async () => {
  const browser = await chromium.launch({
    executablePath: "/usr/bin/chromium",
    args: [
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--autoplay-policy=no-user-gesture-required",
    ],
  });
  let results = [];
  for (const film of ["01", "02", "03"]) {
    const page = await browser.newPage({
      viewport: { width: 1920, height: 1310 },
      deviceScaleFactor: 1,
    });
    let errors = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.goto(
      "http://127.0.0.1:8894/previews/" + film + "_PREMIUM_V2.html",
    );
    await page.waitForFunction(
      () => window.__GRINDCTRL_READY && window.__GRINDCTRL_PLAYER,
      null,
      { timeout: 60000 },
    );
    const shots = await page.locator("details button").count();
    let rows = [];
    for (let sec = 0; sec < 150; sec += 2.5) {
      const f = Math.min(4499, Math.round(sec * 30));
      await page.evaluate((f) => window.__GRINDCTRL_PLAYER.seekTo(f), f);
      await page.waitForTimeout(35);
      rows.push(
        await page.evaluate(() => {
          const root = document.querySelector("[data-film]");
          const box = root.getBoundingClientRect(),
            scale = box.width / 1920;
          const texts = [];
          const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
          let node;
          while ((node = w.nextNode())) {
            if (!node.textContent.trim() || !node.parentElement) continue;
            const el = node.parentElement;
            let visible = true;
            for (let a = el; a && a !== root; a = a.parentElement) {
              if (Number(getComputedStyle(a).opacity) < 0.01) {
                visible = false;
                break;
              }
            }
            if (!visible) continue;
            const range = document.createRange();
            range.selectNodeContents(node);
            const r = range.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) continue;
            let clipped = false;
            for (let a = el; a && a !== root; a = a.parentElement) {
              const css = getComputedStyle(a);
              if (
                ["hidden", "clip", "auto", "scroll"].includes(css.overflow) ||
                ["hidden", "clip", "auto", "scroll"].includes(css.overflowY)
              ) {
                const ar = a.getBoundingClientRect();
                if (
                  r.bottom > ar.bottom + 2 ||
                  r.top < ar.top - 2 ||
                  r.right > ar.right + 2 ||
                  r.left < ar.left - 2
                ) {
                  clipped = true;
                  break;
                }
              }
            }
            if (
              r.left < box.left - 2 ||
              r.right > box.right + 2 ||
              r.top < box.top - 2 ||
              r.bottom > box.bottom + 2 ||
              clipped
            )
              texts.push({
                text: node.textContent.trim(),
                x: (r.left - box.left) / scale,
                y: (r.top - box.top) / scale,
                w: r.width / scale,
                h: r.height / scale,
                clipped,
              });
          }
          return {
            frame: Number(root.dataset.frame),
            overflow: texts,
            notes: [...root.querySelectorAll("[data-note-call]")].map((e) => ({
              call: e.dataset.noteCall,
              author: e.dataset.noteAuthor,
              text: e.textContent,
            })),
          };
        }),
      );
    }
    await page.setViewportSize({ width: 390, height: 800 });
    await page.waitForTimeout(50);
    const mobile = await page.evaluate(() => ({
      scroll: document.documentElement.scrollWidth,
      width: innerWidth,
      buttons: [...document.querySelectorAll("nav button")].every(
        (b) => b.getBoundingClientRect().height >= 44,
      ),
    }));
    results.push({
      film,
      shots,
      sampledStates: rows.length,
      errors,
      mobile,
      states: rows,
    });
    await page.close();
    console.log(
      "QA",
      film,
      rows.reduce((s, r) => s + r.overflow.length, 0),
      "clipping reports",
    );
  }
  fs.writeFileSync(
    root + "/qa/PREVIEW_QA.json",
    JSON.stringify(results, null, 2),
  );
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
