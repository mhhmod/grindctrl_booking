from pathlib import Path
import json,sys,subprocess,hashlib
from PIL import Image
import numpy as np
D=Path(__file__).resolve().parent.parent
for n in ['01','02','03']:
 if len(sys.argv)>1 and sys.argv[1]!=n:continue
 p=D/'qa'/(n+'-FRAME_SAMPLES.json')
 if not p.exists():continue
 rows=json.loads(p.read_text())
 for r in rows:
  a=np.asarray(Image.open(D/r['reference']).convert('RGB')).astype('int16');b=np.asarray(Image.open(D/r['encoded']).convert('RGB')).astype('int16');assert a.shape==b.shape==(1080,1920,3);delta=np.abs(a-b);r['mean_absolute_pixel_error_255']=float(delta.mean());r['pixel_error_p99']=float(np.quantile(delta,.99))
 names={'01':'01_Concrete_Genesys_ZohoDesk_PREMIUM_V2','02':'02_Concrete_Customer360_CallActivities_PREMIUM_V2','03':'03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2'}
 movie=D/'renders'/(names[n]+'.mp4')
 video_hash=subprocess.check_output(['ffmpeg','-v','error','-i',str(movie),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-'],text=True).strip()
 report={'film':n,'samples':len(rows),'sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'h264_stream_sha256':video_hash,'preview_sha256':hashlib.sha256((D/'previews'/(n+'_PREMIUM_V2.html')).read_bytes()).hexdigest(),'max_mean_absolute_pixel_error_255':max(r['mean_absolute_pixel_error_255'] for r in rows),'frames':rows,'method':'Actual final encoded frame vs synchronized standalone HTML Player at same frame,1920×1080,local fonts/data assets. AAC rendering not inferred from pixel parity. A final audio-only mux preserves the measured H.264 stream unchanged.'}
 (D/'qa'/(n+'-FRAME_PARITY_QA.json')).write_text(json.dumps(report,indent=2));print('PARITY',n,report['samples'],report['max_mean_absolute_pixel_error_255']);assert report['max_mean_absolute_pixel_error_255']<3,report['max_mean_absolute_pixel_error_255']
