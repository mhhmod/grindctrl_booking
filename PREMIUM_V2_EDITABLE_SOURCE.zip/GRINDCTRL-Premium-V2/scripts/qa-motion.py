"""Describe actual encoded motion; reading holds are not automatically defects."""
from pathlib import Path
import subprocess, json, sys
import numpy as np

D = Path(__file__).resolve().parent.parent
NAMES = {'01': '01_Concrete_Genesys_ZohoDesk_PREMIUM_V2', '02': '02_Concrete_Customer360_CallActivities_PREMIUM_V2', '03': '03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2'}
for n, stem in NAMES.items():
    if len(sys.argv) > 1 and sys.argv[1] != n:
        continue
    raw = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(D/'renders'/(stem+'.mp4')), '-vf', 'fps=2,crop=1920:800:0:130,scale=480:200,format=gray', '-an', '-f', 'rawvideo', '-'])
    frames = np.frombuffer(raw, dtype='uint8').reshape(-1, 200, 480).astype('int16')
    delta = np.abs(np.diff(frames, axis=0)).mean(axis=(1, 2))
    holds = []; start = None
    for i, value in enumerate(delta):
        if value < .12 and start is None:
            start = i / 2
        if value >= .12 and start is not None:
            if i / 2 - start >= 2:
                holds.append({'start_sec': start, 'end_sec': i/2, 'seconds': i/2-start})
            start = None
    if start is not None and len(delta)/2 - start >= 2:
        holds.append({'start_sec': start, 'end_sec': len(delta)/2, 'seconds': len(delta)/2-start})
    report = {'film': n, 'decoded_samples': len(frames), 'method': '2 fps actual encoded luma, central 1920x800 workflow area downsampled to480x200; excludes captions and header/footer. Descriptive motion metric, not a comprehension or creative-quality score.', 'mean_absolute_change_255': float(delta.mean()), 'holds_over_2_seconds': holds, 'interpretation': 'A focused UI reading hold is intentional when the narration is explaining the visible record. Original short visual-only intervals are identified separately in AUDIO_SOURCE_VERIFICATION.json. Motion alone does not prove quality.'}
    (D/'qa'/(n+'-MOTION_QA.json')).write_text(json.dumps(report, indent=2))
    print('MOTION DESCRIBED', n, 'max hold', max((h['seconds'] for h in holds), default=0), flush=True)
