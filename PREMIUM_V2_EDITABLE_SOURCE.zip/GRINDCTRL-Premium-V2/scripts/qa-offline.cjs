const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
(async () => {
  const browser = await chromium.launch({executablePath: process.env.GRINDCTRL_CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage', '--autoplay-policy=no-user-gesture-required']});
  const results = [];
  try {
    for (const film of ['01','02','03']) {
      let page = await browser.newPage();
      const errors = [], externalRequests = [];
      page.on('pageerror', e => errors.push(e.message));
      const localUrl='http://127.0.0.1:8894/previews/'+film+'_PREMIUM_V2.html';
      const handleRoute = route => {
        if (route.request().url() === localUrl && route.request().isNavigationRequest()) return route.continue();
        externalRequests.push(route.request().url()); return route.abort();
      };
      await page.route(/^https?:/, handleRoute);
      let fileProtocol=true, fileProtocolLimitation=null;
      try {
        await page.goto(pathToFileURL(path.join(root, 'previews', film+'_PREMIUM_V2.html')).href);
      } catch(error) {
        if (!error.message.includes('ERR_BLOCKED_BY_ADMINISTRATOR')) throw error;
        fileProtocol=false;fileProtocolLimitation='Managed Chromium administrator policy blocks file:// navigation. Not bypassed; direct file opening remains unverified here.';
        await page.close();
        page = await browser.newPage();
        page.on('pageerror', e => errors.push(e.message));
        await page.route(/^https?:/, handleRoute);
        await page.goto(localUrl);
      }
      await page.waitForFunction(() => window.__GRINDCTRL_READY);
      await page.evaluate(() => window.__GRINDCTRL_PLAYER.play());
      await page.waitForTimeout(1700);
      const state = await page.evaluate(() => ({frame:window.__GRINDCTRL_PLAYER.getCurrentFrame(),fontLoaded:document.fonts.check('24px Geist'),audioElements:[...document.querySelectorAll('audio')].map(a=>({duration:a.duration,error:a.error?.code || null,sourceIsDataUrl:a.currentSrc.startsWith('data:')}))}));
      if (state.frame < 5 || !state.fontLoaded || errors.length || externalRequests.length || state.audioElements.some(a=>a.error)) throw Error(JSON.stringify({film,state,errors,externalRequests}));
      results.push({film,fileProtocol,fileProtocolLimitation,externalAssetRequestsBlocked:true,externalRequests,errors,...state,method:'Standalone HTML local-server fallback; only initial document GET allowed. All subsequent HTTP(S) asset requests blocked; embedded font, images and audio playback progress verified. This does not certify direct file:// opening in this managed browser or a full human audition.'});
      await page.close();
    }
  } finally { await browser.close(); }
  fs.writeFileSync(path.join(root,'qa/OFFLINE_PREVIEW_QA.json'),JSON.stringify(results,null,2));
  console.log('OFFLINE PREVIEWS PASSED', results.length);
})().catch(error => { console.error(error); process.exit(1); });
