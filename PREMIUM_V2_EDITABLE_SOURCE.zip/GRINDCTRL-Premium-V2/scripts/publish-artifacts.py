"""Publish to a fresh artifact-only orphan branch; never touch app checkouts."""
from pathlib import Path
import subprocess, json
D=Path('/workspace/GRINDCTRL-PREMIUM-V2-Delivery-2026-10-23')
G=Path('/tmp/grindctrl-premium-v2-three-films-2026-10-22.git')
B='grindctrl-premium-v2-three-films-2026-10-22'
REMOTE='https://github.com/mhhmod/grindctrl_booking.git'
def run(args):return subprocess.check_output(args,text=True).strip()
assert not run(['git','ls-remote',REMOTE,'refs/heads/'+B]),'Never overwrite an existing branch'
assert not G.exists(),'Use a fresh artifact-only Git directory'
assert len(list(D.glob('*.mp4')))==3
assert (D/'PREMIUM_V2_EDITABLE_SOURCE.zip').exists()
for p in D.rglob('*'):
    if p.is_file():
        assert p.stat().st_size<99*1024**2
        assert p.suffix not in ['.pem','.key'] and 'private-contract' not in p.name
subprocess.run(['git','init','--bare',str(G)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
base=['git','--git-dir='+str(G),'--work-tree='+str(D)]
subprocess.run(base+['read-tree','--empty'],check=True)
subprocess.run(base+['add','--all'],check=True)
tree=run(base+['write-tree'])
names=run(['git','--git-dir='+str(G),'ls-tree','-r','--name-only',tree]).splitlines()
assert not any(n.startswith(('.github/','apps/')) for n in names)
commit=run(['git','--git-dir='+str(G),'-c','user.name=Codex','-c','user.email=codex@openai.com','commit-tree',tree,'-m','Deliver three completely rebuilt Premium V2 Remotion films with original approved narration, sources and final media QA'])
subprocess.run(['git','--git-dir='+str(G),'update-ref','refs/heads/'+B,commit],check=True)
subprocess.run(['git','--git-dir='+str(G),'push',REMOTE,'refs/heads/'+B+':refs/heads/'+B],check=True)
out={'repository':'mhhmod/grindctrl_booking','branch':B,'commit':commit,'files':len(names),'scope':'Artifact-only orphan branch. No main/application/workflow edits; no private contracts or credentials.'}
(D/'PUBLICATION_LOCAL.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out))
