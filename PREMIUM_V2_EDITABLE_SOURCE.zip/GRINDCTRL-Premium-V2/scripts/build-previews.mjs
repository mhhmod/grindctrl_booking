import { build } from "esbuild";
import fs from "node:fs";
import path from "node:path";
const root = path.resolve(import.meta.dirname, "..");
await build({
  entryPoints: [path.join(root, "src/Preview.tsx")],
  bundle: true,
  minify: true,
  format: "iife",
  outfile: path.join(root, "previews/player.js"),
  loader: { ".woff2": "dataurl" },
  define: { "process.env.NODE_ENV": '"production"' },
  target: ["chrome120", "safari17"],
  logLevel: "warning",
});
const js = fs.readFileSync(path.join(root, "previews/player.js"), "utf8");
const css = fs.readFileSync(path.join(root, "previews/player.css"), "utf8");
for (const film of ["01", "02", "03"]) {
  const assets = {};
  for (const dir of film === "03" ? ["approved", "generated"] : ["approved"])
    for (const name of fs.readdirSync(path.join(root, "public", dir))) {
      if (!name.endsWith(".png")) continue;
      assets[dir + "/" + name] =
        "data:image/png;base64," +
        fs
          .readFileSync(path.join(root, "public", dir, name))
          .toString("base64");
    }
  assets["audio/" + film + "-approved-mix.m4a"] =
    "data:audio/mp4;base64," +
    fs
      .readFileSync(path.join(root, "public/audio", film + "-approved-mix.m4a"))
      .toString("base64");
  const html =
    '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GRINDCTRL Premium V2 / Film ' +
    film +
    "</title><style>" +
    css +
    'body{background:#faf8f5}button{border:1px solid #ded8ce;border-radius:8px;background:#fffdf9;color:#2a2826;padding:11px 16px;min-height:44px;font:500 14px Geist,Arial;cursor:pointer}button:hover{background:#eee9e0}button:focus-visible{outline:2px solid #827059;outline-offset:3px}</style></head><body><div id="root"></div><script>window.__GRINDCTRL_FILM=' +
    JSON.stringify(film) +
    ";window.__GRINDCTRL_ASSETS=" +
    JSON.stringify(assets) +
    ";</script><script>" +
    js.replace(/<\/script/gi, "<\\/script") +
    "</script></body></html>";
  fs.writeFileSync(
    path.join(root, "previews", film + "_PREMIUM_V2.html"),
    html,
  );
  console.log("PREVIEW", film, html.length);
}
