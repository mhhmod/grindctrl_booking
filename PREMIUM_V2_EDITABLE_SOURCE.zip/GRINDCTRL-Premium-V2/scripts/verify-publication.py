"""GET the actual published bytes; do not infer availability from git push."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib, json, zipfile
from urllib.request import urlopen

D=Path('/workspace/GRINDCTRL-PREMIUM-V2-Delivery-2026-10-23')
pub=json.loads((D/'PUBLICATION_LOCAL.json').read_text())
manifest=json.loads((D/'DELIVERY_MANIFEST.json').read_text())
base='https://raw.githubusercontent.com/'+pub['repository']+'/'+pub['commit']+'/'
required=[r for r in manifest['files'] if r['file'].endswith(('.mp4','.html','.zip')) or r['file'] in ['QA_REPORT.md','FINAL_REPORT.md'] or 'BEFORE-AFTER' in r['file']]
tmp=Path('/tmp/grindctrl-premium-v2-public-checks');tmp.mkdir(exist_ok=True)
def check(row):
    url=base+row['file']
    with urlopen(url,timeout=90) as response:
        assert response.status==200;digest=hashlib.sha256();size=0
        p=tmp/Path(row['file']).name
        with p.open('wb') as f:
            while True:
                block=response.read(1024*1024)
                if not block:break
                f.write(block);digest.update(block);size+=len(block)
        assert digest.hexdigest()==row['sha256'] and size==row['bytes'],url
    if p.suffix=='.zip':
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            inner=json.loads(z.read('GRINDCTRL-Premium-V2/SHA256SUMS.json'))
            for name,sha in inner.items():
                assert hashlib.sha256(z.read('GRINDCTRL-Premium-V2/'+name)).hexdigest()==sha
    return {'file':row['file'],'url':url,'http_status':200,'bytes':size,'sha256':digest.hexdigest(),'zip_crc_and_internal_hashes_passed':True if p.suffix=='.zip' else None}
with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(check,required))
with urlopen(base+'DELIVERY_MANIFEST.json',timeout=40) as remote:
    assert remote.status==200 and remote.read()==(D/'DELIVERY_MANIFEST.json').read_bytes()
out={'checked_utc':datetime.now(timezone.utc).isoformat(),'repository':pub['repository'],'branch':pub['branch'],'commit':pub['commit'],'method':'Actual unauthenticated HTTP GET through this cloud environment network proxy; hashes matched local final deliverables. Not an independent user-browser or external-network test. Raw HTML URLs download files, not a hosted application.','checks':results,'delivery_manifest_matches':True}
(D/'PUBLIC_DOWNLOAD_VERIFICATION_LOCAL.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'checked_files':len(results),'all_hashes_match':True,'commit':pub['commit']}))
