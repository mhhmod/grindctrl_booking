"""Package final artifacts after every media/semantic gate is complete."""
from pathlib import Path
import hashlib, json, shutil, zipfile, sys

D=Path(__file__).resolve().parent.parent
OUT=Path('/workspace/GRINDCTRL-PREMIUM-V2-Delivery-2026-10-23')
NAMES=['01_Concrete_Genesys_ZohoDesk_PREMIUM_V2','02_Concrete_Customer360_CallActivities_PREMIUM_V2','03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2']
summary=json.loads((D/'qa/FINAL_QA_SUMMARY.json').read_text())
assert len(summary['films'])==3
assert not OUT.exists(), 'Use a fresh delivery directory; do not overwrite previous delivery'
OUT.mkdir()
def copy(src, rel):
    dst=OUT/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for stem in NAMES:
    copy(D/'renders'/(stem+'.mp4'),stem+'.mp4')
for p in (D/'previews').glob('*.html'):
    copy(p,p.name)
for p in (D/'timelines').glob('*'):
    if p.suffix in ['.srt','.csv'] or p.name in ['actual_audio_cues.json','visual-shot-map.json']:
        copy(p,Path('timelines')/p.name)
for p in (D/'reviews/final').glob('*'):
    if any(key in p.name for key in ['BEFORE-AFTER','FINAL-CONTACT-SHEET','POSTER']):
        copy(p,Path('reviews/final')/p.name)
for p in (D/'qa').glob('*.json'):
    copy(p,Path('qa')/p.name)
for name in ['QA_REPORT.md','FINAL_REPORT.md','STACK_DECISION.md']:
    copy(D/name,name)
copy(D/'FINAL_REPORT.md','README.md')

# Selected source files: full production dependencies/assets, not local runtimes.
files=[]
for folder in ['src','public','previews','timelines','scripts','design-system']:
    files += [p for p in (D/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for p in (D/'research').glob('*'):
    if p.is_file() and p.suffix in ['.json','.md','.txt']:
        files.append(p)
files += [p for p in (D/'reviews/final').glob('*') if p.is_file()]
files += [D/'reviews/FORENSIC_AND_CREATIVE_REVIEW.md',D/'reviews/BASELINE_REVIEW_FRAMES.json']
files += list((D/'qa').glob('*.json'))
files += [D/name for name in ['README.md','FINAL_REPORT.md','QA_REPORT.md','STACK_DECISION.md','PRODUCTION_BRIEF.txt','package.json','package-lock.json','tsconfig.json','requirements-qa.txt']]
files=sorted(set(files))
manifest={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=OUT/'PREMIUM_V2_EDITABLE_SOURCE.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:
        z.write(p,'GRINDCTRL-Premium-V2/'+str(p.relative_to(D)))
    z.writestr('GRINDCTRL-Premium-V2/SHA256SUMS.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    inner=json.loads(z.read('GRINDCTRL-Premium-V2/SHA256SUMS.json'))
    for name,digest in inner.items():
        assert hashlib.sha256(z.read('GRINDCTRL-Premium-V2/'+name)).hexdigest()==digest
assert archive.stat().st_size<99*1024**2

inventory=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file():
        assert p.stat().st_size<99*1024**2
        inventory.append({'file':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(OUT/'DELIVERY_MANIFEST.json').write_text(json.dumps({'project':'GRINDCTRL Premium V2 — three films','repository':'mhhmod/grindctrl_booking','branch':'grindctrl-premium-v2-three-films-2026-10-22','source_archive_internal_files':len(manifest),'source_archive_crc_and_internal_hashes_passed':True,'files':inventory},indent=2))
(OUT/'SHA256SUMS.txt').write_text(''.join(r['sha256']+'  '+r['file']+'\n' for r in inventory))
print(json.dumps({'delivery':str(OUT),'files':len(inventory),'source_zip_bytes':archive.stat().st_size,'source_files':len(manifest)}))
