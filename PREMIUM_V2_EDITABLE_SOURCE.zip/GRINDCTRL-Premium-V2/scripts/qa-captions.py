from pathlib import Path
import json, re, difflib
D=Path(__file__).resolve().parent.parent
films=json.loads((D/'timelines/approved-audio-and-captions.json').read_text())
out=[]
def words(s):
    normalized=s.lower().replace('’', "'")
    normalized=re.sub(r'\bgrind\s+control\b', 'grindctrl', normalized)
    return re.findall(r"[a-z0-9]+", normalized)
for film in films:
    n=film['id'];caps=film['captions'];previous=-1
    for cap in caps:
        assert cap['start']>=previous and cap['end']>cap['start'] and cap['end']<=150
        assert cap['text'].strip() and '\ufffd' not in cap['text']
        previous=cap['end']
    srt=(D/'timelines'/(n+'.srt')).read_text()
    assert len(re.findall(r' --> ', srt))==len(caps)
    source=words((D/'timelines'/('GRINDCTRL_SCRIPT_'+n+'_EN.txt')).read_text())
    actual=words(' '.join(c['text'] for c in caps))
    edits=[{'op':op,'script':source[a:b],'caption':actual[c:d]} for op,a,b,c,d in difflib.SequenceMatcher(None,source,actual).get_opcodes() if op!='equal']
    assert not edits if n!='02' else edits==[{'op':'insert','script':[],'caption':['a']}],edits
    out.append({'film':n,'captions':len(caps),'first_start_sec':caps[0]['start'],'last_end_sec':caps[-1]['end'],'timeline_monotonic_no_overlap':True,'replacement_characters':0,'script_reconciliation':edits,'note':'Film02 retains the spoken article in “or a completed action”; labels retain correct English product spellings. Timing is automated CTC alignment, not a human-certified transcript.'})
(D/'qa/CAPTION_QA.json').write_text(json.dumps(out,indent=2))
print('CAPTION TIMELINES PASSED',len(out))
