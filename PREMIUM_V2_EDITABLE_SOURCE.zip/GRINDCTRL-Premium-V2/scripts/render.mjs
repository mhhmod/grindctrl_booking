import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderMedia,
  renderStill,
  openBrowser,
} from "@remotion/renderer";
import path from "node:path";
import fs from "node:fs";
import { execFileSync } from "node:child_process";
const root = path.resolve(import.meta.dirname, "..");
const serveUrl = process.argv.includes("--reuse-bundle")
  ? path.join(root, process.env.GRINDCTRL_BUNDLE_DIR || "build")
  : await bundle({
      entryPoint: path.join(root, "src/index.ts"),
      publicDir: path.join(root, "public"),
      outDir: path.join(root, process.env.GRINDCTRL_BUNDLE_DIR || "build"),
      onProgress: (p) => {
        if (p === 100) console.log("Bundled", p);
      },
    });
const film = process.argv.find((a) => /^0[123]$/.test(a)) || "01";
const browser = await openBrowser("chrome", {
  browserExecutable:
    process.env.GRINDCTRL_CHROMIUM_PATH ||
    (fs.existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
  chromiumOptions: { disableWebSecurity: false, gl: "swangle" },
});
const comp = await selectComposition({
  serveUrl,
  id: "Film" + film,
  puppeteerInstance: browser,
});
const prefix = {
  "01": "01_Concrete_Genesys_ZohoDesk_PREMIUM_V2",
  "02": "02_Concrete_Customer360_CallActivities_PREMIUM_V2",
  "03": "03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2",
}[film];
try {
  if (process.argv.includes("--stills")) {
    const frames = {
      "01": [90, 720, 1620, 2010, 2660, 3890, 4260],
      "02": [340, 1020, 1500, 2030, 2510, 3000, 4215],
      "03": [210, 705, 870, 1035, 1270, 2180, 2635, 4240],
    }[film];
    for (const frame of frames) {
      await renderStill({
        serveUrl,
        composition: comp,
        output: path.join(
          root,
          "reviews",
          film + "-" + String(frame).padStart(4, "0") + ".png",
        ),
        frame,
        puppeteerInstance: browser,
        imageFormat: "png",
      });
      console.log("STILL", film, frame);
    }
  } else {
    const proof = process.argv.includes("--proof");
    const ranges = {
      "01": [1350, 1709],
      "02": [1980, 2609],
      "03": [885, 1169],
    };
    const output = path.join(
      root,
      proof ? "reviews" : "renders",
      prefix + (proof ? "-proof" : "") + ".mp4",
    );
    await renderMedia({
      serveUrl,
      composition: comp,
      codec: "h264",
      outputLocation: output,
      puppeteerInstance: browser,
      concurrency: 3,
      crf: 17,
      x264Preset: "fast",
      pixelFormat: "yuv420p",
      audioCodec: "aac",
      audioBitrate: "256k",
      ...(proof ? { frameRange: ranges[film] } : {}),
      onProgress: ({
        progress,
        renderedFrames,
        encodedFrames,
        stitchStage,
      }) => {
        if (renderedFrames % 150 === 0 || progress === 1)
          console.log(
            JSON.stringify({
              film,
              progress,
              renderedFrames,
              encodedFrames,
              stitchStage,
              time: new Date().toISOString(),
            }),
          );
      },
    });
    if (!proof) {
      execFileSync(
        "python",
        [path.join(root, "scripts/finish-media.py"), film, output],
        { stdio: "inherit" },
      );
    }
    console.log("COMPLETE", output);
  }
} finally {
  await browser.close({ silent: true });
}
