"""Extract final encoded review evidence; never used to render film content."""
from pathlib import Path
import json, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

D = Path(__file__).resolve().parent.parent
NAMES = {
    '01': '01_Concrete_Genesys_ZohoDesk_PREMIUM_V2',
    '02': '02_Concrete_Customer360_CallActivities_PREMIUM_V2',
    '03': '03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2',
}
MOMENTS = {'01': [3, 24, 67], '02': [68, 83, 100], '03': [7, 34.5, 87.8]}
POSTERS = {'01': 68, '02': 84, '03': 35.5}
SHOTS = json.loads((D / 'timelines/visual-shot-map.json').read_text())
OUT = D / 'reviews/final'
OUT.mkdir(parents=True, exist_ok=True)
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font = ImageFont.truetype(FONT, 23)
small = ImageFont.truetype(FONT, 18)

def frame(n, sec, out):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(sec), '-i',
                    str(D / 'renders' / (NAMES[n] + '.mp4')), '-frames:v', '1',
                    '-q:v', '2', str(out)], check=True)
    return Image.open(out).convert('RGB')

for n in NAMES:
    if len(sys.argv) > 1 and sys.argv[1] != n:
        continue
    shots = SHOTS[n]
    canvas = Image.new('RGB', (1920, 1296), '#e9e6e1')
    draw = ImageDraw.Draw(canvas)
    draw.text((22, 10), f'FILM {n} / FINAL ENCODED MP4 / all 12 visual sequences', font=font, fill='#262626')
    records = []
    for i, shot in enumerate(shots):
        sec = round((shot['start_sec'] + shot['end_sec']) / 2, 3)
        path = OUT / f'{n}-{shot["id"]}.jpg'
        image = frame(n, sec, path)
        x, y = (i % 3) * 640 + 12, (i // 3) * 309 + 64
        image = image.resize((616, 347))
        # 16:9 tiles fit within the four-row sheet at 528 x 297.
        image = image.resize((512, 288))
        canvas.paste(image, (x + 52, y))
        draw.text((x + 52, y - 23), f'{shot["id"]} / {sec:.2f}s', font=small, fill='#262626')
        records.append({'scene': shot['id'], 'sec': sec, 'file': str(path.relative_to(D))})
    canvas.save(OUT / f'{n}-FINAL-CONTACT-SHEET.jpg', quality=93)

    comparison = Image.new('RGB', (1920, 1740), '#f6f3ee')
    draw = ImageDraw.Draw(comparison)
    draw.text((28, 17), f'FILM {n} / matching narration moments / encoded frames', font=font, fill='#262626')
    draw.text((28, 56), 'REJECTED BASELINE', font=font, fill='#77716a')
    draw.text((990, 56), 'NEW PREMIUM V2', font=font, fill='#262626')
    for i, sec in enumerate(MOMENTS[n]):
        old = Image.open(D / 'reviews/baseline' / f'{n}-{sec:g}.jpg').convert('RGB')
        after = frame(n, sec, OUT / f'{n}-comparison-{sec:g}.jpg')
        y = 118 + i * 535
        comparison.paste(old.resize((936, 527)), (12, y))
        comparison.paste(after.resize((936, 527)), (972, y))
        draw.text((30, y + 6), f'{sec:g}s', font=small, fill='#635c52')
    comparison.save(OUT / f'{n}-BEFORE-AFTER.jpg', quality=94)
    frame(n, POSTERS[n], OUT / f'{n}-POSTER.jpg')
    (OUT / f'{n}-ENCODED_REVIEW_FRAMES.json').write_text(json.dumps(records, indent=2))
    print('ENCODED REVIEW ARTIFACTS', n, flush=True)
