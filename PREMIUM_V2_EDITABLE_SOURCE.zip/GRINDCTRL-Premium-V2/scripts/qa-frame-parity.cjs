const fs = require("fs"),
  path = require("path"),
  { spawnSync } = require("child_process"),
  { chromium } = require("playwright");
const root = path.resolve(__dirname, "..");
const names = {
  "01": "01_Concrete_Genesys_ZohoDesk_PREMIUM_V2",
  "02": "02_Concrete_Customer360_CallActivities_PREMIUM_V2",
  "03": "03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2",
};
(async () => {
  const browser = await chromium.launch({
    executablePath: process.env.GRINDCTRL_CHROMIUM_PATH || "/usr/bin/chromium",
    args: [
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--autoplay-policy=no-user-gesture-required",
    ],
  });
  try {
    for (const film of Object.keys(names).filter(
      (f) => !process.argv[2] || process.argv[2] === f,
    )) {
      const dir = path.join(root, "qa/frame-parity", film);
      fs.mkdirSync(dir, { recursive: true });
      const page = await browser.newPage({
        viewport: { width: 1920, height: 1400 },
        deviceScaleFactor: 1,
      });
      await page.addInitScript(() => (window.__GRINDCTRL_QA = true));
      await page.goto(
        "http://127.0.0.1:8894/previews/" + film + "_PREMIUM_V2.html",
      );
      await page.waitForFunction(() => window.__GRINDCTRL_READY);
      await page.addStyleTag({
        content:
          "body{margin:0!important}main{max-width:none!important;width:1920px!important;padding:0!important}",
      });
      const shots = JSON.parse(
        fs.readFileSync(path.join(root, "timelines/visual-shot-map.json")),
      )[film];
      const cues = JSON.parse(
        fs.readFileSync(path.join(root, "timelines/actual_audio_cues.json")),
      )[film];
      const set = new Set([0, 1, 30, 2250, 3600, 4200, 4440, 4499]);
      for (const s of shots) {
        for (const x of [
          s.start_frame,
          s.start_frame + 5,
          s.start_frame + 22,
          Math.round((s.start_frame + s.end_frame_exclusive) / 2),
          s.end_frame_exclusive - 1,
        ])
          set.add(Math.min(4499, x));
      }
      for (const c of cues) {
        set.add(Math.max(0, c.frame - 2));
        set.add(Math.min(4499, c.frame + 12));
      }
      const frames = [...set].sort((a, b) => a - b);
      let rows = [];
      for (const frame of frames) {
        await page.evaluate((f) => window.__GRINDCTRL_PLAYER.seekTo(f), frame);
        await page.waitForFunction(
          (f) =>
            Number(document.querySelector("[data-film]").dataset.frame) === f,
          frame,
        );
        const loc = page.locator("[data-film]");
        const rect = await loc.boundingBox();
        if (Math.abs(rect.width - 1920) > 1 || Math.abs(rect.height - 1080) > 1)
          throw Error("Wrong preview size " + JSON.stringify(rect));
        const ref = path.join(dir, frame + "-preview.png");
        await loc.screenshot({ path: ref });
        const actual = path.join(dir, frame + "-encoded.png");
        let r = spawnSync(
          "ffmpeg",
          [
            "-v",
            "error",
            "-y",
            "-ss",
            Math.max(0, frame / 30 - 0.0001).toFixed(6),
            "-i",
            path.join(root, "renders", names[film] + ".mp4"),
            "-frames:v",
            "1",
            actual,
          ],
          { encoding: "utf8" },
        );
        if (r.status) throw Error(r.stderr);
        rows.push({
          frame,
          time_sec: frame / 30,
          reference: path.relative(root, ref),
          encoded: path.relative(root, actual),
        });
      }
      fs.writeFileSync(
        path.join(root, "qa", film + "-FRAME_SAMPLES.json"),
        JSON.stringify(rows, null, 2),
      );
      await page.close();
      console.log("EXTRACTED PARITY", film, frames.length);
    }
  } finally {
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
