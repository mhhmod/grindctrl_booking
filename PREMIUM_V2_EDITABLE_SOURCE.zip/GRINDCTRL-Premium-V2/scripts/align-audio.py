"""Local English CTC forced alignment; no recording leaves this environment.
Actual waveform + supplied phrase transcription. Keep model scores/uncertain terms.
This is automated alignment, not a human pronunciation certification.
"""
from pathlib import Path
import json,subprocess,torch,torchaudio,hashlib,re,time,os
D=Path(__file__).resolve().parent.parent
O=D/'timelines/ctc-alignment';O.mkdir(exist_ok=True)
torch.set_num_threads(1)
bundle=torchaudio.pipelines.WAV2VEC2_ASR_BASE_960H
model=bundle.get_model(dl_kwargs={'model_dir':os.environ.get('GRINDCTRL_ALIGN_MODEL_DIR',str(D/'.alignment-cache'))}).eval()
labels=bundle.get_labels();vocab={c:i for i,c in enumerate(labels)}
films=json.loads((D/'timelines/approved-audio-and-captions.json').read_text())
for film in films:
 n=film['id'];raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(D/'public/audio'/film['source_audio']),'-ar','16000','-ac','1','-f','f32le','-'])
 wave=torch.frombuffer(bytearray(raw),dtype=torch.float32).clone();out=[]
 # Use the original fine phrase boundaries, not equal length scenes.
 rows=json.loads((D/'timelines/alignment-phrase-transcripts.json').read_text())[n]
 for row in rows:
  a=max(0,row['start']-.1);b=min(len(wave)/16000,row['end']+.1)
  text=row['text'].upper().replace('GRINDCTRL','GRIND CONTROL').replace('GENESIS','GENESYS').replace('SOHO','ZOHO').replace('PRIVATE NODE','PRIVATE NOTE')
  text=re.sub(r"[^A-Z' ]",' ',text);words=text.split()
  transcript='|'.join(words)
  if not transcript:continue
  target=torch.tensor([[vocab[c] for c in transcript]],dtype=torch.int32)
  w=wave[round(a*16000):round(b*16000)].unsqueeze(0)
  with torch.inference_mode():emissions,_=model(w);emissions=torch.log_softmax(emissions,dim=-1)
  try:align,scores=torchaudio.functional.forced_align(emissions,target,blank=0)
  except Exception as e:out.append({'source_start':a,'source_end':b,'text':text,'error':str(e)});continue
  spans=torchaudio.functional.merge_tokens(align[0],scores[0].exp())
  ratio=(b-a)/emissions.shape[1]
  wi=0;chars=[];cur=[]
  def emit():
   if not cur:return
   word=''.join(labels[s.token] for s in cur)
   st=a+cur[0].start*ratio;en=a+cur[-1].end*ratio
   def target_time(src):
    for seg in film['narration_segments']:
     if seg['source_start_sec']-.001<=src<=seg['source_end_sec']+.001:return seg['target_start_sec']+src-seg['source_start_sec']
    return None
   out.append({'word':word,'source_start_sec':st,'source_end_sec':en,'start_sec':target_time(st),'end_sec':target_time(en),'mean_ctc_score':sum(s.score for s in cur)/len(cur),'phrase_text':row['text']})
  for s in spans:
   if labels[s.token]=='|':emit();cur=[]
   else:cur.append(s)
  emit()
  print(n,round(a,2),round(b,2),text[:65],flush=True)
 (O/(n+'-words.json')).write_text(json.dumps({'film':n,'source_sha256':hashlib.sha256((D/'public/audio'/film['source_audio']).read_bytes()).hexdigest(),'model':'torchaudio WAV2VEC2_ASR_BASE_960H','method':'automated waveform CTC forced alignment against phrase transcripts reconciled to approved English scripts; scores retained; not human certified','words':out},indent=2))
 print('ALIGNED',n,len(out),flush=True)
