const fs = require("fs"),
  path = require("path"),
  { chromium } = require("playwright");
const root = path.resolve(__dirname, "..");
const names = {
  "01": "01_Concrete_Genesys_ZohoDesk_PREMIUM_V2",
  "02": "02_Concrete_Customer360_CallActivities_PREMIUM_V2",
  "03": "03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2",
};
(async () => {
  const b = await chromium.launch({
    executablePath: process.env.GRINDCTRL_CHROMIUM_PATH || "/usr/bin/chromium",
    args: [
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--autoplay-policy=no-user-gesture-required",
    ],
  });
  try {
    for (const film of Object.keys(names).filter(
      (x) => !process.argv[2] || x === process.argv[2],
    )) {
      const p = await b.newPage();
      const file = names[film] + ".mp4";
      await p.setContent(
        '<video id="v" controls playsinline style="width:100%" src="http://127.0.0.1:8894/renders/' +
          file +
          '"></video>',
      );
      await p.evaluate(async () => {
        const v = document.querySelector("video");
        window.qa = { timeSamples: [], events: [] };
        for (const name of ["error", "ended", "stalled", "waiting", "canplay"])
          v.addEventListener(name, () =>
            qa.events.push({ name, at: v.currentTime, code: v.error?.code }),
          );
        v.addEventListener("timeupdate", () => {
          if (
            !qa.timeSamples.length ||
            v.currentTime - qa.timeSamples.at(-1) > 0.8
          )
            qa.timeSamples.push(v.currentTime);
        });
        v.muted = false;
        v.volume = 0.8;
        await v.play();
      });
      await p.waitForFunction(
        () => document.querySelector("video").ended,
        null,
        { timeout: 230000 },
      );
      const result = await p.evaluate(() => {
        const v = document.querySelector("video");
        return {
          ...qa,
          duration: v.duration,
          currentTime: v.currentTime,
          ended: v.ended,
          playbackRate: v.playbackRate,
          muted: v.muted,
          videoWidth: v.videoWidth,
          videoHeight: v.videoHeight,
          decodedFrames: v.getVideoPlaybackQuality().totalVideoFrames,
          droppedFrames: v.getVideoPlaybackQuality().droppedVideoFrames,
          audioDecodedBytes: v.webkitAudioDecodedByteCount,
          error: v.error
            ? { code: v.error.code, message: v.error.message }
            : null,
        };
      });
      if (
        result.error ||
        !result.ended ||
        result.currentTime < 149.95 ||
        result.duration !== 150
      )
        throw Error(JSON.stringify(result));
      result.method =
        "Full natural-rate unmuted software Chromium playback. Not an independent human viewing/listening session.";
      result.sha256 = require("crypto")
        .createHash("sha256")
        .update(fs.readFileSync(path.join(root, "renders", file)))
        .digest("hex");
      fs.writeFileSync(
        path.join(root, "qa", film + "-PLAYBACK_QA.json"),
        JSON.stringify(result, null, 2),
      );
      await p.close();
      console.log(
        "COMPLETE PLAYBACK",
        film,
        result.currentTime,
        result.audioDecodedBytes,
      );
    }
  } finally {
    await b.close();
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
