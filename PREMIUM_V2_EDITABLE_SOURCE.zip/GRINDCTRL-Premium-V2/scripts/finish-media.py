"""Copy rendered video and mux the authoritative mix to exactly 150 seconds.

Remotion's AAC output may expose terminal codec padding (150.016 s). We use
the same approved 150-second mix, not that re-encoded AAC, and preserve the
rendered H.264 stream byte for byte. No speech content is edited here.
"""
from pathlib import Path
import subprocess, json, hashlib, sys, os

D = Path(__file__).resolve().parent.parent
n = sys.argv[1]
p = Path(sys.argv[2]).resolve()
mix = D / 'public/audio' / (n + '-approved-mix.m4a')
out = p.with_name(p.stem + '-finished.mp4')
def video_hash(file):
    return subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(file), '-map', '0:v:0', '-c', 'copy', '-f', 'hash', '-hash', 'sha256', '-'], text=True).strip()
before = video_hash(p)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(p), '-i', str(mix), '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '256k', '-af', 'atrim=end=150,asetpts=PTS-STARTPTS', '-t', '150', '-movflags', '+faststart', str(out)], check=True)
after = video_hash(out)
assert before == after, 'Video must not be re-encoded by finishing'
meta = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(out)]))
assert float(meta['format']['duration']) == 150
assert all(float(s['duration']) == 150 for s in meta['streams'])
os.replace(out, p)
report = {'film': n, 'file': p.name, 'method': 'H.264 stream copy; authoritative approved mix encoded once for final mux; trim only terminal codec padding to150.000s. Original narration placement and words unchanged.', 'container_seconds': float(meta['format']['duration']), 'video_stream_sha256_before': before, 'video_stream_sha256_after': after, 'approved_mix_sha256': hashlib.sha256(mix.read_bytes()).hexdigest(), 'final_sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
(D / 'qa' / (n + '-FINISH_QA.json')).write_text(json.dumps(report, indent=2))
print('FINISHED EXACT150', n, flush=True)
