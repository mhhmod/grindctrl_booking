const fs = require("fs"),
  path = require("path"),
  assert = require("assert");
const { chromium } = require("playwright");
const root = path.resolve(__dirname, "..");
const checks = {
  "01": [
    [
      3,
      "Call is incoming before answer",
      (t) => t.includes("Incoming call") && !t.includes("Call connected"),
    ],
    [
      5.6,
      "Call connects on the spoken answer",
      (t) => t.includes("Call connected"),
    ],
    [22.1, "Number not yet marked copied", (t) => !t.includes("Copied")],
    [22.8, "Number copied on actual spoken copy", (t) => t.includes("Copied")],
    [
      43.5,
      "No customer history during lookup",
      (t) => !t.includes("Ahmed M.") && !t.includes("DESK-2048"),
    ],
    [
      56.6,
      "Pending status and recorded update visible",
      (t) =>
        t.includes("Pending branch review") &&
        t.includes("Awaiting branch review."),
    ],
    [
      80.5,
      "Ambiguous match hides ticket history",
      (t) =>
        t.includes("Choose the correct record") && !t.includes("DESK-2048"),
    ],
    [
      88.6,
      "Lookup failure preserves call",
      (t) =>
        t.includes("Lookup temporarily unavailable") &&
        t.includes(" · Connected") &&
        t.includes("Call continues"),
    ],
    [
      93.5,
      "Phone is not identity",
      (t) => t.includes("lookup key") && t.includes("Verified identity"),
    ],
  ],
  "02": [
    [
      28.8,
      "Private profile withheld before match",
      (t) => !t.includes("Ahmed M.") && !t.includes("ahmed@example.com"),
    ],
    [
      36,
      "Permitted customer profile fields",
      (t) => t.includes("Ahmed M.") && t.includes("ahmed@example.com"),
    ],
    [
      50.5,
      "Trusted-source tier example, no entitlement",
      (t) =>
        t.includes("Elite") &&
        t.includes("Authoritative membership data required"),
    ],
    [
      84,
      "Historical note retains original call/author",
      (_, n) =>
        n.some((x) => x.call === "CALL-101" && x.author === "Maya") &&
        !n.some((x) => x.call === "CALL-102" && x.author === "Maya"),
    ],
    [
      100.7,
      "New note linked only to current interaction",
      (_, n) =>
        n.some((x) => x.call === "CALL-102" && x.author === "Salma") &&
        !n.some((x) => x.call === "CALL-101"),
    ],
    [
      106,
      "Permission limitation hides notes",
      (t, n) => t.includes("Access restricted") && n.length === 0,
    ],
    [
      116.5,
      "Missing tier explicitly unavailable",
      (t) => t.includes("unavailable") && !t.includes("VIP"),
    ],
    [
      119.7,
      "Lookup failure never blocks call",
      (t) =>
        t.includes(" · Connected") &&
        t.includes("Call continues") &&
        t.includes("Lookup temporarily unavailable"),
    ],
    [
      140,
      "Later call reads Salma note without reassignment",
      (t, n) =>
        t.includes("CALL-103") &&
        t.includes("Youssef") &&
        n.some((x) => x.call === "CALL-102" && x.author === "Salma") &&
        !n.some((x) => x.call === "CALL-103"),
    ],
  ],
  "03": [
    [
      28,
      "No uploaded photo before actual upload word",
      (t) => !t.includes("Photo added"),
    ],
    [
      28.9,
      "Uploaded photo paired with selected garment",
      (t) => t.includes("Photo added") && t.includes("Navy linen overshirt"),
    ],
    [
      34,
      "Preview clearly authored demonstration",
      (t) =>
        t.includes("Illustrative preview / same person") &&
        t.includes("Same garment"),
    ],
    [
      44.5,
      "No exact-fit claim",
      (t) => t.includes("Not an exact measurement or fit guarantee."),
    ],
    [
      72.6,
      "Answer grounded in merchant content",
      (t) => t.includes("STORE KNOWLEDGE / DEMO CONTENT"),
    ],
    [
      86.8,
      "Conversation assigned to fictional human",
      (t) => t.includes("Assigned to Lina"),
    ],
    [
      88.5,
      "Private note only team-visible",
      (t) => t.includes("PRIVATE NOTE / LINA / TEAM ONLY"),
    ],
    [
      89.6,
      "Human reply in existing thread",
      (t) =>
        t.includes("LINA / HUMAN REPLY") &&
        t.includes("Earlier conversation remains"),
    ],
    [
      97,
      "Conditional verified read-only context",
      (t) =>
        t.includes("Read only") &&
        t.includes("No order edits or refund promises."),
    ],
    [
      145,
      "Correct official brand spelling",
      (t) => t.includes("GRINDCTRL") && t.includes("Let shoppers see it."),
    ],
  ],
};
(async () => {
  const browser = await chromium.launch({
    executablePath: process.env.GRINDCTRL_CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  let all = [];
  for (const film of ["01", "02", "03"]) {
    const page = await browser.newPage({
      viewport: { width: 1600, height: 1100 },
    });
    await page.goto(
      "http://127.0.0.1:8894/previews/" + film + "_PREMIUM_V2.html",
    );
    await page.waitForFunction(() => window.__GRINDCTRL_READY, null, {
      timeout: 60000,
    });
    for (const [sec, label, fn] of checks[film]) {
      await page.evaluate(
        (f) => window.__GRINDCTRL_PLAYER.seekTo(f),
        Math.round(sec * 30),
      );
      await page.waitForTimeout(70);
      const state = await page.evaluate(() => {
        const r = document.querySelector("[data-film]");
        const scenes = r.querySelectorAll("[data-scene]");
        const s = scenes[scenes.length - 1];
        function visible(n) {
          for (let a = n; a && a !== s; a = a.parentElement)
            if (Number(getComputedStyle(a).opacity) < 0.01) return false;
          return true;
        }
        return {
          text: s.innerText,
          notes: [...s.querySelectorAll("[data-note-call]")]
            .filter(visible)
            .map((e) => ({
              call: e.dataset.noteCall,
              author: e.dataset.noteAuthor,
              text: e.innerText,
            })),
        };
      });
      const pass = fn(state.text, state.notes);
      all.push({ film, sec, label, pass });
      if (!pass) console.log("FAIL", film, sec, label, state.text, state.notes);
    }
    const fonts = await page.evaluate(() => ({
      loaded: document.fonts.check("400 30px Geist"),
      buttons: [...document.querySelectorAll("nav button")].map((x) => ({
        label: x.textContent,
        height: x.getBoundingClientRect().height,
      })),
      audio: [...document.querySelectorAll("audio")].map((a) => ({
        src: a.src.slice(0, 35),
        ready: a.readyState,
      })),
    }));
    assert(fonts.loaded, "Font not loaded");
    await page.close();
  }
  const reduced = await browser.newPage({
    viewport: { width: 390, height: 800 },
    reducedMotion: "reduce",
  });
  await reduced.goto("http://127.0.0.1:8894/previews/01_PREMIUM_V2.html");
  await reduced.waitForFunction(() => window.__GRINDCTRL_READY);
  assert(
    (await reduced
      .getByRole("button", { name: "Static step mode on", exact: true })
      .count()) === 1,
  );
  await reduced.close();
  await browser.close();
  fs.writeFileSync(
    path.join(root, "qa/STATE_GUARDS.json"),
    JSON.stringify(
      {
        checks: all,
        reducedMotionStartsPaused: true,
        allPassed: all.every((x) => x.pass),
      },
      null,
      2,
    ),
  );
  assert(
    all.every((x) => x.pass),
    "State guards failed",
  );
  console.log("ALL STATE GUARDS PASSED", all.length);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
