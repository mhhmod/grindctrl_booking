"""Write reports only from completed, mutually matching final QA artifacts."""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib

D=Path(__file__).resolve().parent.parent
names={'01':'01_Concrete_Genesys_ZohoDesk_PREMIUM_V2','02':'02_Concrete_Customer360_CallActivities_PREMIUM_V2','03':'03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2'}
def read(path):return json.loads((D/path).read_text())
rows=[]
for n,stem in names.items():
    media=read('qa/'+n+'-MEDIA_QA.json');play=read('qa/'+n+'-PLAYBACK_QA.json');parity=read('qa/'+n+'-FRAME_PARITY_QA.json');finish=read('qa/'+n+'-FINISH_QA.json')
    sha=hashlib.sha256((D/'renders'/(stem+'.mp4')).read_bytes()).hexdigest()
    assert media['sha256']==play['sha256']==parity['sha256']==finish['final_sha256']==sha
    assert media['video']['duration']==play['duration']==finish['container_seconds']==150
    assert media['video']['decoded_frames']==4500 and play['ended'] and play['error'] is None
    assert parity['max_mean_absolute_pixel_error_255']<3
    assert parity['preview_sha256']==hashlib.sha256((D/'previews'/(n+'_PREMIUM_V2.html')).read_bytes()).hexdigest()
    assert finish['video_stream_sha256_before']==finish['video_stream_sha256_after']==parity['h264_stream_sha256']
    assert (D/'reviews/final'/(n+'-FINAL-CONTACT-SHEET.jpg')).exists()
    rows.append({'film':n,'file':stem+'.mp4','media':media,'playback':play,'parity':{k:v for k,v in parity.items() if k!='frames'},'finish':finish})
assert read('qa/STATE_GUARDS.json')['allPassed']
for preview in read('qa/PREVIEW_QA.json'):
    assert not preview['errors'] and preview['sampledStates']==60
    assert not any(state['overflow'] for state in preview['states'])
    assert preview['mobile']['scroll']==preview['mobile']['width']==390 and preview['mobile']['buttons']
assert all(row['timeline_monotonic_no_overlap'] for row in read('qa/CAPTION_QA.json'))
for offline in read('qa/OFFLINE_PREVIEW_QA.json'):
    assert not offline['externalRequests'] and not offline['errors'] and offline['fontLoaded'] and offline['frame']>5
stamp=datetime.now(timezone.utc).isoformat()
(D/'qa/FINAL_QA_SUMMARY.json').write_text(json.dumps({'completed_utc':stamp,'films':rows,'external_human_user_test':False,'independent_human_listening_session':False},indent=2))
table='\n'.join(f"| {r['film']} | 150.000 s | 4500 | 1920×1080 / 30 fps | H.264 / AAC | {r['media']['audio']['lufs']:.2f} | {r['media']['audio']['true_peak_dbtp']:.2f} |" for r in rows)
detail='\n'.join(f"- Film {r['film']}: {r['parity']['samples']} encoded/HTML frame pairs; maximum mean pixel error {r['parity']['max_mean_absolute_pixel_error_255']:.3f}/255. Original-voice correlation minimum {r['media']['audio']['minimum_original_voice_correlation']:.5f}; maximum sampled alignment lag {r['media']['audio']['max_alignment_lag_samples']} samples at 44.1 kHz. Full browser playback reached {r['playback']['currentTime']:.3f}s; dropped frames {r['playback']['droppedFrames']}." for r in rows)
qa=f'''# Premium V2 — final QA

Completed {stamp}. These results describe the actual delivered files, not just source previews. Media, playback, finishing and parity reports are bound to each final MP4 SHA256.

## Technical results

| Film | Video, audio and container duration | Frames | Picture | Codecs | LUFS-I | True peak dBTP |
|---|---|---|---|---|---|---|
{table}

All three files decoded completely through FFmpeg with no decode errors and no detected full-black sequences. The final mux copies H.264 unchanged and encodes the authoritative mix to an exact 150.000-second endpoint. An initial playback check caught 150.016 s of AAC terminal padding; that failed intermediate is not delivered.

{detail}

The standalone previews were checked at 60 seek states per film, with zero detected text clipping, no JavaScript errors, no horizontal page overflow at 390 px, and usable external controls. 28 semantic state guards passed: permission/matching gates, call continuity on lookup failure, original call-note ownership, distinct record types, conditional read-only order context, correct brand spelling and a paused reduced-motion startup. Explicit playback enables motion; reduced-motion mode is not represented as eliminating all animation while playing.

Actual encoded frame samples cover every scene boundary, scene centers, critical spoken-event cues, beginning, middle and final 30 seconds. Full natural-rate unmuted Chromium playback exercised each entire 150-second file. Initial simultaneous-render browser runs reported 9 dropped display frames for Film02 and 1 for Film03 despite complete 4500-frame encoded files. Those runs are retained as PLAYBACK_UNDER_RENDER_LOAD.json; a final playback was repeated after rendering/parity extraction stopped. The final counters above report that run without hiding the earlier measurements. Software playback is not a claim that a separate human listened to all seven-and-a-half minutes.

## Audio and subtitles

Original supplied MP3 bytes and decoded-sample inventories are preserved. Local waveform CTC forced alignment was reconciled to the approved scripts; confidence scores and actual word times are included. No new narration, speed or pitch change was made. Film01 retains 147.760 s of decoded narration; Film02 retains 144.880 s; Film03 retains 138.880 s in order. The user explicitly authorized Film03’s 11.12 s of distributed purposeful visual time, including three 2-second intervals at semantic pauses; no words were removed or reordered.

Subtitles and important UI events use the measured audio. Caption timelines are monotonic, non-overlapping and within the150-second edit. Film02 preserves the spoken article in “or a completed action.” Proper English names remain GRINDCTRL, Genesys and Zoho Desk. Timing is machine aligned with assistant transcript review, not independently human-certified pronunciation or subtitle accuracy.

## Creative inspection, separate from technical passes

Assistant visual inspection covered full-resolution style/proof frames, all 36 scene-center compositions, final encoded contact sheets, selected full-size encoded scenes, critical interaction sequences and matching before/after frames. Observed corrections include a face-preserving Try-On reveal, larger contextual UI, constrained activity expansion, explicit original-note authorship, compact handoff composition, removal of a chat-input annotation overlap, and speech-driven system/context focus in Film01. See reviews/FORENSIC_AND_CREATIVE_REVIEW.md for the specific changes.

Film01 uses manual copy/search, permitted lookup, ticket focus and fallback states. Film02 uses profile → independent call timeline → selected original note → current-call writing → later retrieval. Film03 changes to editorial garment/portrait composition, product-page interaction, photo upload, authored visual reveal, meaningful merchant-content answer and human shared-inbox handoff. This is a new Remotion production, not the prior cached SVG/JPEG-state engine. Readable record holds are intentional; motion sampling is descriptive and is not used to award a perfect creative score.

## Limits and evidence

No external user comprehension study, independent creative panel, complete human audition or Concrete tenant test occurred. The customer/call/order/product records are fictional. Genesys/Zoho UI is a vendor-informed proposed context experience, not verified tenant UI. Call-note storage, original-author retention, membership source, permissions and existing contracted URL-pop configuration still require authorized discovery. The Try-On imagery is synthetic artwork, not proof of exact fit or measured live engine output. No savings, merchant stock or operational integration is invented.

Requested websites that were blocked and Zoho's article-less application shell are explicitly recorded in research/access.json. Accessible official repository documentation and authorized local application source are distinguished in the evidence ledger. Remotion licensing and font rights are recorded in STACK_DECISION.md and the included original license texts.

The HTML embeds its image, font and audio assets. Direct file:// navigation was blocked by this managed Chromium administrator policy and was not bypassed. A local-server test allowed only the initial document request and blocked subsequent HTTP(S) assets, verifying self-contained playback; direct file opening on the recipient’s browser remains unverified here. If a browser blocks local HTML, serve the downloaded folder with `python -m http.server`.

Raw parity frame pairs remain in the working workspace to avoid an excessive archive; JSON measurements, full-resolution representative final frames, final contact sheets and before/after comparisons are included. All production sources and assets required to reproduce the films are included; node_modules, model weights, virtual environments, compiled builds, private contracts and unrelated application files are excluded.
'''
(D/'QA_REPORT.md').write_text(qa)
sources=read('qa/AUDIO_SOURCE_VERIFICATION.json')
audio_table='\n'.join(f"| {s['film']} | {s['container_duration']:.6f} | {s['decoded_seconds']:.3f} | `{s['sha256']}` |" for s in sources)
report=f'''# GRINDCTRL — three premium films, V2

Three complete new films are delivered, each 150 seconds, 1920×1080, 30 fps, 4500 frames, H.264 with AAC audio. The prior files and production application are preserved. The output source is Remotion 4.0.538 + React 19.3.1 + TypeScript, with editable components, motion primitives, scene modules and measured audio cues.

## Direct files

1. [Genesys + Zoho Desk](01_Concrete_Genesys_ZohoDesk_PREMIUM_V2.mp4)
2. [Customer360 / Call Activities](02_Concrete_Customer360_CallActivities_PREMIUM_V2.mp4)
3. [Virtual Try-On + Store Chat](03_GRINDCTRL_TryOn_StoreChat_PREMIUM_V2.mp4)

Download [PREMIUM_V2_EDITABLE_SOURCE.zip](PREMIUM_V2_EDITABLE_SOURCE.zip) for the complete project, original narration, approved mixes, standalone HTML previews, SRT, measured cues, assets, reports and build scripts. HTML files open locally after downloading; raw GitHub links are not represented as hosted web apps.

## What changed

The rejected renderer cached SVG screenshots by visual-state key, leaving repeated fixed-window compositions and weak movement. V2 uses actual Remotion frame rendering, 12 major sequences per film, native editable React/CSS UI, measured type/search/copy/lookup/note/upload/reply states, intentional camera changes and different employee/retail compositions. The story remains employee-first; systems support the experience. The new source lets a designer change typography, fields, timing and motion without rewriting a rendering engine.

New fictional navy-linen photography was generated as a consistent material-led product family. The worn portrait was conditioned on the selected garment; the before portrait was edited from that same result. The result uses a face-preserving comparison reveal, not a distorted crop or a claim of exact body measurements. The Store Chat example now provides a useful merchant-fixture-grounded answer and retains context through a reasoned human handoff.

Compare the actual encoded narrative moments in [Film01 before/after](reviews/final/01-BEFORE-AFTER.jpg), [Film02 before/after](reviews/final/02-BEFORE-AFTER.jpg) and [Film03 before/after](reviews/final/03-BEFORE-AFTER.jpg). Separate final contact sheets show every major scene. These are concrete review evidence, not a perfect-score creative claim.

## Original audio

| Film | Source MP3 container seconds | Decoded narration seconds | Original SHA256 |
|---|---|---|---|
{audio_table}

The original English recordings are unchanged. Film03 uses the user's explicit 11.12-second visual-time exception; all voice content remains once and in order. Actual phrase/word timings, confidence values and animation triggers are in timelines/. No new voice credits were spent.

## Scope and research

Official Genesys Client Apps SDK and Conversations API guidance were accessible and inspected; vendor help pages and Concrete live screens were not available. Official Remotion/Motion/GSAP/Rive/R3F/Blender references were inspected through accessible repositories where public sites were blocked. Authorized local GRINDCTRL source and supplied proofs informed branding and product patterns. These evidence classes are kept separate. No public-site access or installed tenant feature is fabricated.

The Concrete films propose a new collaboration. Manual Zoho Desk phone search is user-reported. The 2023 contracted CRM URL-pop scope requires inspection before choosing new infrastructure. Phone matching is not identity verification. Membership source, note storage, individual call association, retention, author preservation and permissions remain discovery items. Human call notes are distinct from ticket notes and AI summaries. The fashion film uses a fictional merchant and authored illustrations; conditional order lookup is read-only and requires configuration/verification.

## Verification and remaining limits

See [QA_REPORT.md](QA_REPORT.md) for full decode, exact media durations, original-voice waveform comparisons, natural-rate software playback, encoded/HTML frame parity, semantic guards, layout checks, creative observations and corrections. Reports and SHA256 manifests reference final files. No actual Concrete integration, pilot outcome, quantified savings, independent user testing or full human audition is claimed.

Remotion has entity-dependent commercial licensing; the original terms and font license are included. The artifact-only branch does not modify main, deploy the site or contain private contracts. Later authorized UI captures can replace the separated CallCard, TicketWorkspace, Activity/OwnedNote and fashion/inbox components while preserving field-source, access and ownership gates.
'''
base='https://raw.githubusercontent.com/mhhmod/grindctrl_booking/grindctrl-premium-v2-three-films-2026-10-22/'
for file in [stem+'.mp4' for stem in names.values()]+['PREMIUM_V2_EDITABLE_SOURCE.zip']:
    report=report.replace(']('+file+')',']('+base+file+')')
(D/'FINAL_REPORT.md').write_text(report)
print('FINAL REPORTS WRITTEN',stamp)
