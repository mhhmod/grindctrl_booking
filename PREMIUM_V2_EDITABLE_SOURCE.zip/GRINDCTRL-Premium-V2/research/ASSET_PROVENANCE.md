# Assets and permissions

- GRINDCTRL, Genesys and Zoho marks: existing supplied project assets, copied unchanged; no logo synthesis. Concrete is a typed name, not an invented logo. All marks remain their owners’ marks and indicate the proposed/system context.
- Geist variable Latin font: @fontsource-variable/geist5.3.0; original SIL Open Font License included at public/approved/Geist-OFL.txt. No runtime font requests.
- New navy linen hero: image-generation tool, fictional product,1024×1536, /workspace/generated_images/exec-e4cc4375-466a-4c8d-90dc-79643c90ae2d.png. New creation directed for washed slub linen, one left chest patch pocket, pointed collar, dark horn buttons and soft studio lighting.
- Worn result portrait: reference-conditioned image generation from that exact garment, /workspace/generated_images/exec-29d5b50c-950b-4a29-aeae-08609ef519e3.png. Fictional adult, neutral pose/ivory tee/stone trousers.
- Before portrait: image-tool edit of the result portrait to remove only the overshirt, /workspace/generated_images/exec-38f3e85f-6729-4ae8-b36d-636f4a2422ff.png. Face/pose/lighting and garment relationship visually inspected. No body-shaping or exact-fit claim. Generative photorealism is not a garment measurement/engine benchmark.
- Full-resolution photographs reviewed for face consistency, one-pocket construction, collar/cuffs/buttons, textile texture and obvious anatomy artifacts. A face-preserving contain composition replaces the initial over-wide cropped result.
- Existing approved English MP3s: unchanged originals, SHA256/sample inventory at qa/AUDIO_SOURCE_VERIFICATION.json. No voice generation, speed change, pitch shift or word deletion.
-150-second narration/music mixes: existing original procedural ambient/piano score and selective soft taps from the supplied project; no stock music or unlicensed recording added. Whole-mix loudness control only. Source original MP3s included for independent re-finishing. No claim that a mixed AAC file is byte-identical to the original MP3.
- Local wav2vec2/torchaudio model is used for alignment, not voice synthesis. Model/venv/cache not included in deliverables; JSON outputs and optional alignment script are included.
- Private contracts, signatures, original fees, credentials and unrelated application files are excluded from publication. Old encoded frames appear only in labelled before/after review comparisons, never as V2 film footage.

The Store Chat fit-description example comes from the explicitly fictional merchant-knowledge fixture at timelines/FICTIONAL_MERCHANT_KNOWLEDGE.json. It is not a claim that Concrete or another live merchant approved that product description. No current prices, inventory or delivery promises are authored.
