# Evidence ledger / UI fidelity — Premium V2

## Classification

| Item | Evidence class | What is established / not established |
|---|---|---|
| Employees can manually search Zoho Desk by phone | Confirmed existing behaviour **as reported by the user** | Conversation evidence only. No independently observed tenant test. |
| Existing Genesys “CRM URL pop up integration” | Contracted, deployment unverified | Original29Nov2023 contract: page4, AnnexA Services1(i). Existing configuration/native capacity must be inspected first. This is not proof that a Zoho integration is deployed. Private contract pages are not redistributed. |
| Genesys client-app UI extension | Official vendor-supported capability | Official Client Apps SDK README was accessible/read. HTTPS/iframe UI integration and separate platform data APIs; app-display groups are not a replacement for server authorization. Concrete’s product edition, version, configuration, scopes and mechanism remain unknown. |
| Genesys platform conversation/wrap-up API | Official vendor-supported capability | Official ConversationsApi documentation was accessible. Conversation/participant/communication scope does not establish a universal historic note store or a tenant-retention policy. No API call against Concrete was made. |
| Exact screen-pop configuration / field geography | Proposed integration / unknown | Genesys help was blocked. A clearly labelled separate proposed URL context window is used. No fictional native Genesys panel is passed off as an installed component. Existing supported URL-pop configuration should be audited before new infrastructure. |
| Zoho Desk tickets / contact context | Existing system reported by user; interface illustrative | Official help returned application-shell HTML without article text. Desk is not treated as Zoho CRM. The film’s ticket UI is a focused illustrative reconstruction, not an authorized Concrete screenshot. |
| Zoho Call Activities, original human notes and write flow | Proposed integration / unknown storage | The activities/calls help page could not be read beyond its SPA shell. Actual per-call source, write API, association keys, original authorship, retention and permissions must be verified. No existing cross-system call-note sync is claimed. |
| Customer phone/name/email | Proposed permissioned view | Fictional Ahmed M./example.com/masked Egyptian number. A phone key is not identity. Multiple/no match, access restriction, missing field and lookup failure keep private history hidden. Voice channel remains available. |
| Icons Club Lifestyle / Prestige / Elite | User-supplied confirmed vocabulary; source unknown | Tier is only shown as a fictional trusted-source example. Membership source/freshness/visibility must be verified. No invented entitlements or inference from phone. |
| GRINDCTRL visual identity | Authorized repository evidence | apps/web-next/DESIGN.md: warm cream/charcoal and Geist/Inter. Source logo reused with plain brand wordmark. This informs visual consistency, not live product verification. |
| GRINDCTRL Try-On product flow | Authorized source-code / supplied visual references | Read app/try-on/page.tsx, lib/try-on/types.ts and existing proof assets/manifest. Product selection, customer photo, signed session/job concepts and result states exist in source. This is not a production API call or a verification of the public deployment. |
| Store Chat / shared inbox | Authorized source-code / supplied visual references | Read local components/shopify/store-chat-embedded.tsx and dashboard/inbox-workspace.tsx; inspected existing inbox proof. Assignment, handoff reason and conversation context have source-level evidence. Mocked film interaction is fictional; operational access/settings not verified. |
| Shopify storefront / conditional order context | Illustrative demonstration / deployment unknown | Official public Shopify documentation attempt blocked; official Shopify app-template README accessible/read for app structure only. No merchant installation, Shopify order source, access token or enabled order integration is asserted. Read-only example requires verification/configuration. |
| Fashion people/products/result images | Illustrative synthetic demonstration | Newly generated editorial artwork and reference-conditioned edits. Not actual Concrete products, customer photos or measured engine output. Preview does not prove body dimensions or exact fit. |

## Scope and records

GRINDCTRL proposes a new collaboration. Concrete is not presented as an implemented GRINDCTRL client. No tenant screenshot or permissioned production record was supplied. No actual savings, stock, entitlements, pilot results or deployed integration is fabricated.

Original note ownership:

- CALL-101:15Oct2026,11:08,Maya. Human note11:12: customer requested an exchange; branch review pending.
- CALL-102:22Oct2026,14:32,Salma. New human note14:39: customer followed up, awaiting a confirmed branch update.
- CALL-103:29Oct2026,Youssef reads the original CALL-102/Salma note. Reading does not reassign its author or ownership.
- Ticket DESK-2048’s recorded pending branch review is distinct from these call notes, an AI summary, a recording, a transcript or an approved action.

## Authorized later fidelity pass

Replace only the relevant React presentation components using authorized/anonymized captures, with edition/version/date/rights recorded. Components are separated: CallCard/CallStrip, TicketWorkspace/TicketNote, ActivityRow/OwnedNote, ProductPage/ShopperChat/Inbox. Preserve timeline semantic hooks, matching/access gates and note ownership. This is an edit-friendly structure, not an assertion that a live screenshot adapter is already integrated.

## Actual access limits

research/access.json records every requested URL,403 and404. Official Remotion/Motion/GSAP/Rive/R3F/Blender/Inter documentation was read through accessible official repositories. Apple HIG and the requested public GRINDCTRL/Concrete pages were blocked. No inaccessible article is counted as completed research. The browser-like UI is deliberately an illustrative concept wherever operational evidence is absent.
