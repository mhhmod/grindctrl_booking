import { cue } from "../../motion/cues";
import React from "react";
import { AbsoluteFill } from "remotion";
import { C, shadow } from "../../design-system/tokens";
import {
  Box,
  Window,
  Logo,
  Label,
  Avatar,
  Badge,
  Button,
  Tabs,
  Title,
  Eyebrow,
  Field,
} from "../../components/Primitives";
import {
  CallCard,
  CallStrip,
  PersonHeader,
  SearchField,
  TicketWorkspace,
  TicketRow,
  TicketNote,
  PHONE,
} from "../../components/ContactCenter";
import { Icon } from "../../components/Icons";
import {
  Camera,
  Cursor,
  damp,
  ease,
  mix,
  p,
  reveal,
  typing,
  Scene,
} from "../../motion/primitives";
export const film01Shots = [
  { id: "arrival", start: 0, end: 10.476, title: "Incoming call" },
  {
    id: "missing",
    start: 10.476,
    end: 17.73,
    title: "Context exists elsewhere",
  },
  { id: "manual", start: 17.73, end: 25.804, title: "Copy and search" },
  {
    id: "history",
    start: 25.804,
    end: 35.938,
    title: "Find the latest update",
  },
  { id: "lookup", start: 35.938, end: 47.203, title: "Authorized lookup" },
  { id: "pop", start: 47.203, end: 57.033, title: "Customer context opens" },
  {
    id: "exchange",
    start: 57.033,
    end: 79.126,
    title: "Continue from a recorded status",
  },
  { id: "fallback", start: 79.126, end: 95.192, title: "Safe fallback" },
  {
    id: "connect",
    start: 95.192,
    end: 108.766,
    title: "Build on existing systems",
  },
  { id: "value", start: 108.766, end: 122.001, title: "Validate the benefit" },
  {
    id: "pilot",
    start: 122.001,
    end: 136.66,
    title: "Inspect before implementation",
  },
  {
    id: "close",
    start: 136.66,
    end: 150,
    title: "Context ready for the conversation",
  },
];
const NotePreview = ({ t }: { t: number }) => (
  <div
    style={{
      padding: 34,
      background: "#f9f7f1",
      border: "1px solid #e4dccd",
      borderRadius: 13,
    }}
  >
    <Badge tone="amber" icon="clock">
      Pending branch review
    </Badge>
    <div
      style={{
        fontSize: 38,
        lineHeight: 1.3,
        letterSpacing: -0.7,
        marginTop: 26,
      }}
    >
      Awaiting branch review.
    </div>
    <Label style={{ marginTop: 17 }}>Latest recorded update · DESK-2048</Label>
  </div>
);
export const Arrival = ({ t }: { t: number }) => {
  const answer = ease(t, cue("01", "call_answer"), 0.7);
  return (
    <>
      <Box x={110} y={215} w={650}>
        <Eyebrow>Concrete Customer Service</Eyebrow>
        <Title size={88} style={{ marginTop: 32 }}>
          A call.
          <br />
          An earlier story.
        </Title>
        <div
          style={{ height: 1, width: 130, background: C.line, marginTop: 32 }}
        />
        <Label style={{ fontSize: 29, marginTop: 25 }}>
          One customer. An exchange follow-up.
        </Label>
        <div style={{ marginTop: 29, ...reveal(t, 6.366) }}>
          <Badge tone="amber" icon="clock">
            From last week
          </Badge>
        </div>
      </Box>
      <Box
        x={1020 - mix(0, 45, answer)}
        y={165 + mix(0, 15, answer)}
        style={{
          transform: `perspective(1800px) rotateY(${mix(-5, 0, answer)}deg)`,
          transformOrigin: "left center",
        }}
      >
        <CallCard
          t={t}
          incoming={t < cue("01", "call_answer")}
          style={{ width: 640 }}
        />
      </Box>
      <Cursor
        t={t}
        points={[
          [3, 1540, 720],
          [4.65, 1315, 697],
          [4.95, 1315, 697],
          [5.5, 1440, 760],
        ]}
        clicks={[cue("01", "call_answer")]}
      />
    </>
  );
};
export const Missing = ({ t }: { t: number }) => (
  <>
    <Box x={105} y={150}>
      <Eyebrow>Reported current workflow</Eyebrow>
      <Title size={54} style={{ marginTop: 18 }}>
        The history exists. Elsewhere.
      </Title>
    </Box>
    <Camera
      t={t}
      start={10.476}
      end={17.6}
      from={[0, 0, 0.98]}
      to={[-18, -2, 1.025]}
    >
      <Box x={113} y={300}>
        <CallCard t={t} compact />
      </Box>
      <Box x={575} y={278} w={1230}>
        <Window vendor="zoho" tag="TICKETING / ILLUSTRATIVE">
          <div style={{ padding: 38 }}>
            <SearchField />
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 20,
                marginTop: 49,
              }}
            >
              <div
                style={{
                  width: 68,
                  height: 68,
                  borderRadius: 18,
                  background: C.soft,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icon name="folder" size={32} color={C.muted} />
              </div>
              <div>
                <div style={{ fontSize: 35, letterSpacing: -0.8 }}>
                  Find customer history
                </div>
                <Label style={{ marginTop: 8 }}>
                  Search using the caller’s phone number.
                </Label>
              </div>
            </div>
            <div
              style={{ marginTop: 45, display: "flex", gap: 16, opacity: 0.45 }}
            >
              {[0.8, 0.6, 0.35].map((v, i) => (
                <div
                  key={i}
                  style={{
                    height: 9,
                    borderRadius: 3,
                    background: C.line,
                    width: 200 * v,
                  }}
                />
              ))}
            </div>
            <div
              style={{
                marginTop: 49,
                paddingTop: 24,
                borderTop: `1px solid ${C.line}`,
                display: "flex",
                justifyContent: "space-between",
                fontSize: 23,
                color: C.muted,
              }}
            >
              <span>Customer record</span>
              <span>Tickets</span>
              <span>Latest update</span>
            </div>
          </div>
        </Window>
      </Box>
    </Camera>
  </>
);
export const Manual = ({ t }: { t: number }) => {
  const copied = t >= cue("01", "manual_copy"),
    search = t >= cue("01", "manual_search");
  return (
    <>
      <Box x={110} y={141}>
        <Eyebrow>Existing workflow / manual search</Eyebrow>
      </Box>
      <Window
        title="Concrete / employee desktop"
        tag="ILLUSTRATIVE DEMO"
        style={{
          position: "absolute",
          left: 100,
          top: 192,
          width: 1720,
          height: 703,
        }}
      >
        <div style={{ display: "flex", height: 639 }}>
          <div
            style={{
              width: 370,
              padding: 30,
              background: "#f7f8f4",
              borderRight: `1px solid ${C.line}`,
            }}
          >
            <Logo vendor="genesys" height={28} />
            <div style={{ marginTop: 29 }}>
              <Badge tone="green" icon="phone">
                Call connected
              </Badge>
            </div>
            <Label style={{ marginTop: 38 }}>Caller number</Label>
            <div
              style={{
                marginTop: 15,
                padding: "17px 10px",
                background: copied ? "#e8dec8" : "#fff",
                border: `1px solid ${copied ? "#cbb996" : C.line}`,
                borderRadius: 9,
                fontSize: 28,
                whiteSpace: "nowrap",
              }}
            >
              {PHONE}
            </div>
            <div
              style={{
                display: "flex",
                gap: 12,
                alignItems: "center",
                fontSize: 24,
                color: copied ? C.green : C.muted,
                marginTop: 23,
              }}
            >
              <Icon name={copied ? "check" : "copy"} />
              {copied ? "Copied" : "Copy phone number"}
            </div>
            <div style={{ marginTop: 48, fontSize: 23, color: C.muted }}>
              Salma · CALL-102
            </div>
            <div style={{ marginTop: 44, display: "flex", gap: 16 }}>
              {["mic", "pause", "phone"].map((n) => (
                <Icon
                  key={n}
                  name={n}
                  size={28}
                  color={n === "phone" ? C.red : C.muted}
                />
              ))}
            </div>
          </div>
          <div style={{ flex: 1, padding: "31px 42px" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Logo vendor="zoho" height={28} />
              <Label>Tickets / Contacts</Label>
            </div>
            <div style={{ marginTop: 34 }}>
              <SearchField
                focus={search}
                text={
                  search
                    ? typing(PHONE, t, cue("01", "manual_search"), 1.25)
                    : ""
                }
              />
            </div>
            <div style={{ marginTop: 70, textAlign: "center", color: C.muted }}>
              <Icon name="search" size={54} color="#c6c0b5" />
              <div style={{ fontSize: 31, marginTop: 20 }}>
                {search
                  ? "Searching existing records"
                  : "Customer history is not yet open"}
              </div>
              <Label style={{ marginTop: 12 }}>
                The call continues while the agent searches.
              </Label>
            </div>
          </div>
        </div>
      </Window>
      <Cursor
        t={t}
        points={[
          [18.2, 660, 580],
          [22.15, 300, 472],
          [22.45, 300, 472],
          [23.7, 1010, 383],
          [24.5, 1070, 383],
        ]}
        clicks={[22.403, 23.89]}
      />
    </>
  );
};
export const History = ({ t }: { t: number }) => {
  const q = ease(t, 28.4, 0.85);
  return (
    <>
      <Box x={110} y={137}>
        <Eyebrow>Existing workflow / retrieve the latest update</Eyebrow>
      </Box>
      <Camera
        t={t}
        start={30.9}
        end={35.7}
        from={[0, 0, 1]}
        to={[-65, -17, 1.08]}
      >
        <Window
          vendor="zoho"
          tag="ILLUSTRATIVE DEMO"
          style={{
            position: "absolute",
            left: 112,
            top: 190,
            width: 1695,
            height: 716,
          }}
        >
          <div style={{ display: "flex", height: 652 }}>
            <div
              style={{
                width: 355,
                padding: 30,
                borderRight: `1px solid ${C.line}`,
                background: C.paper,
              }}
            >
              <SearchField
                text={PHONE}
                style={{ fontSize: 22, height: 57, padding: "0 12px" }}
              />
              <div style={{ marginTop: 30 }}>
                <PersonHeader small email={false} />
              </div>
              <Label style={{ marginTop: 32 }}>
                Customer’s previous tickets
              </Label>
              <div style={{ marginTop: 23, fontSize: 25 }}>
                Open ticket → Read update
              </div>
              <div style={{ marginTop: 50 }}>
                <Badge tone="green" icon="phone">
                  Call connected
                </Badge>
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ padding: "0 31px" }}>
                <Tabs items={["Tickets", "Contact details"]} />
              </div>
              <TicketRow selected />
              {q < 0.99 && (
                <TicketRow
                  title="Product information"
                  id="DESK-1981"
                  status="Closed"
                  old
                />
              )}
              <div
                style={{
                  height: mix(0, 340, q),
                  overflow: "hidden",
                  padding: "0 29px",
                  opacity: q,
                }}
              >
                <div style={{ paddingTop: 26 }}>
                  <TicketNote t={t} start={29.1} />
                </div>
              </div>
            </div>
          </div>
        </Window>
      </Camera>
      <Cursor
        t={t}
        points={[
          [26.2, 1330, 540],
          [28.15, 1110, 390],
          [28.5, 1110, 390],
          [29.2, 1320, 610],
        ]}
        clicks={[28.4]}
      />
    </>
  );
};
export const Lookup = ({ t }: { t: number }) => {
  const found = t >= 44.953;
  const moving = p(t, 41.71, 2.6);
  return (
    <>
      <Box x={110} y={142}>
        <Eyebrow>Proposed experience / authorized lookup</Eyebrow>
        <Title size={55} style={{ marginTop: 17 }}>
          Let the call bring the context.
        </Title>
      </Box>
      <Box x={115} y={294}>
        <CallCard t={t} incoming={t < 41} compact />
      </Box>
      <Box x={654} y={298} w={1135}>
        <Window title="GRINDCTRL / permitted record lookup" tag="PROPOSED">
          <div style={{ padding: "36px 43px" }}>
            <Label>Lookup input</Label>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginTop: 16,
                paddingBottom: 27,
                borderBottom: `1px solid ${C.line}`,
              }}
            >
              <div style={{ fontSize: 38, letterSpacing: -0.6 }}>{PHONE}</div>
              <Badge
                icon={found ? "check" : "lock"}
                tone={found ? "green" : "neutral"}
              >
                {found ? "One candidate matched" : "Authorized lookup"}
              </Badge>
            </div>
            <div
              style={{
                height: 4,
                background: C.soft,
                margin: "29px 0 33px",
                overflow: "hidden",
                borderRadius: 3,
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: found ? "100%" : `${moving * 85}%`,
                  background: C.green,
                }}
              />
            </div>
            <div style={{ display: "flex", gap: 22, alignItems: "center" }}>
              <div
                style={{
                  width: 65,
                  height: 65,
                  borderRadius: 17,
                  background: found ? C.greenSoft : C.soft,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icon
                  name={found ? "shield" : "lock"}
                  size={31}
                  color={found ? C.green : C.muted}
                />
              </div>
              <div>
                <div style={{ fontSize: 32 }}>
                  {found
                    ? "Check match and permitted access"
                    : "Customer history stays private"}
                </div>
                <Label style={{ fontSize: 24, marginTop: 9 }}>
                  {found
                    ? "Open only the appropriate customer record."
                    : "Phone number identifies candidates, not a verified person."}
                </Label>
              </div>
            </div>
            <div
              style={{
                display: "flex",
                gap: 22,
                fontSize: 22,
                color: C.muted,
                marginTop: 39,
              }}
            >
              <span>Caller key</span>
              <Icon name="chevron" size={19} />
              <span>Match checks</span>
              <Icon name="chevron" size={19} />
              <span>Access checks</span>
            </div>
          </div>
        </Window>
      </Box>
    </>
  );
};
export const Pop = ({ t }: { t: number }) => (
  <>
    <Box x={110} y={142}>
      <Eyebrow>Proposed / authorized customer context</Eyebrow>
    </Box>
    <Box x={102} y={206}>
      <CallCard t={t} compact matched />
    </Box>
    <Window
      title="Customer context"
      tag="PROPOSED URL SCREEN POP"
      style={{
        position: "absolute",
        left: 535,
        top: 196,
        width: 1280,
        height: 710,
        transform: `translateX(${mix(100, 0, damp(t, 47.203, 0.8))}px)`,
      }}
    >
      <div style={{ padding: "30px 37px" }}>
        <div style={reveal(t, cue("01", "screen_pop"))}>
          <PersonHeader email={false} />
        </div>
        <div
          style={{ marginTop: 24, ...reveal(t, cue("01", "previous_tickets")) }}
        >
          <Tabs items={["Previous tickets", "Contact details"]} />
        </div>
        <div
          style={{ ...reveal(t, cue("01", "previous_tickets")), marginTop: 2 }}
        >
          <TicketRow
            selected
            status={
              t >= cue("01", "ticket_status")
                ? "Pending branch review"
                : "Existing ticket"
            }
          />
        </div>
        <div
          style={{
            marginTop: 25,
            opacity: ease(t, cue("01", "latest_update"), 0.5),
          }}
        >
          <TicketNote t={t} start={cue("01", "latest_update")} />
        </div>
      </div>
    </Window>
  </>
);
export const Exchange = ({ t }: { t: number }) => {
  const close = ease(t, 62.195, 1),
    conversation = ease(t, 72.226, 0.9);
  return (
    <>
      <Box x={110} y={137}>
        <Eyebrow>One customer / one documented exchange request</Eyebrow>
      </Box>
      <Camera
        t={t}
        start={62.195}
        end={67.6}
        from={[0, 0, 1]}
        to={[-20, -14, 1.03]}
      >
        <Window
          title="Customer context / Ahmed M."
          tag="PROPOSED EXPERIENCE"
          style={{
            position: "absolute",
            left: 112,
            top: 188,
            width: 1697,
            height: 721,
          }}
        >
          <CallStrip />
          <div style={{ display: "flex", height: 557 }}>
            <div
              style={{
                width: mix(510, 390, close),
                borderRight: `1px solid ${C.line}`,
                background: C.paper,
                padding: "30px 29px",
              }}
            >
              <Label>Previous support ticket</Label>
              <div
                style={{
                  fontSize: 36,
                  fontWeight: 500,
                  letterSpacing: -0.7,
                  marginTop: 22,
                }}
              >
                Exchange follow-up
              </div>
              <div style={{ fontSize: 25, color: C.muted, marginTop: 15 }}>
                DESK-2048
              </div>
              <div style={{ marginTop: 27 }}>
                <Badge tone="amber" icon="clock">
                  Pending branch review
                </Badge>
              </div>
              <div style={{ marginTop: 38 }}>
                <Avatar />
                <div style={{ fontSize: 29, marginTop: 17 }}>Ahmed M.</div>
              </div>
            </div>
            <div style={{ flex: 1, padding: "29px 36px" }}>
              <div style={{ fontSize: 29, fontWeight: 480, marginBottom: 22 }}>
                Continue from the latest recorded point.
              </div>
              <TicketNote t={t} large start={57.8} />
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  marginTop: 24,
                  color: C.amber,
                  opacity: ease(t, 67.916, 0.5),
                }}
              >
                <Icon name="note" size={22} />
                <span style={{ fontSize: 24 }}>
                  Recorded status · no completed review implied
                </span>
              </div>
            </div>
          </div>
        </Window>
      </Camera>
      {conversation > 0 && (
        <Box
          x={1045}
          y={713}
          w={703}
          style={{
            ...reveal(t, 72.226),
            padding: "23px 28px",
            background: "white",
            border: `1px solid ${C.line}`,
            borderRadius: 14,
            boxShadow: shadow,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 13 }}>
            <Avatar name="S" size={43} />
            <div style={{ fontSize: 25, color: C.green }}>
              Salma continues the conversation.
            </div>
          </div>
        </Box>
      )}
    </>
  );
};
export const Fallback = ({ t, film = "01" }: { t: number; film?: string }) => {
  const second = film === "02";
  const start = second ? 104.323 : 79.126;
  const k = second
    ? t < 107.958
      ? 5
      : t < 111.218
        ? 0
        : t < 115.299
          ? 1
          : t < 118.431
            ? 2
            : 3
    : t < 83.825
      ? 1
      : t < 87.702
        ? 0
        : t < 91.852
          ? 3
          : 4;
  const titles = [
    "No matching contact",
    "Choose the correct record",
    "Membership unavailable",
    "Lookup temporarily unavailable",
    "A phone number is a lookup key.",
    "Permission required",
  ];
  return (
    <>
      <Box x={110} y={138}>
        <Eyebrow>
          Safe fallbacks / {second ? "customer continuity" : "caller context"}
        </Eyebrow>
      </Box>
      <Window
        title="Customer context"
        tag="PROPOSED / FICTIONAL RECORDS"
        style={{
          position: "absolute",
          left: 110,
          top: 190,
          width: 1700,
          height: 714,
        }}
      >
        <CallStrip matched={false} />
        <div style={{ padding: "39px 47px" }}>
          <div style={{ display: "flex", gap: 23, alignItems: "center" }}>
            <div
              style={{
                width: 70,
                height: 70,
                borderRadius: 18,
                background: k === 3 ? C.redSoft : C.soft,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Icon
                name={
                  k === 1
                    ? "user"
                    : k === 3
                      ? "refresh"
                      : k === 4
                        ? "shield"
                        : k === 5
                          ? "lock"
                          : "search"
                }
                size={33}
                color={k === 3 ? C.red : C.muted}
              />
            </div>
            <div>
              <Title size={43}>{titles[k]}</Title>
              <Label style={{ marginTop: 11, fontSize: 26 }}>
                {k === 5
                  ? "Restricted fields stay hidden for this role."
                  : k === 1
                    ? "History remains hidden until matching and access checks."
                    : k === 4
                      ? "Verify the person before exposing permitted customer history."
                      : k === 2
                        ? "Do not infer a tier. Keep missing fields honest."
                        : "Continue the call. Use an appropriate manual path."}
              </Label>
            </div>
          </div>
          {k === 1 ? (
            <div style={{ marginTop: 34, display: "flex", gap: 26 }}>
              {["Ahmed M.", "A. M. · another possible match"].map((s, i) => (
                <div
                  key={s}
                  style={{
                    flex: 1,
                    border: `1px solid ${i === 0 && t > (second ? 113.9 : 81.7) ? "#aebdae" : C.line}`,
                    background:
                      i === 0 && t > (second ? 113.9 : 81.7)
                        ? C.greenSoft
                        : "white",
                    padding: "24px 28px",
                    borderRadius: 12,
                    display: "flex",
                    gap: 18,
                    alignItems: "center",
                  }}
                >
                  <Avatar name={i ? "A" : "AM"} size={56} />
                  <div>
                    <div style={{ fontSize: 28 }}>{s}</div>
                    <Label style={{ fontSize: 21, marginTop: 5 }}>
                      Candidate record · shared caller number
                    </Label>
                  </div>
                  <Icon
                    name="chevron"
                    size={23}
                    style={{ marginLeft: "auto" }}
                  />
                </div>
              ))}
            </div>
          ) : k === 2 ? (
            <div
              style={{
                display: "flex",
                gap: 28,
                marginTop: 35,
                alignItems: "center",
              }}
            >
              <Avatar />
              <div>
                <div style={{ fontSize: 32 }}>Ahmed M.</div>
                <div style={{ marginTop: 14 }}>
                  <Badge>Icons Club tier · unavailable</Badge>
                </div>
              </div>
            </div>
          ) : k === 5 ? (
            <div
              style={{
                display: "flex",
                gap: 22,
                alignItems: "center",
                marginTop: 40,
              }}
            >
              <Badge icon="lock" style={{ fontSize: 27 }}>
                Access restricted
              </Badge>
              <Label style={{ fontSize: 26 }}>
                Use the authorized access path.
              </Label>
            </div>
          ) : k === 4 ? (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 34,
                marginTop: 42,
              }}
            >
              <div style={{ fontSize: 43 }}>{PHONE}</div>
              <div style={{ fontSize: 35, color: C.faint }}>≠</div>
              <Badge icon="shield" style={{ fontSize: 28 }}>
                Verified identity
              </Badge>
            </div>
          ) : (
            <div
              style={{
                display: "flex",
                gap: 23,
                alignItems: "center",
                marginTop: 40,
              }}
            >
              <Button icon="search" light>
                Manual search
              </Button>
              {k === 3 && (
                <Badge tone="green" icon="phone">
                  Call continues
                </Badge>
              )}
            </div>
          )}
          <div
            style={{
              marginTop: 36,
              paddingTop: 23,
              borderTop: `1px solid ${C.line}`,
              fontSize: 23,
              color: C.muted,
            }}
          >
            No private history is displayed in an uncertain state.
          </div>
        </div>
      </Window>
    </>
  );
};
export const Connect = ({ t }: { t: number }) => (
  <>
    <Box x={113} y={252} w={640}>
      <Eyebrow>A proposed improvement</Eyebrow>
      <Title size={79} style={{ marginTop: 28 }}>
        Your systems.
        <br />A clearer moment.
      </Title>
      <Label style={{ fontSize: 29, marginTop: 28, lineHeight: 1.5 }}>
        Genesys receives the call.
        <br />
        Zoho Desk holds the ticket context.
      </Label>
      <div
        style={{ marginTop: 33, ...reveal(t, cue("01", "proposal_status")) }}
      >
        <Badge icon="lock">Subject to technical validation</Badge>
      </div>
    </Box>
    <Box
      x={887}
      y={204}
      w={900}
      style={{ transform: "perspective(2200px) rotateY(-3deg) rotateZ(1deg)" }}
    >
      <Window title="Proposed employee experience" tag="CONCRETE">
        <CallStrip />
        <div style={{ padding: 30 }}>
          <div
            style={{
              display: "flex",
              gap: 35,
              padding: "4px 0 27px",
              borderBottom: `1px solid ${C.line}`,
            }}
          >
            <div
              style={{
                padding: "12px 16px",
                borderRadius: 8,
                background:
                  t >= cue("01", "existing_genesys")
                    ? C.greenSoft
                    : "transparent",
                transition: "none",
              }}
            >
              <Logo vendor="genesys" height={31} />
            </div>
            <span style={{ fontSize: 25, color: C.faint }}>+</span>
            <div
              style={{
                padding: "12px 16px",
                borderRadius: 8,
                background:
                  t >= cue("01", "existing_zoho") ? C.amberSoft : "transparent",
              }}
            >
              <Logo vendor="zoho" height={31} />
            </div>
          </div>
          <div
            style={{
              marginTop: 27,
              borderRadius: 8,
              outlineOffset: 8,
              outline: `2px solid rgba(91,115,98,${0.42 * ease(t, cue("01", "proposed_context")) * (1 - ease(t, cue("01", "connect_context")))})`,
            }}
          >
            <PersonHeader small email={false} />
          </div>
          <div
            style={{
              marginTop: 24,
              borderRadius: 13,
              outlineOffset: 5,
              outline: `2px solid rgba(157,132,84,${0.5 * ease(t, cue("01", "connect_context")) * (1 - ease(t, 107.8))})`,
            }}
          >
            <NotePreview t={t} />
          </div>
        </div>
      </Window>
    </Box>
  </>
);
export const Value = ({ t }: { t: number }) => {
  const measure = t >= 116.4;
  return (
    <>
      <Box x={110} y={144}>
        <Eyebrow>
          {measure
            ? "Pilot measures / no guaranteed savings"
            : "The proposed difference"}
        </Eyebrow>
        <Title size={58} style={{ marginTop: 18 }}>
          {measure
            ? "Prove the difference in a pilot."
            : "Less searching. More attention."}
        </Title>
      </Box>
      {!measure ? (
        <>
          <Box x={115} y={330} w={560}>
            <Label>Today / manual retrieval</Label>
            <Window plain style={{ marginTop: 22, padding: "29px 31px" }}>
              <SearchField text={PHONE} style={{ fontSize: 25 }} />
              <div
                style={{
                  marginTop: 25,
                  display: "flex",
                  alignItems: "center",
                  gap: 14,
                  fontSize: 27,
                }}
              >
                <Icon name="copy" color={C.muted} />
                Copy · Search · Open ticket
              </div>
            </Window>
            <Label style={{ marginTop: 24 }}>
              Context must be found during the call.
            </Label>
          </Box>
          <Box x={801} y={306} w={1000}>
            <Window title="Proposed / customer context in view" tag="FICTIONAL">
              <CallStrip />
              <div style={{ padding: 30 }}>
                <NotePreview t={t} />
              </div>
            </Window>
          </Box>
        </>
      ) : (
        <Box x={185} y={319} w={1550}>
          <Window
            title="Pilot validation / measurement plan"
            tag="TO BE MEASURED"
          >
            <div style={{ padding: "10px 39px 26px" }}>
              {[
                [
                  "Manual searching",
                  "Observe whether retrieval steps are reduced.",
                ],
                [
                  "Follow-up clarity",
                  "Check the correct latest status is visible.",
                ],
                [
                  "Conversation continuity",
                  "Review the agent’s ability to continue in context.",
                ],
              ].map(([h, s], i) => (
                <div
                  key={h}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 23,
                    padding: "26px 0",
                    borderBottom: i < 2 ? `1px solid ${C.line}` : "none",
                    ...reveal(t, 116.4 + i * 0.7),
                  }}
                >
                  <div
                    style={{
                      width: 53,
                      height: 53,
                      borderRadius: 14,
                      background: C.soft,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon
                      name={["search", "ticket", "chat"][i]}
                      color={C.muted}
                    />
                  </div>
                  <div>
                    <div style={{ fontSize: 31 }}>{h}</div>
                    <Label style={{ fontSize: 24, marginTop: 8 }}>{s}</Label>
                  </div>
                  <Badge style={{ marginLeft: "auto" }}>To validate</Badge>
                </div>
              ))}
            </div>
          </Window>
        </Box>
      )}
    </>
  );
};
export const Pilot = ({ t, film = "01" }: { t: number; film?: string }) => {
  const two = film === "02";
  const labels = two
    ? [
        "Call activities and original notes",
        "Supported integrations",
        "Field access, permissions and retention",
        "Authorized fictional test records",
      ]
    : [
        "Existing Genesys URL pop-up",
        "Zoho Desk access",
        "Permissions and supported mechanisms",
        "Authorized sample calls",
      ];
  const times = two
    ? [122.325, 127.718, 129.547, 131.984]
    : [122.001, 126.625, 128.357, 131.662];
  return (
    <>
      <Box x={110} y={151} w={490}>
        <Eyebrow>Practical next step</Eyebrow>
        <Title size={67} style={{ marginTop: 28 }}>
          Inspect first.
          <br />
          Pilot carefully.
        </Title>
        <Label style={{ fontSize: 28, marginTop: 28, lineHeight: 1.45 }}>
          Use the smallest suitable improvement.
        </Label>
        <div style={{ marginTop: 37 }}>
          <Badge icon="lock">Authorized discovery</Badge>
        </div>
      </Box>
      <Box x={682} y={185} w={1118}>
        <Window title="Discovery / pilot checklist" tag="PROPOSED NEXT STEP">
          <div style={{ padding: "17px 35px 25px" }}>
            {labels.map((s, i) => (
              <div
                key={s}
                style={{
                  display: "flex",
                  gap: 19,
                  alignItems: "center",
                  padding: "27px 0",
                  borderBottom: i < 3 ? `1px solid ${C.line}` : "none",
                  opacity: t < times[i] ? 0.4 : 1,
                }}
              >
                <div
                  style={{
                    width: 43,
                    height: 43,
                    borderRadius: 11,
                    border: `1px solid ${C.line}`,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    fontSize: 22,
                    color: t >= times[i] ? C.ink : C.muted,
                  }}
                >
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div style={{ fontSize: 28, flex: 1 }}>{s}</div>
                <Badge style={{ fontSize: 20 }}>
                  {i === 3 ? "Test plan" : "Review"}
                </Badge>
              </div>
            ))}
          </div>
          <div
            style={{
              padding: "21px 35px",
              borderTop: `1px solid ${C.line}`,
              background: C.paper,
              fontSize: 22,
              color: C.muted,
            }}
          >
            {two
              ? "Confirm storage, association keys, visibility and retention."
              : "2023 contract: “CRM URL pop up integration” · deployment unverified."}
          </div>
        </Window>
      </Box>
    </>
  );
};
export const Close = ({ t }: { t: number }) => (
  <>
    <Box x={110} y={213} w={645}>
      <Eyebrow>GRINDCTRL × Concrete</Eyebrow>
      <Title size={76} style={{ marginTop: 30 }}>
        When the call begins,
        <br />
        context is ready.
      </Title>
      <Label style={{ fontSize: 28, marginTop: 28 }}>
        An experience to validate together.
      </Label>
      <div
        style={{
          marginTop: 36,
          display: "flex",
          gap: 24,
          alignItems: "center",
        }}
      >
        <Logo vendor="genesys" height={28} />
        <span style={{ color: C.faint, fontSize: 26 }}>+</span>
        <Logo vendor="zoho" height={28} />
      </div>
    </Box>
    <Box
      x={897}
      y={193}
      w={900}
      style={{
        transform: `perspective(2200px) rotateY(${mix(-4, 0, ease(t, 140, 5))}deg)`,
      }}
    >
      <Window title="Proposed employee experience" tag="FICTIONAL RECORD">
        <CallStrip matched={t >= cue("01", "context_ready")} />
        <div style={{ padding: 29 }}>
          <div style={{ opacity: ease(t, cue("01", "context_ready"), 0.4) }}>
            <PersonHeader small email={false} />
          </div>
          <div
            style={{ marginTop: 27, ...reveal(t, cue("01", "context_ready")) }}
          >
            <NotePreview t={t} />
          </div>
          <div
            style={{
              marginTop: 22,
              fontSize: 23,
              color: C.green,
              display: "flex",
              alignItems: "center",
              gap: 10,
              ...reveal(t, 142.071),
            }}
          >
            <Icon name="chat" size={23} />
            Continue from the recorded point.
          </div>
        </div>
      </Window>
    </Box>
  </>
);
export const Film01Scene: React.FC<{ id: string; t: number }> = ({ id, t }) => {
  const map: Record<string, React.FC<{ t: number }>> = {
    arrival: Arrival,
    missing: Missing,
    manual: Manual,
    history: History,
    lookup: Lookup,
    pop: Pop,
    exchange: Exchange,
    fallback: Fallback,
    connect: Connect,
    value: Value,
    pilot: Pilot,
    close: Close,
  };
  const Comp = map[id];
  return <Comp t={t} />;
};
