import { cue } from "../../motion/cues";
import React from "react";
import { AbsoluteFill } from "remotion";
import { C, shadow } from "../../design-system/tokens";
import {
  Box,
  Window,
  Logo,
  Label,
  Avatar,
  Badge,
  Button,
  Tabs,
  Title,
  Eyebrow,
  Field,
} from "../../components/Primitives";
import {
  FashionImage,
  ProductPage,
  ProductInfo,
  StoreHeader,
  ChatHeader,
  ChatMessage,
  ChatInput,
  ShopperChat,
} from "../../components/Fashion";
import { SearchField } from "../../components/ContactCenter";
import { Icon } from "../../components/Icons";
import {
  Camera,
  Cursor,
  damp,
  ease,
  mix,
  p,
  reveal,
  typing,
  Sweep,
} from "../../motion/primitives";
export const film03Shots = [
  {
    id: "editorial",
    start: 0,
    end: 14.856,
    title: "The garment, then the question",
  },
  {
    id: "store",
    start: 14.856,
    end: 25.568,
    title: "A supported Shopify product page",
  },
  {
    id: "upload",
    start: 25.568,
    end: 31.216,
    title: "Choose the garment and add a photo",
  },
  {
    id: "reveal",
    start: 31.216,
    end: 39.099,
    title: "A personal visual preview",
  },
  {
    id: "fit",
    start: 39.099,
    end: 48.538,
    title: "Style preview, not a fit guarantee",
  },
  {
    id: "question",
    start: 48.538,
    end: 68.222,
    title: "Ask within the shopping journey",
  },
  {
    id: "answer",
    start: 68.222,
    end: 79.037,
    title: "Answers grounded in store knowledge",
  },
  {
    id: "handoff",
    start: 79.037,
    end: 90.559,
    title: "A person continues with context",
  },
  {
    id: "order",
    start: 90.559,
    end: 106.638,
    title: "Configured verified read-only lookup",
  },
  {
    id: "journey",
    start: 106.638,
    end: 121.165,
    title: "One connected customer journey",
  },
  {
    id: "brand",
    start: 121.165,
    end: 133.974,
    title: "See it, understand it, stay in control",
  },
  { id: "close", start: 133.974, end: 150, title: "Explore GRINDCTRL" },
];
const Editorial = ({ t }: { t: number }) => {
  const macro = ease(t, 7.965, 0.75) * (1 - ease(t, 10.252, 0.65));
  const question = t >= 10.252;
  return (
    <>
      <Box x={110} y={239} w={680}>
        <Eyebrow>GRINDCTRL / AI Visual Sales</Eyebrow>
        <Title size={88} style={{ marginTop: 35 }}>
          {question ? (
            <>
              What could it
              <br />
              look like on me?
            </>
          ) : (
            <>
              A piece
              <br />
              you love.
            </>
          )}
        </Title>
        <Label style={{ fontSize: 28, marginTop: 30, lineHeight: 1.5 }}>
          {question
            ? "A more personal way to explore."
            : "The linen edit. A fictional fashion story."}
        </Label>
        <div
          style={{
            marginTop: 35,
            display: "flex",
            gap: 15,
            alignItems: "center",
          }}
        >
          <span
            style={{
              width: 26,
              height: 26,
              background: C.navy,
              borderRadius: "50%",
            }}
          />
          <span style={{ fontSize: 25, color: C.muted }}>
            Midnight navy / washed linen
          </span>
        </div>
      </Box>
      <Box
        x={900}
        y={117}
        w={940}
        h={798}
        style={{
          overflow: "hidden",
          borderRadius: 4,
          boxShadow: "0 25px 65px -45px #4b3a28",
        }}
      >
        <FashionImage
          style={{
            transform: `scale(${1 + macro * 0.12}) translateY(${macro * 2}%)`,
            transformOrigin: "60% 42%",
          }}
        />
      </Box>
      {question && (
        <Box
          x={731}
          y={569}
          w={241}
          h={316}
          style={{
            overflow: "hidden",
            border: "7px solid #fff",
            borderRadius: 10,
            boxShadow: shadow,
            ...reveal(t, 10.7),
          }}
        >
          <FashionImage kind="before" position="center 28%" />
        </Box>
      )}
    </>
  );
};
const Store = ({ t }: { t: number }) => (
  <>
    <Box x={110} y={137}>
      <Eyebrow>Supported Shopify storefront / illustrative merchant</Eyebrow>
    </Box>
    <Camera
      t={t}
      start={21.324}
      end={25.5}
      from={[0, 0, 1]}
      to={[-21, -10, 1.025]}
    >
      <ProductPage
        t={t}
        style={{ position: "absolute", left: 111, top: 185, width: 1700 }}
      />
    </Camera>
    <Cursor
      t={t}
      points={[
        [21.5, 1320, 527],
        [22.5, 1356, 623],
        [24.4, 1356, 623],
        [25.1, 1458, 709],
        [25.5, 1458, 709],
      ]}
      clicks={[22.6]}
    />
  </>
);
const Upload = ({ t }: { t: number }) => {
  const modal = damp(t, 25.568, 0.7),
    photo = ease(t, cue("03", "photo_upload"), 0.65),
    loading = t >= 29.216;
  return (
    <>
      <div
        style={{
          position: "absolute",
          left: 111,
          top: 185,
          width: 1700,
          opacity: 0.22,
        }}
      >
        <ProductPage t={t} />
      </div>
      <Window
        title="GRINDCTRL / Virtual Try-On"
        tag="ILLUSTRATIVE WORKFLOW"
        style={{
          position: "absolute",
          left: 350,
          top: 175,
          width: 1220,
          height: 735,
          transform: `translateY(${mix(80, 0, modal)}px) scale(${mix(0.93, 1, modal)})`,
          transformOrigin: "75% 75%",
          opacity: modal,
        }}
      >
        <div style={{ padding: "31px 38px" }}>
          <Title size={44}>Your photo. Your selected piece.</Title>
          <Label style={{ fontSize: 24, marginTop: 14 }}>
            A personal style preview using the same garment.
          </Label>
          <div style={{ display: "flex", gap: 30, marginTop: 31 }}>
            <div style={{ width: 259 }}>
              <div
                style={{
                  height: 349,
                  borderRadius: 11,
                  overflow: "hidden",
                  background: "#e4d5c0",
                }}
              >
                <FashionImage />
              </div>
              <Label style={{ fontSize: 21, marginTop: 15 }}>
                Navy linen overshirt
              </Label>
            </div>
            <div style={{ flex: 1 }}>
              <div
                style={{
                  height: 349,
                  border: `1.5px dashed ${photo ? "#a6b9a6" : "#c5baaa"}`,
                  background: photo ? "#f2f4ef" : "#faf8f3",
                  borderRadius: 11,
                  display: "flex",
                  gap: 25,
                  alignItems: "center",
                  justifyContent: "center",
                  padding: 24,
                }}
              >
                {photo > 0.01 ? (
                  <>
                    <div
                      style={{
                        width: 203,
                        height: 295,
                        borderRadius: 8,
                        overflow: "hidden",
                        opacity: photo,
                      }}
                    >
                      <FashionImage kind="before" />
                    </div>
                    <div>
                      <Badge tone="green" icon="check">
                        Photo added
                      </Badge>
                      <Label style={{ fontSize: 23, marginTop: 20 }}>
                        Fictional shopper photo.
                        <br />
                        Ready to create a preview.
                      </Label>
                    </div>
                  </>
                ) : (
                  <div style={{ textAlign: "center" }}>
                    <Icon name="upload" size={51} color={C.muted} />
                    <div style={{ fontSize: 30, marginTop: 19 }}>
                      Upload your photo
                    </div>
                    <Label style={{ fontSize: 22, marginTop: 12 }}>
                      Clear image. Natural pose.
                    </Label>
                  </div>
                )}
              </div>
              <div
                style={{
                  height: 4,
                  background: C.soft,
                  marginTop: 19,
                  borderRadius: 3,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${p(t, 27.746, 1.47) * 100}%`,
                    background: C.green,
                  }}
                />
              </div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginTop: 24,
                }}
              >
                <Label style={{ fontSize: 21 }}>
                  {loading
                    ? "Preparing the illustrated preview"
                    : "Photo stays paired with this garment"}
                </Label>
                <Button
                  icon={loading ? "spark" : "upload"}
                  style={{ fontSize: 23 }}
                >
                  {loading ? "Create preview" : "Choose photo"}
                </Button>
              </div>
            </div>
          </div>
          <Label style={{ fontSize: 19, marginTop: 22 }}>
            Synthetic demonstration assets. Processing time is not represented.
          </Label>
        </div>
      </Window>
      <Cursor
        t={t}
        points={[
          [26, 1490, 735],
          [26.8, 1179, 503],
          [27.7, 1179, 503],
          [28.5, 1391, 757],
          [29.25, 1391, 757],
          [30.1, 1480, 810],
        ]}
        clicks={[27.746, 29.216]}
      />
    </>
  );
};
export const Reveal = ({
  t,
  compact = false,
}: {
  t: number;
  compact?: boolean;
}) => {
  const q = ease(t, cue("03", "preview_generation"), 1.3);
  return (
    <>
      <Box x={110} y={187} w={690}>
        <Eyebrow>A personal style preview</Eyebrow>
        <Title size={73} style={{ marginTop: 27 }}>
          Your photo.
          <br />
          The same piece.
        </Title>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 28,
            marginTop: 37,
          }}
        >
          <div
            style={{
              width: 225,
              height: 321,
              borderRadius: 10,
              overflow: "hidden",
              boxShadow: shadow,
            }}
          >
            <FashionImage />
          </div>
          <div style={{ maxWidth: 340 }}>
            <Label style={{ fontSize: 27 }}>
              The selected navy
              <br />
              linen overshirt.
            </Label>
            <div style={{ marginTop: 23 }}>
              <Badge icon="lock">Same garment</Badge>
            </div>
          </div>
        </div>
      </Box>
      <Box
        x={943}
        y={150}
        w={856}
        h={756}
        style={{
          borderRadius: 14,
          overflow: "hidden",
          background: "#e9dbc6",
          boxShadow: shadow,
        }}
      >
        <FashionImage kind="before" style={{ objectFit: "contain" }} />
        <div
          style={{
            position: "absolute",
            inset: 0,
            clipPath: `inset(0 ${100 - q * 100}% 0 0)`,
          }}
        >
          <FashionImage kind="result" style={{ objectFit: "contain" }} />
        </div>
        {q < 1 && (
          <div
            style={{
              position: "absolute",
              top: 0,
              bottom: 0,
              left: `${q * 100}%`,
              width: 2,
              background: "#fff9",
            }}
          />
        )}
        <div style={{ position: "absolute", bottom: 25, left: 26 }}>
          <Badge icon="spark" style={{ fontSize: 22, background: "#ffffffed" }}>
            Illustrative preview / same person
          </Badge>
        </div>
      </Box>
    </>
  );
};
const Fit = ({ t }: { t: number }) => (
  <>
    <Box
      x={111}
      y={150}
      w={738}
      h={754}
      style={{ overflow: "hidden", borderRadius: 13, boxShadow: shadow }}
    >
      <FashionImage kind="result" position="center 35%" />
      <div style={{ position: "absolute", left: 27, bottom: 28 }}>
        <Badge style={{ background: "#fffef2ed", fontSize: 22 }}>
          Style exploration / authored illustration
        </Badge>
      </div>
    </Box>
    <Box x={987} y={220} w={786}>
      <Eyebrow>Confidence with clear limits</Eyebrow>
      <Title size={70} style={{ marginTop: 27 }}>
        Explore the style.
        <br />
        Check the details.
      </Title>
      <div
        style={{
          marginTop: 34,
          display: "flex",
          gap: 14,
          alignItems: "center",
          fontSize: 29,
          color: C.muted,
          ...reveal(t, 42.178),
        }}
      >
        <Icon name="ruler" size={28} />
        Not an exact measurement or fit guarantee.
      </div>
      <Window
        title="Product information"
        tag="MERCHANT SOURCE"
        style={{ marginTop: 32, opacity: ease(t, 45.511) }}
      >
        <div
          style={{
            padding: "25px 29px",
            display: "flex",
            alignItems: "center",
            gap: 20,
          }}
        >
          <Icon name="note" color={C.muted} size={32} />
          <div>
            <div style={{ fontSize: 29 }}>Size guide and garment details</div>
            <Label style={{ fontSize: 23, marginTop: 7 }}>
              Use the merchant’s actual product information.
            </Label>
          </div>
        </div>
      </Window>
    </Box>
  </>
);
const Question = ({ t }: { t: number }) => {
  const opened = t >= 58.353;
  const prompt =
    t < 55.007
      ? "Does this shirt run oversized?"
      : t < 56.456
        ? "Is there a size guide?"
        : "What is the delivery policy?";
  const promptAt = t < 55.007 ? 52.886 : t < 56.456 ? 55.007 : 56.456;
  return (
    <>
      <Box x={110} y={138}>
        <Eyebrow>Store Chat / ask without leaving the piece</Eyebrow>
      </Box>
      <Window
        title="Shopify storefront / fictional fashion merchant"
        tag="ILLUSTRATIVE PRODUCT EXPERIENCE"
        style={{
          position: "absolute",
          left: 110,
          top: 187,
          width: 1700,
          height: 718,
        }}
      >
        <StoreHeader />
        <div style={{ display: "flex", height: 586 }}>
          <div
            style={{
              width: opened ? 720 : 850,
              overflow: "hidden",
              background: "#e8dcc9",
            }}
          >
            <FashionImage position="center 39%" />
          </div>
          <div style={{ flex: 1, padding: "38px 43px", position: "relative" }}>
            {!opened ? (
              <>
                <Eyebrow>Selected piece</Eyebrow>
                <Title size={47} style={{ marginTop: 20 }}>
                  The navy linen overshirt.
                </Title>
                <Label style={{ fontSize: 25, marginTop: 22 }}>
                  Questions are part of choosing.
                </Label>
                <div
                  style={{
                    marginTop: 41,
                    padding: "26px 29px",
                    borderRadius: 13,
                    background: C.soft,
                    fontSize: 32,
                    lineHeight: 1.35,
                    minHeight: 112,
                  }}
                >
                  {t < 52.886
                    ? "Ask about this piece."
                    : typing(prompt, t, promptAt, 0.7)}
                </div>
                <div style={{ marginTop: 29 }}>
                  <Button
                    icon="chat"
                    style={{ background: C.navy, borderColor: C.navy }}
                  >
                    Open Store Chat
                  </Button>
                </div>
              </>
            ) : (
              <div
                style={{
                  position: "absolute",
                  left: 31,
                  right: 31,
                  top: 21,
                  ...reveal(t, 58.353),
                }}
              >
                <ShopperChat t={t} style={{ boxShadow: "none" }} />
              </div>
            )}
          </div>
        </div>
      </Window>
      <Cursor
        t={t}
        points={[
          [57.1, 1350, 746],
          [58, 1290, 712],
          [58.4, 1290, 712],
          [60, 1670, 797],
          [67.8, 1600, 828],
        ]}
        clicks={[58.353]}
      />
    </>
  );
};
const Answer = ({ t }: { t: number }) => (
  <>
    <Box x={110} y={139}>
      <Eyebrow>Helpful answers / approved store knowledge</Eyebrow>
    </Box>
    <Box
      x={111}
      y={196}
      w={612}
      h={710}
      style={{ overflow: "hidden", borderRadius: 13, boxShadow: shadow }}
    >
      <FashionImage position="center 42%" />
    </Box>
    <Box x={819} y={189} w={978}>
      <ShopperChat t={t} answer style={{ minHeight: 716 }} />
    </Box>
  </>
);
export const Inbox = ({
  t,
  preview = false,
}: {
  t: number;
  preview?: boolean;
}) => {
  const assigned = preview || t >= cue("03", "assign"),
    note = preview || t >= cue("03", "private_note"),
    replied = preview || t >= cue("03", "human_reply");
  return (
    <Window
      title="GRINDCTRL / team inbox"
      tag="ILLUSTRATIVE CONVERSATION"
      style={{
        position: "absolute",
        left: 110,
        top: 188,
        width: 1700,
        height: 720,
      }}
    >
      <div style={{ display: "flex", height: 656 }}>
        <div
          style={{
            width: 342,
            padding: 25,
            borderRight: `1px solid ${C.line}`,
            background: C.paper,
          }}
        >
          <div style={{ fontSize: 30, fontWeight: 500 }}>Conversations</div>
          <div style={{ marginTop: 20 }}>
            <Badge tone="amber">Needs a reply</Badge>
          </div>
          <div
            style={{
              marginTop: 27,
              padding: "23px 20px",
              background: "white",
              border: `1px solid #d5cec2`,
              borderRadius: 13,
            }}
          >
            <div style={{ display: "flex", gap: 13, alignItems: "center" }}>
              <Avatar name="A" size={48} />
              <div style={{ fontSize: 27 }}>Alex</div>
            </div>
            <div style={{ fontSize: 23, lineHeight: 1.45, marginTop: 17 }}>
              Personal sizing question
            </div>
            <Label style={{ fontSize: 20, marginTop: 13 }}>
              Selected garment + chat context
            </Label>
          </div>
          <div style={{ marginTop: 24, fontSize: 20, color: C.muted }}>
            Fictional shopper / example thread
          </div>
        </div>
        <div style={{ flex: 1 }}>
          <div
            style={{
              height: 93,
              padding: "0 28px",
              borderBottom: `1px solid ${C.line}`,
              display: "flex",
              alignItems: "center",
              gap: 17,
            }}
          >
            <div>
              <div style={{ fontSize: 29 }}>Alex · Navy linen overshirt</div>
              <Label style={{ fontSize: 21, marginTop: 5 }}>
                AI handoff: personal sizing judgment
              </Label>
            </div>
            <div style={{ marginLeft: "auto" }}>
              <Badge
                tone={assigned ? "green" : "neutral"}
                icon={assigned ? "user" : "clock"}
              >
                {assigned ? "Assigned to Lina" : "Unassigned"}
              </Badge>
            </div>
          </div>
          <div style={{ padding: "23px 31px", display: "flex", gap: 28 }}>
            <div
              style={{
                width: 117,
                height: 159,
                borderRadius: 9,
                overflow: "hidden",
                flexShrink: 0,
              }}
            >
              <FashionImage />
            </div>
            <div style={{ flex: 1 }}>
              <ChatMessage
                from="shopper"
                style={{
                  fontSize: 26,
                  marginLeft: 0,
                  marginRight: 0,
                  padding: "17px 21px",
                }}
              >
                Could a person help me read the size guide?
              </ChatMessage>
              {note && (
                <ChatMessage
                  from="private"
                  label="PRIVATE NOTE / LINA / TEAM ONLY"
                  style={{ fontSize: 25, padding: "15px 21px", marginRight: 0 }}
                >
                  Personal sizing advice requested.
                  <br />
                  Review the selected product and guide.
                </ChatMessage>
              )}
              {replied && (
                <ChatMessage
                  from="human"
                  label="LINA / HUMAN REPLY"
                  style={{ fontSize: 25, padding: "15px 21px", marginRight: 0 }}
                >
                  I can help you read the guide for this piece.
                </ChatMessage>
              )}
              <div
                style={{
                  marginTop: 13,
                  display: "flex",
                  alignItems: "center",
                  gap: 11,
                  fontSize: 21,
                  color: C.muted,
                }}
              >
                <Icon name="chat" size={21} />
                Earlier conversation remains in this thread.
              </div>
            </div>
          </div>
        </div>
      </div>
    </Window>
  );
};
const Handoff = ({ t }: { t: number }) => {
  const at = cue("03", "shared_inbox"),
    q = ease(t, at, 0.65);
  return (
    <>
      <Box x={110} y={138}>
        <Eyebrow>
          A reasoned handoff / context travels with the conversation
        </Eyebrow>
      </Box>
      {q < 1 && (
        <div style={{ opacity: 1 - q }}>
          <Box x={110} y={219} w={594}>
            <Title size={71}>
              A teammate
              <br />
              can take it
              <br />
              from here.
            </Title>
            <Label style={{ fontSize: 29, marginTop: 27, lineHeight: 1.5 }}>
              Reason: personal sizing judgment.
              <br />
              Keep the selected piece and thread.
            </Label>
          </Box>
          <Box x={844} y={186} w={950}>
            <ShopperChat t={t} handoff />
          </Box>
        </div>
      )}
      {t >= at && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            opacity: q,
            transform: `translateX(${mix(65, 0, q)}px) scale(${mix(0.985, 1, q)})`,
            transformOrigin: "76% 48%",
          }}
        >
          <Inbox t={t} />
        </div>
      )}
    </>
  );
};
const Order = ({ t }: { t: number }) => {
  const verified = t >= 95.152;
  return (
    <>
      <Box x={110} y={138}>
        <Eyebrow>
          Only when configured and verified / read-only order context
        </Eyebrow>
      </Box>
      <Window
        title="Store Chat / verified read-only lookup"
        tag="CONDITIONAL ILLUSTRATIVE FLOW"
        style={{
          position: "absolute",
          left: 110,
          top: 188,
          width: 1700,
          height: 720,
        }}
      >
        <div style={{ display: "flex", padding: "38px 39px", gap: 43 }}>
          <div
            style={{
              width: 624,
              borderRight: `1px solid ${C.line}`,
              paddingRight: 38,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
              <div
                style={{
                  width: 57,
                  height: 57,
                  borderRadius: 15,
                  background: C.soft,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icon name="shield" size={28} />
              </div>
              <div>
                <Title size={35}>Verify shopper details</Title>
                <Label style={{ fontSize: 22, marginTop: 8 }}>
                  Access must be configured first.
                </Label>
              </div>
            </div>
            <div style={{ marginTop: 29 }}>
              <Label style={{ fontSize: 21 }}>Order reference</Label>
              <SearchField text="DEMO-1001" style={{ marginTop: 10 }} />
              <Label style={{ fontSize: 21, marginTop: 22 }}>Email</Label>
              <SearchField text="alex@example.com" style={{ marginTop: 10 }} />
            </div>
            <div style={{ marginTop: 29 }}>
              <Badge
                tone={verified ? "green" : "neutral"}
                icon={verified ? "shield" : "lock"}
              >
                {verified
                  ? "Example verification completed"
                  : "Verify before showing records"}
              </Badge>
            </div>
            <Label style={{ fontSize: 21, marginTop: 23 }}>
              Fictional order and email. No real customer lookup.
            </Label>
          </div>
          <div style={{ flex: 1, paddingTop: 4 }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Title size={39}>
                {verified
                  ? "Illustrative order context"
                  : "Information stays private"}
              </Title>
              <Badge icon="lock">Read only</Badge>
            </div>
            <div
              style={{
                marginTop: 31,
                padding: "28px 30px",
                background: verified ? C.greenSoft : C.soft,
                borderRadius: 12,
              }}
            >
              <div style={{ fontSize: 28 }}>
                {verified
                  ? "DEMO-1001 / example order"
                  : "Awaiting configured access + verification"}
              </div>
              <Label style={{ fontSize: 24, marginTop: 15, lineHeight: 1.5 }}>
                {verified
                  ? "Shown only from a permitted configured source."
                  : "No order details are displayed yet."}
              </Label>
            </div>
            <div
              style={{
                marginTop: 32,
                display: "flex",
                gap: 14,
                alignItems: "center",
                fontSize: 28,
                color: C.muted,
              }}
            >
              <Icon name="lock" size={27} />
              No order edits or refund promises.
            </div>
            <div
              style={{
                marginTop: 28,
                borderTop: `1px solid ${C.line}`,
                paddingTop: 24,
                fontSize: 24,
                color: C.muted,
              }}
            >
              Availability depends on the merchant’s enabled integration.
            </div>
          </div>
        </div>
      </Window>
    </>
  );
};
const Journey = ({ t }: { t: number }) => {
  const stage = t < 110.491 ? 0 : t < 112.434 ? 1 : t < 117.34 ? 2 : 3;
  return (
    <>
      <Box x={110} y={138}>
        <Eyebrow>One shopping journey / the context stays with it</Eyebrow>
      </Box>
      {stage === 0 ? (
        <ProductPage
          t={t}
          style={{ position: "absolute", left: 110, top: 185, width: 1700 }}
        />
      ) : stage === 1 ? (
        <>
          <Box x={110} y={202} w={660}>
            <Title size={72}>
              See the piece
              <br />
              on your photo.
            </Title>
            <Label style={{ fontSize: 28, marginTop: 28 }}>
              A visual preview to explore the style.
            </Label>
          </Box>
          <Box
            x={944}
            y={161}
            w={838}
            h={748}
            style={{ overflow: "hidden", borderRadius: 14, boxShadow: shadow }}
          >
            <FashionImage kind="result" />
          </Box>
        </>
      ) : stage === 2 ? (
        <>
          <Box
            x={110}
            y={190}
            w={616}
            h={717}
            style={{ overflow: "hidden", borderRadius: 13 }}
          >
            <FashionImage />
          </Box>
          <Box x={822} y={186} w={972}>
            <ShopperChat t={t} answer />
          </Box>
        </>
      ) : (
        <Inbox t={t} preview />
      )}
    </>
  );
};
const Brand = ({ t }: { t: number }) => {
  const index = t < 128.25 ? 0 : t < 130.59 ? 1 : 2;
  return (
    <>
      <Box
        x={110}
        y={155}
        w={745}
        h={752}
        style={{ overflow: "hidden", borderRadius: 14, boxShadow: shadow }}
      >
        <FashionImage kind="result" />
        <div style={{ position: "absolute", bottom: 26, left: 27 }}>
          <Badge style={{ background: "#fffffff0" }}>
            Illustrative fashion experience
          </Badge>
        </div>
      </Box>
      <Box x={1001} y={213} w={793}>
        <Eyebrow>Two tools. One considered journey.</Eyebrow>
        <div style={{ marginTop: 34 }}>
          {["See it.", "Understand it.", "Stay in control."].map((s, i) => (
            <div
              key={s}
              style={{
                fontSize: 74,
                lineHeight: 1.32,
                letterSpacing: -3,
                fontWeight: 450,
                color: i === index ? C.ink : "#c0bab0",
                transform: `translateX(${i === index ? 0 : 9}px)`,
              }}
            >
              {s}
            </div>
          ))}
        </div>
        <Label style={{ fontSize: 28, marginTop: 31, lineHeight: 1.5 }}>
          Virtual Try-On. Store Chat.
          <br />
          The human team, with context.
        </Label>
      </Box>
    </>
  );
};
const Close = ({ t }: { t: number }) => {
  const finale = t >= 141.839;
  const q = ease(t, 141.839, 0.85);
  return (
    <>
      <Box x={110} y={219} w={815}>
        <Eyebrow>GRINDCTRL / AI Visual Sales</Eyebrow>
        <Title size={81} style={{ marginTop: 35 }}>
          {finale ? (
            <>
              Let shoppers see it.
              <br />
              Let them ask.
            </>
          ) : (
            <>
              Explore the
              <br />
              product experience.
            </>
          )}
        </Title>
        <div style={{ marginTop: 35 }}>
          <Logo height={42} />
        </div>
        <div style={{ marginTop: 38, fontSize: 30, letterSpacing: -0.3 }}>
          grindctrl.cloud/try-on
        </div>
        <Label style={{ fontSize: 25, marginTop: 17 }}>
          For your Shopify fashion store.
        </Label>
      </Box>
      <Box
        x={1044 - mix(0, 10, q)}
        y={149}
        w={755}
        h={760}
        style={{ borderRadius: 14, overflow: "hidden", boxShadow: shadow }}
      >
        <FashionImage
          kind="result"
          style={{ transform: `scale(${mix(1.04, 1, ease(t, 133.974, 8))})` }}
        />
        <div style={{ position: "absolute", bottom: 25, left: 25 }}>
          <Badge style={{ background: "#ffffffed" }} icon="spark">
            Virtual Try-On / illustrative preview
          </Badge>
        </div>
      </Box>
      <Box
        x={939}
        y={600}
        w={244}
        h={288}
        style={{
          background: "white",
          padding: 7,
          borderRadius: 12,
          boxShadow: shadow,
          transform: `rotate(${mix(-4, -2, q)}deg)`,
        }}
      >
        <FashionImage style={{ borderRadius: 7 }} />
      </Box>
    </>
  );
};
export const Film03Scene: React.FC<{ id: string; t: number }> = ({ id, t }) => {
  const map: Record<string, React.FC<{ t: number }>> = {
    editorial: Editorial,
    store: Store,
    upload: Upload,
    reveal: Reveal,
    fit: Fit,
    question: Question,
    answer: Answer,
    handoff: Handoff,
    order: Order,
    journey: Journey,
    brand: Brand,
    close: Close,
  };
  const Comp = map[id];
  return <Comp t={t} />;
};
