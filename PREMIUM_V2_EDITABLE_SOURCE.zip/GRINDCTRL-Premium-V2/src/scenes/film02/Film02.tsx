import { cue } from "../../motion/cues";
import React from "react";
import { C, shadow } from "../../design-system/tokens";
import {
  Box,
  Window,
  Logo,
  Label,
  Avatar,
  Badge,
  Button,
  Tabs,
  Title,
  Eyebrow,
  Field,
} from "../../components/Primitives";
import {
  CallCard,
  CallStrip,
  PersonHeader,
  SearchField,
  ProfileFields,
  PHONE,
} from "../../components/ContactCenter";
import {
  ActivityWorkspace,
  ActivityRow,
  OwnedNote,
  CALLS,
  CallKey,
} from "../../components/CallHistory";
import { Icon } from "../../components/Icons";
import {
  Camera,
  Cursor,
  ease,
  mix,
  p,
  reveal,
  typing,
} from "../../motion/primitives";
import { Fallback, Pilot } from "../film01/Film01";
export const film02Shots = [
  { id: "arrival", start: 0, end: 15.916, title: "A repeat call" },
  {
    id: "overview",
    start: 15.916,
    end: 26.876,
    title: "A more useful target view",
  },
  {
    id: "profile",
    start: 26.876,
    end: 39.9,
    title: "Match then show permitted fields",
  },
  { id: "tiers", start: 39.9, end: 58.193, title: "Trusted membership source" },
  {
    id: "timeline",
    start: 58.193,
    end: 72.072,
    title: "An individual story for each call",
  },
  {
    id: "historical",
    start: 72.072,
    end: 87.976,
    title: "Open the original human note",
  },
  {
    id: "kinds",
    start: 87.976,
    end: 93.559,
    title: "Keep record types distinct",
  },
  {
    id: "write",
    start: 93.559,
    end: 104.323,
    title: "Write against the current interaction",
  },
  { id: "fallback", start: 104.323, end: 122.325, title: "Handle uncertainty" },
  {
    id: "pilot",
    start: 122.325,
    end: 135.823,
    title: "Verify storage and permissions",
  },
  {
    id: "future",
    start: 135.823,
    end: 145,
    title: "Retrieve without reassigning authorship",
  },
  { id: "close", start: 145, end: 150, title: "Every call has its own story" },
];
const Arrival = ({ t }: { t: number }) => {
  const target = t >= 9.383;
  return (
    <>
      <Box x={111} y={240} w={630}>
        <Eyebrow>Concrete / the next conversation</Eyebrow>
        <Title size={86} style={{ marginTop: 30 }}>
          Every call.
          <br />
          Its own story.
        </Title>
        <Label style={{ marginTop: 27, fontSize: 29, lineHeight: 1.5 }}>
          The next agent should have
          <br />a better starting point.
        </Label>
      </Box>
      <Box x={918} y={191} w={890}>
        {!target ? (
          <CallCard
            t={t}
            incoming={t < 2.474}
            style={{ width: 720, marginLeft: 76 }}
          />
        ) : (
          <Window
            title="Target view / after authorized matching"
            tag="PROPOSED"
            style={{ height: 714 }}
          >
            <CallStrip />
            <div style={{ padding: 31 }}>
              <PersonHeader small email={false} />
              <div style={{ marginTop: 28, opacity: ease(t, 11.474) }}>
                <div style={{ fontSize: 25, color: C.muted, marginBottom: 13 }}>
                  Earlier call activity
                </div>
                <div style={{ fontSize: 27, marginTop: 19 }}>
                  CALL-101 · 15 Oct · Maya
                </div>
                <div style={{ marginTop: 20, opacity: ease(t, 12.974) }}>
                  <OwnedNote id="CALL-101" size={29} t={t} start={12.974} />
                </div>
              </div>
            </div>
          </Window>
        )}
      </Box>
    </>
  );
};
const Overview = ({ t }: { t: number }) => (
  <>
    <Box x={109} y={139}>
      <Eyebrow>Customer 360 / proposed target after matching</Eyebrow>
    </Box>
    <Camera
      t={t}
      start={15.916}
      end={26.6}
      from={[0, 0, 0.97]}
      to={[-5, -6, 1]}
    >
      <Window
        title="A clearer customer view"
        tag="ILLUSTRATIVE CONCEPT"
        style={{
          position: "absolute",
          left: 111,
          top: 190,
          width: 1700,
          height: 716,
        }}
      >
        <CallStrip />
        <div style={{ display: "flex", padding: 32, gap: 46 }}>
          <div
            style={{
              width: 485,
              paddingRight: 33,
              borderRight: `1px solid ${C.line}`,
            }}
          >
            <PersonHeader />
            <div style={{ marginTop: 23 }}>
              <Badge tone="amber">Elite · fictional membership</Badge>
            </div>
            <div style={{ fontSize: 26, marginTop: 29 }}>{PHONE}</div>
            <Label style={{ fontSize: 23, marginTop: 26 }}>
              Record data, shown only with
              <br />
              the appropriate permissions.
            </Label>
          </div>
          <div style={{ flex: 1 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 22,
              }}
            >
              <div style={{ fontSize: 32, fontWeight: 500 }}>
                Call Activities
              </div>
              <Badge icon="note">Human notes</Badge>
            </div>
            <div style={{ fontSize: 27, marginBottom: 13 }}>
              CALL-101 · 15 Oct · Maya
            </div>
            <OwnedNote id="CALL-101" size={32} t={t} start={20.022} />
            <div style={{ fontSize: 23, color: C.muted, marginTop: 19 }}>
              Original call · original author · original time
            </div>
          </div>
        </div>
      </Window>
    </Camera>
  </>
);
const Profile = ({ t }: { t: number }) => {
  const matched = t >= 31.213;
  const missing = t >= 37.053;
  return (
    <>
      <Box x={111} y={143}>
        <Eyebrow>Phone → reliable match → permitted profile</Eyebrow>
      </Box>
      <Box x={112} y={237} w={541}>
        <CallCard t={t} matched={matched} style={{ width: 541 }} />
      </Box>
      <Box x={764} y={199} w={1045}>
        <Window title="Customer profile" tag="PROPOSED / ACCESS CHECKS">
          <div style={{ padding: "34px 41px" }}>
            {!matched ? (
              <>
                <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
                  <Avatar name="?" size={85} />
                  <div>
                    <Title size={38}>
                      {t >= 29.31 ? "Candidate matched" : "Looking up customer"}
                    </Title>
                    <Label style={{ marginTop: 10 }}>
                      Context remains private until checks complete.
                    </Label>
                  </div>
                </div>
                <div style={{ marginTop: 39 }}>
                  <SearchField text={PHONE} />
                </div>
                <div style={{ display: "flex", gap: 20, marginTop: 38 }}>
                  <Badge icon="lock">Match check</Badge>
                  <Badge icon="shield">Access check</Badge>
                </div>
                <div style={{ height: 4, marginTop: 38, background: C.soft }}>
                  <div
                    style={{
                      width: `${p(t, 26.876, 4.337) * 100}%`,
                      height: 4,
                      background: C.green,
                    }}
                  />
                </div>
              </>
            ) : (
              <>
                <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
                  <Avatar size={85} />
                  <div>
                    <Title size={43}>Ahmed M.</Title>
                    <Badge tone="green" icon="shield" style={{ marginTop: 12 }}>
                      Permitted matched record
                    </Badge>
                  </div>
                </div>
                <div style={{ marginTop: 27 }}>
                  <Field label="Phone number" icon="phone">
                    {PHONE}
                  </Field>
                  <Field label="Customer name" icon="user">
                    Ahmed M.
                  </Field>
                  <div style={{ opacity: ease(t, 35.046) }}>
                    <Field
                      label={
                        missing ? "Email / missing-field example" : "Email"
                      }
                      icon="mail"
                    >
                      {missing ? (
                        <span style={{ color: C.muted }}>Unavailable</span>
                      ) : (
                        "ahmed@example.com"
                      )}
                    </Field>
                  </div>
                </div>
              </>
            )}
          </div>
        </Window>
      </Box>
    </>
  );
};
const Tiers = ({ t }: { t: number }) => {
  const trusted = t >= 47.119;
  const selected = t >= cue("02", "trusted_source");
  return (
    <>
      <Box x={110} y={158} w={545}>
        <Eyebrow>Concrete Icons Club</Eyebrow>
        <Title size={73} style={{ marginTop: 28 }}>
          Membership,
          <br />
          from a record.
        </Title>
        <Label style={{ fontSize: 29, marginTop: 28, lineHeight: 1.5 }}>
          A trusted source.
          <br />
          No inferred tier or invented benefit.
        </Label>
        <div style={{ marginTop: 36 }}>
          <Badge icon="shield">Source must be verified</Badge>
        </div>
      </Box>
      <Box x={756} y={185} w={1049}>
        <Window title="Customer profile / Icons Club" tag="PROPOSED">
          <div style={{ padding: "33px 39px" }}>
            <PersonHeader small email={false} />
            <div
              style={{
                borderTop: `1px solid ${C.line}`,
                marginTop: 28,
                paddingTop: 29,
              }}
            >
              <Label>Icons Club membership tier</Label>
              <div style={{ display: "flex", gap: 12, marginTop: 22 }}>
                {["Lifestyle", "Prestige", "Elite"].map((s, i) => (
                  <div
                    key={s}
                    style={{
                      padding: "19px 27px",
                      borderRadius: 9,
                      border: `1px solid ${selected && i === 2 ? "#b49c73" : C.line}`,
                      background: selected && i === 2 ? C.amberSoft : "white",
                      fontSize: 29,
                      color: selected && i === 2 ? C.amber : C.muted,
                      opacity: t > 44.454 + i * 0.65 ? 1 : 0.25,
                    }}
                  >
                    {s}
                  </div>
                ))}
              </div>
              <div
                style={{
                  marginTop: 33,
                  padding: "24px 26px",
                  background: trusted ? C.greenSoft : C.soft,
                  borderRadius: 11,
                  ...reveal(t, 47.119),
                }}
              >
                <div
                  style={{
                    display: "flex",
                    gap: 13,
                    alignItems: "center",
                    color: trusted ? C.green : C.muted,
                    fontSize: 26,
                  }}
                >
                  <Icon name="lock" />
                  {trusted
                    ? "Authoritative membership data required"
                    : "Membership source not yet verified"}
                </div>
                <Label style={{ fontSize: 23, marginTop: 13 }}>
                  {selected
                    ? "Elite · illustrative trusted-source record"
                    : "Do not infer membership from phone or behaviour."}
                </Label>
              </div>
              <Label style={{ fontSize: 22, marginTop: 26 }}>
                Lifestyle / Prestige / Elite are tier names only.
                <br />
                Benefits and data source require confirmation.
              </Label>
            </div>
          </div>
        </Window>
      </Box>
    </>
  );
};
const Timeline = ({ t }: { t: number }) => {
  const open = ease(t, 69.415, 0.8);
  return (
    <>
      <Box x={110} y={141}>
        <Eyebrow>Call Activities / distinct interactions</Eyebrow>
      </Box>
      <Window
        title="Customer 360 / call timeline"
        tag="PROPOSED EXPERIENCE"
        style={{
          position: "absolute",
          left: 111,
          top: 193,
          width: 1700,
          height: 715,
        }}
      >
        <div style={{ display: "flex", height: "100%" }}>
          <div
            style={{
              width: 410,
              background: "#f6f4ee",
              padding: "45px 33px",
              borderRight: `1px solid ${C.line}`,
            }}
          >
            <PersonHeader email={false} />
            <div style={{ marginTop: 29, fontSize: 26 }}>{PHONE}</div>
            <div style={{ marginTop: 27 }}>
              <Badge tone="amber">Elite · demo</Badge>
            </div>
            <Title size={45} style={{ marginTop: 43 }}>
              A profile is
              <br />
              the beginning.
            </Title>
            <Label style={{ fontSize: 25, marginTop: 22 }}>
              Each call has its own record.
            </Label>
          </div>
          <div style={{ flex: 1, padding: "0 35px 22px" }}>
            <Tabs
              items={["Call Activities", "Ticket updates", "AI summaries"]}
            />
            <div style={{ paddingTop: 25, height: 580, overflow: "hidden" }}>
              <div>
                {(["CALL-102", "CALL-101", "CALL-100"] as CallKey[]).map(
                  (id, i) => (
                    <div
                      key={id}
                      style={{
                        opacity:
                          ease(t, 63.466 + i * 0.35, 0.5) *
                          (id === "CALL-101" ? 1 : 1 - ease(t, 69.415, 0.25)),
                        height:
                          id === "CALL-101"
                            ? "auto"
                            : mix(190, 0, ease(t, 69.72, 0.55)),
                        overflow: "hidden",
                      }}
                    >
                      <ActivityRow
                        id={id}
                        selected={id === "CALL-101"}
                        expand={id === "CALL-101" ? open : 0}
                        t={t}
                        noteStart={69.7}
                      />
                    </div>
                  ),
                )}
              </div>
            </div>
          </div>
        </div>
      </Window>
    </>
  );
};
const Historical = ({ t }: { t: number }) => {
  const q = ease(t, 81.518, 0.8);
  return (
    <>
      <Box x={110} y={141}>
        <Eyebrow>Open one call / read its original human note</Eyebrow>
      </Box>
      <Camera
        t={t}
        start={81.518}
        end={85.98}
        from={[0, 0, 1]}
        to={[-4, -14, 1.035]}
      >
        <Window
          title="Call Activities / Ahmed M."
          tag="PROPOSED / FICTIONAL RECORDS"
          style={{
            position: "absolute",
            left: 111,
            top: 194,
            width: 1699,
            height: 715,
          }}
        >
          <CallStrip />
          <div style={{ display: "flex", padding: "31px 35px", gap: 36 }}>
            <div
              style={{
                width: 450,
                borderRight: `1px solid ${C.line}`,
                paddingRight: 32,
              }}
            >
              <Label>Selected previous interaction</Label>
              <div
                style={{
                  display: "flex",
                  gap: 18,
                  alignItems: "center",
                  marginTop: 25,
                }}
              >
                <div
                  style={{
                    width: 62,
                    height: 62,
                    borderRadius: 17,
                    background: C.greenSoft,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Icon name="phone" size={29} color={C.green} />
                </div>
                <div>
                  <div style={{ fontSize: 36, fontWeight: 520 }}>CALL-101</div>
                  <Label style={{ marginTop: 7 }}>15 Oct 2026 · 11:08</Label>
                </div>
              </div>
              <div style={{ marginTop: 29, fontSize: 31 }}>
                Exchange request
              </div>
              <div
                style={{
                  marginTop: 27,
                  display: "flex",
                  alignItems: "center",
                  gap: 17,
                }}
              >
                <Avatar name="M" size={55} />
                <div style={{ fontSize: 28 }}>
                  Maya <Label style={{ fontSize: 21 }}>Original agent</Label>
                </div>
              </div>
              <div style={{ marginTop: 36 }}>
                <Badge icon="lock">Belongs to CALL-101</Badge>
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: 23,
                }}
              >
                <div style={{ fontSize: 30 }}>Note for this interaction</div>
                <Label style={{ fontSize: 21 }}>Recorded 15 Oct · 11:12</Label>
              </div>
              <OwnedNote id="CALL-101" size={40} t={t} start={72.8} />
              <div
                style={{
                  marginTop: 25,
                  display: "flex",
                  alignItems: "center",
                  gap: 13,
                  color: C.green,
                  fontSize: 25,
                  ...reveal(t, 81.518),
                }}
              >
                <Icon name="eye" size={23} />
                Salma reads Maya’s original note.
              </div>
            </div>
          </div>
        </Window>
      </Camera>
      <Cursor
        t={t}
        points={[
          [80, 590, 770],
          [81.15, 330, 440],
          [81.6, 330, 440],
          [82.5, 1145, 536],
        ]}
        clicks={[81.518]}
      />
    </>
  );
};
const Kinds = ({ t }: { t: number }) => (
  <>
    <Box x={110} y={141}>
      <Eyebrow>Same customer / different record types</Eyebrow>
    </Box>
    <Box x={113} y={235} w={1050}>
      <Window title="CALL-101 / Maya" tag="HUMAN-AUTHORED">
        <div style={{ padding: 35 }}>
          <OwnedNote id="CALL-101" size={41} t={t} start={87.976} />
        </div>
      </Window>
    </Box>
    <Box x={1252} y={252} w={530}>
      <Title size={52}>
        A call note.
        <br />
        Precisely that.
      </Title>
      <div
        style={{ marginTop: 36, fontSize: 29, color: C.muted, lineHeight: 1.8 }}
      >
        <div style={{ display: "flex", gap: 13, alignItems: "center" }}>
          <Icon name="ticket" />
          Ticket update
        </div>
        <div style={{ display: "flex", gap: 13, alignItems: "center" }}>
          <Icon name="spark" />
          AI summary
        </div>
        <div style={{ display: "flex", gap: 13, alignItems: "center" }}>
          <Icon name="check" />
          Completed action
        </div>
      </div>
      <Label style={{ marginTop: 25 }}>
        Separate records. Separate meaning.
      </Label>
    </Box>
  </>
);
const Write = ({ t }: { t: number }) => {
  const saved = t >= 99.752;
  return (
    <>
      <Box x={110} y={140}>
        <Eyebrow>Current interaction / new human note</Eyebrow>
      </Box>
      <Window
        title="Customer 360 / current call"
        tag="PROPOSED WRITE FLOW / IF SUPPORTED"
        style={{
          position: "absolute",
          left: 110,
          top: 194,
          width: 1700,
          height: 717,
        }}
      >
        <CallStrip />
        <div style={{ display: "flex", padding: "31px 36px", gap: 37 }}>
          <div
            style={{
              width: 425,
              paddingRight: 32,
              borderRight: `1px solid ${C.line}`,
            }}
          >
            <Label>Current interaction</Label>
            <div style={{ fontSize: 46, letterSpacing: -1, marginTop: 23 }}>
              CALL-102
            </div>
            <div style={{ fontSize: 26, color: C.muted, marginTop: 14 }}>
              22 Oct 2026 · 14:32
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 18,
                marginTop: 29,
              }}
            >
              <Avatar name="S" size={62} />
              <div style={{ fontSize: 30 }}>
                Salma<Label style={{ fontSize: 22 }}>Current agent</Label>
              </div>
            </div>
            <div style={{ marginTop: 34 }}>
              <Badge icon="lock">Note owner stays CALL-102</Badge>
            </div>
            <Label style={{ marginTop: 28 }}>CALL-101 remains unchanged.</Label>
          </div>
          <div style={{ flex: 1 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 21,
              }}
            >
              <div style={{ fontSize: 31 }}>Call note</div>
              <Badge
                tone={saved ? "green" : "neutral"}
                icon={saved ? "check" : "note"}
              >
                {saved ? "Saved to CALL-102" : "Draft · human authored"}
              </Badge>
            </div>
            <div
              data-note-call="CALL-102"
              data-note-author="Salma"
              style={{
                border: `1px solid ${saved ? "#c6d6c8" : "#c8bfae"}`,
                borderRadius: 12,
                padding: "27px 30px",
                height: 219,
                background: saved ? "#f4f7f2" : "#fffdf9",
                fontSize: 36,
                lineHeight: 1.4,
                letterSpacing: -0.45,
              }}
            >
              {typing(CALLS["CALL-102"].note, t, cue("02", "write_note"), 2.7)}
              {!saved && (
                <span
                  style={{
                    display: "inline-block",
                    height: 35,
                    width: 2,
                    background: C.ink,
                    marginLeft: 2,
                  }}
                />
              )}
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginTop: 24,
              }}
            >
              <Label style={{ fontSize: 23 }}>Salma · 22 Oct · 14:39</Label>
              <Button
                icon={saved ? "check" : "note"}
                style={{
                  background: saved ? C.green : C.ink,
                  borderColor: saved ? C.green : C.ink,
                }}
              >
                {saved ? "Saved to this call" : "Save call note"}
              </Button>
            </div>
            <Label style={{ fontSize: 22, marginTop: 24 }}>
              Proposed storage and write mechanism require validation.
            </Label>
          </div>
        </div>
      </Window>
      <Cursor
        t={t}
        points={[
          [98.5, 1390, 681],
          [99.4, 1626, 749],
          [99.85, 1626, 749],
          [100.5, 1730, 787],
        ]}
        clicks={[99.752]}
      />
    </>
  );
};
const Future = ({ t }: { t: number }) => (
  <>
    <Box x={110} y={141}>
      <Eyebrow>Later interaction / preserve the original note</Eyebrow>
    </Box>
    <Window
      title="Customer 360 / later contact"
      tag="PROPOSED / FICTIONAL RECORDS"
      style={{
        position: "absolute",
        left: 111,
        top: 193,
        width: 1700,
        height: 716,
      }}
    >
      <CallStrip id="CALL-103" agent="Youssef" />
      <div style={{ display: "flex", padding: "31px 36px", gap: 36 }}>
        <div
          style={{
            width: 425,
            borderRight: `1px solid ${C.line}`,
            paddingRight: 30,
          }}
        >
          <Label>Current call · 29 Oct</Label>
          <Title size={47} style={{ marginTop: 18 }}>
            CALL-103
          </Title>
          <div
            style={{
              display: "flex",
              gap: 17,
              alignItems: "center",
              marginTop: 27,
            }}
          >
            <Avatar name="Y" size={59} />
            <div style={{ fontSize: 29 }}>
              Youssef
              <Label style={{ fontSize: 21 }}>Reading earlier activity</Label>
            </div>
          </div>
          <div style={{ marginTop: 34 }}>
            <Badge>Open original CALL-102</Badge>
          </div>
          <Label style={{ fontSize: 24, marginTop: 28 }}>
            Reading does not change authorship.
          </Label>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 30, marginBottom: 22 }}>
            Previous call · 22 Oct · CALL-102
          </div>
          <OwnedNote id="CALL-102" size={39} t={t} start={136.2} />
          <div
            style={{
              marginTop: 24,
              fontSize: 25,
              color: C.green,
              display: "flex",
              gap: 12,
              alignItems: "center",
            }}
          >
            <Icon name="lock" />
            Still Salma’s note. Still linked to CALL-102.
          </div>
        </div>
      </div>
    </Window>
  </>
);
const Close = ({ t }: { t: number }) => (
  <>
    <Box x={110} y={234} w={750}>
      <Eyebrow>GRINDCTRL × Concrete</Eyebrow>
      <Title size={83} style={{ marginTop: 30 }}>
        Every call has
        <br />
        its own story.
      </Title>
      <Label style={{ fontSize: 30, marginTop: 30 }}>
        Keep the customer context.
        <br />
        Keep the original authorship.
      </Label>
    </Box>
    <Box x={1015} y={247} w={775}>
      <Window title="CALL-102 / Salma" tag="ORIGINAL HUMAN NOTE">
        <div style={{ padding: 31 }}>
          <OwnedNote id="CALL-102" size={36} t={t} start={145} />
        </div>
      </Window>
      <div
        style={{
          marginTop: 28,
          display: "flex",
          alignItems: "center",
          gap: 11,
          fontSize: 26,
          color: C.green,
        }}
      >
        <Icon name="shield" />A proposed experience to validate.
      </div>
    </Box>
  </>
);
export const Film02Scene: React.FC<{ id: string; t: number }> = ({ id, t }) => {
  const map: Record<string, React.FC<{ t: number }>> = {
    arrival: Arrival,
    overview: Overview,
    profile: Profile,
    tiers: Tiers,
    timeline: Timeline,
    historical: Historical,
    kinds: Kinds,
    write: Write,
    future: Future,
    close: Close,
  };
  if (id === "fallback") return <Fallback t={t} film="02" />;
  if (id === "pilot") return <Pilot t={t} film="02" />;
  const Comp = map[id];
  return <Comp t={t} />;
};
