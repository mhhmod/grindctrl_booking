import { asset } from "../components/assets";
import React from "react";
import { AbsoluteFill, Audio, Sequence, useCurrentFrame } from "remotion";
import { C } from "../design-system/tokens";
import { Header, Footer } from "../components/Primitives";
import { Film01Scene, film01Shots } from "../scenes/film01/Film01";
import { Film02Scene, film02Shots } from "../scenes/film02/Film02";
import { Film03Scene, film03Shots } from "../scenes/film03/Film03";
import { ease, mix } from "../motion/primitives";
import audio from "../../timelines/approved-audio-and-captions.json";
export const SHOTS = {
  "01": film01Shots,
  "02": film02Shots,
  "03": film03Shots,
};
export type FilmId = keyof typeof SHOTS;
export const Film: React.FC<{
  film: FilmId;
  mute?: boolean;
  captioned?: boolean;
  reducedMotion?: boolean;
}> = ({ film, mute = false, captioned = true, reducedMotion = false }) => {
  const frame = useCurrentFrame(),
    t = frame / 30;
  const SceneComp =
    film === "01" ? Film01Scene : film === "02" ? Film02Scene : Film03Scene;
  const shots = SHOTS[film];
  const cap = audio
    .find((f) => f.id === film)!
    .captions.find((c) => t >= c.start && t < c.end);
  return (
    <AbsoluteFill
      data-film={film}
      data-frame={frame}
      style={{
        fontFamily: "Geist,Arial,sans-serif",
        color: C.ink,
        background: C.paper,
        overflow: "hidden",
        WebkitFontSmoothing: "antialiased",
        fontFeatureSettings: '"ss01"',
        fontVariantNumeric: "tabular-nums",
      }}
    >
      {shots.map((s, i) => {
        const from = Math.round(s.start * 30);
        return (
          <Sequence
            key={s.id}
            name={s.title}
            from={from}
            durationInFrames={Math.min(
              4500 - from,
              Math.round((s.end - s.start) * 30) + 20,
            )}
          >
            <AbsoluteFill
              data-scene={s.id}
              style={{
                background: C.paper,
                opacity: reducedMotion ? 1 : ease(t, s.start, 0.55),
                transform: reducedMotion
                  ? "none"
                  : `translateX(${mix(18, 0, ease(t, s.start, 0.65))}px)`,
              }}
            >
              <SceneComp id={s.id} t={t} />
            </AbsoluteFill>
          </Sequence>
        );
      })}
      <Header film={film} />
      <Footer film={film} />
      {captioned && cap && (
        <div
          data-caption
          style={{
            position: "absolute",
            left: 150,
            right: 150,
            bottom: 61,
            display: "flex",
            justifyContent: "center",
            pointerEvents: "none",
          }}
        >
          <div
            style={{
              fontSize: 30,
              lineHeight: 1.28,
              fontWeight: 440,
              textAlign: "center",
              maxWidth: 1600,
              padding: "15px 26px",
              borderRadius: 12,
              color: C.ink,
              background: "#fffefbf5",
              border: "1px solid #e8e3da",
              boxShadow: "0 5px 18px #5b4b2d08",
            }}
          >
            {cap.text}
          </div>
        </div>
      )}
      {!mute && <Audio src={asset("audio/" + film + "-approved-mix.m4a")} />}
    </AbsoluteFill>
  );
};
