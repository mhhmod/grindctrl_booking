import React from "react";
import { interpolate, spring, Easing, AbsoluteFill } from "remotion";
export const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
export const p = (t: number, start: number, d = 0.5) => clamp((t - start) / d);
export const ease = (t: number, start: number, d = 0.5) =>
  Easing.bezier(0.22, 1, 0.36, 1)(p(t, start, d));
export const mix = (a: number, b: number, x: number) =>
  interpolate(x, [0, 1], [a, b], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
export const damp = (t: number, start: number, d = 0.6) =>
  spring({
    frame: (t - start) * 30,
    fps: 30,
    durationInFrames: Math.round(d * 30),
    config: { damping: 25, stiffness: 135, overshootClamping: true },
  });
export const typing = (text: string, t: number, start: number, d = 1.3) =>
  text.slice(0, Math.floor(text.length * p(t, start, d)));
export const visible = (t: number, start: number) => ({
  opacity: ease(t, start, 0.35),
});
export const reveal = (t: number, start: number, dy = 18) => ({
  opacity: ease(t, start, 0.5),
  transform: `translateY(${mix(dy, 0, ease(t, start, 0.6))}px)`,
});
export const Scene: React.FC<{
  t: number;
  start: number;
  children: React.ReactNode;
  white?: boolean;
}> = ({ t, start, children, white }) => {
  const q = ease(t, start, 0.6);
  return (
    <AbsoluteFill
      style={{
        background: white ? "#fff" : "#faf8f5",
        opacity: q,
        transform: `translateX(${mix(28, 0, q)}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
export const Camera: React.FC<{
  t: number;
  start: number;
  end: number;
  from?: [number, number, number];
  to?: [number, number, number];
  children: React.ReactNode;
}> = ({ t, start, end, from = [0, 0, 1], to = [0, 0, 1], children }) => {
  const q = ease(t, start, end - start);
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${mix(from[0], to[0], q)}px,${mix(from[1], to[1], q)}px) scale(${mix(from[2], to[2], q)})`,
        transformOrigin: "50% 48%",
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
export const Cursor: React.FC<{
  t: number;
  points: [number, number, number][];
  clicks?: number[];
}> = ({ t, points, clicks = [] }) => {
  if (t < points[0][0] || t > points[points.length - 1][0] + 0.7) return null;
  let a = points[0],
    b = points.at(-1)!;
  for (let i = 1; i < points.length; i++) {
    if (t <= points[i][0]) {
      a = points[i - 1];
      b = points[i];
      break;
    }
  }
  const q = ease(t, a[0], Math.max(0.01, b[0] - a[0])),
    x = mix(a[1], b[1], q),
    y = mix(a[2], b[2], q);
  const hit = clicks.find((c) => t >= c && t < c + 0.5);
  const h = hit === undefined ? 1 : p(t, hit, 0.5);
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        zIndex: 50,
        pointerEvents: "none",
      }}
    >
      {hit !== undefined && (
        <div
          style={{
            position: "absolute",
            left: -22,
            top: -22,
            width: 44,
            height: 44,
            border: "2px solid #9d8b6b",
            borderRadius: 50,
            opacity: 1 - h,
            transform: `scale(${0.6 + h})`,
          }}
        />
      )}
      <svg
        width="30"
        height="35"
        viewBox="0 0 30 35"
        style={{ filter: "drop-shadow(0 2px 2px #0002)" }}
      >
        <path
          d="M3 2v25l7-7 6 12 5-3-6-11h11z"
          fill="#2a2826"
          stroke="white"
          strokeWidth="2"
        />
      </svg>
    </div>
  );
};
export const Sweep: React.FC<{ t: number; start: number; width?: number }> = ({
  t,
  start,
  width = 500,
}) => {
  const q = p(t, start, 1);
  if (q <= 0 || q >= 1) return null;
  return (
    <div
      style={{
        position: "absolute",
        left: width * q - 80,
        top: 0,
        bottom: 0,
        width: 80,
        background:
          "linear-gradient(90deg,transparent,rgba(255,255,255,.8),transparent)",
        transform: "skewX(-12deg)",
      }}
    />
  );
};
