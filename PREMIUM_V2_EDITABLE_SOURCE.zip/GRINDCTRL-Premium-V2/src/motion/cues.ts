import manifest from "../../timelines/actual_audio_cues.json";
export const cue = (film: "01" | "02" | "03", event: string) => {
  const row = manifest[film].find((x) => x.event === event);
  if (!row) throw new Error(`Missing measured audio cue: ${film}/${event}`);
  return row.start_sec;
};
