import React, { useState, useRef, useEffect } from "react";
import { createRoot } from "react-dom/client";
import { Player, PlayerRef } from "@remotion/player";
import { Film, FilmId, SHOTS } from "./compositions/Film";
import "./design-system/global.css";
declare global {
  interface Window {
    __GRINDCTRL_FILM: FilmId;
    __GRINDCTRL_PLAYER: PlayerRef | null;
    __GRINDCTRL_STATE: { frame: number; film: FilmId };
    __GRINDCTRL_READY: boolean;
    __GRINDCTRL_QA?: boolean;
  }
}
const App = () => {
  const film = window.__GRINDCTRL_FILM;
  const player = useRef<PlayerRef>(null);
  const [captioned, setCaptioned] = useState(true);
  const [frame, setFrame] = useState(0);
  const [staticMode, setStaticMode] = useState(
    window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  useEffect(() => {
    window.__GRINDCTRL_PLAYER = player.current;
    const update = (e: any) => {
      setFrame(e.detail.frame);
      window.__GRINDCTRL_STATE = { film, frame: e.detail.frame };
    };
    player.current?.addEventListener("frameupdate", update);
    document.fonts.ready.then(() => {
      window.__GRINDCTRL_READY = true;
    });
    return () => player.current?.removeEventListener("frameupdate", update);
  }, [film]);
  const seek = (f: number) => {
    player.current?.pause();
    player.current?.seekTo(Math.max(0, Math.min(4499, f)));
  };
  const next = (d: number) => {
    const shots = SHOTS[film];
    let i = shots.findIndex(
      (s) =>
        frame >= Math.round(s.start * 30) && frame < Math.round(s.end * 30),
    );
    i = Math.min(shots.length - 1, Math.max(0, i + d));
    seek(
      Math.round(
        (shots[i].start + Math.min(2.5, (shots[i].end - shots[i].start) / 2)) *
          30,
      ),
    );
  };
  const name = {
    "01": "The call arrives. The context appears.",
    "02": "Every call has its own story.",
    "03": "Let shoppers see it. Let them ask.",
  }[film];
  return (
    <main
      style={{
        maxWidth: 1600,
        margin: "0 auto",
        padding: "24px clamp(12px,3vw,40px)",
        fontFamily: "Geist,Arial,sans-serif",
        color: "#2a2826",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: 15,
          alignItems: "center",
          marginBottom: 20,
          flexWrap: "wrap",
        }}
      >
        <div>
          <div style={{ fontSize: 12, letterSpacing: 2, color: "#7e7971" }}>
            GRINDCTRL / PREMIUM V2 / FILM {film}
          </div>
          <h1
            style={{
              fontSize: "clamp(20px,3vw,34px)",
              fontWeight: 500,
              letterSpacing: -1,
              margin: "8px 0",
            }}
          >
            {name}
          </h1>
        </div>
        <span style={{ fontSize: 14, color: "#7e7971" }}>
          150 seconds · synchronized source preview
        </span>
      </div>
      <div
        style={{
          borderRadius: 14,
          overflow: "hidden",
          boxShadow: "0 20px 65px -30px #58462d44",
          background: "#faf8f5",
        }}
      >
        <Player
          ref={player}
          component={Film}
          inputProps={{ film, captioned, reducedMotion: staticMode }}
          durationInFrames={4500}
          fps={30}
          compositionWidth={1920}
          compositionHeight={1080}
          style={{ width: "100%" }}
          controls={!window.__GRINDCTRL_QA}
          autoPlay={false}
          loop={false}
          showVolumeControls
          clickToPlay={!staticMode}
          doubleClickToFullscreen
          showPosterWhenPaused={false}
        />
      </div>
      <nav
        aria-label="Presentation controls"
        style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 20 }}
      >
        <button
          onClick={() => {
            setStaticMode(false);
            player.current?.toggle();
          }}
        >
          Play / pause
        </button>
        <button
          onClick={() => {
            seek(0);
            setStaticMode(false);
            player.current?.play();
          }}
        >
          Replay
        </button>
        <button onClick={() => next(-1)}>Previous scene</button>
        <button onClick={() => next(1)}>Next scene</button>
        <button onClick={() => seek(frame - 1)}>−1 frame</button>
        <button onClick={() => seek(frame + 1)}>+1 frame</button>
        <button
          onClick={() => setCaptioned(!captioned)}
          aria-pressed={captioned}
        >
          Captions {captioned ? "on" : "off"}
        </button>
        <button
          onClick={() => {
            player.current?.pause();
            setStaticMode(!staticMode);
          }}
          aria-pressed={staticMode}
        >
          Static step mode {staticMode ? "on" : "off"}
        </button>
      </nav>
      <div
        style={{
          fontSize: 14,
          color: "#7e7971",
          lineHeight: 1.6,
          marginTop: 16,
        }}
      >
        {staticMode
          ? "Reduced-motion preference respected: preview starts paused. Step through scenes, or explicitly choose Play for the animated experience."
          : "All animation follows the exact frame/audio clock. Use scene buttons to inspect any stage."}
        <br />
        {film === "03"
          ? "Illustrative product demonstration with synthetic fashion assets."
          : "Proposed Concrete experience. Fictional records; actual deployment, access, storage and permissions require validation."}
      </div>
      <details style={{ marginTop: 18 }}>
        <summary style={{ cursor: "pointer", minHeight: 44, fontSize: 15 }}>
          Scene navigation
        </summary>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {SHOTS[film].map((s) => (
            <button
              key={s.id}
              onClick={() => seek(Math.round((s.start + 0.8) * 30))}
            >
              {s.title}
            </button>
          ))}
        </div>
      </details>
    </main>
  );
};
createRoot(document.getElementById("root")!).render(<App />);
