import React from "react";
import { C } from "../design-system/tokens";
import { Avatar, Badge, Button, Label, Window, Tabs } from "./Primitives";
import { Icon } from "./Icons";
import { CallStrip, PersonHeader } from "./ContactCenter";
import { ease, mix, p, reveal, typing } from "../motion/primitives";
export type CallKey = "CALL-100" | "CALL-101" | "CALL-102" | "CALL-103";
export const CALLS: Record<
  CallKey,
  {
    date: string;
    time: string;
    agent: string;
    initial: string;
    subject: string;
    note: string;
    noteTime: string;
  }
> = {
  "CALL-100": {
    date: "08 Oct 2026",
    time: "09:22",
    agent: "Omar",
    initial: "O",
    subject: "Product enquiry",
    note: "Customer asked about the care guide. Product information was shared.",
    noteTime: "09:26",
  },
  "CALL-101": {
    date: "15 Oct 2026",
    time: "11:08",
    agent: "Maya",
    initial: "M",
    subject: "Exchange request",
    note: "Customer requested an exchange. Branch review pending.",
    noteTime: "11:12",
  },
  "CALL-102": {
    date: "22 Oct 2026",
    time: "14:32",
    agent: "Salma",
    initial: "S",
    subject: "Exchange follow-up",
    note: "Customer followed up; awaiting a confirmed branch update.",
    noteTime: "14:39",
  },
  "CALL-103": {
    date: "29 Oct 2026",
    time: "10:16",
    agent: "Youssef",
    initial: "Y",
    subject: "Later customer contact",
    note: "",
    noteTime: "",
  },
};
export const OwnedNote: React.FC<{
  id: CallKey;
  size?: number;
  t?: number;
  start?: number;
  draft?: boolean;
}> = ({ id, size = 36, t = 100, start = 0, draft }) => {
  const c = CALLS[id];
  return (
    <div
      data-note-call={id}
      data-note-author={c.agent}
      style={{
        border: `1px solid #e2e7e0`,
        background: "#f4f7f2",
        borderRadius: 13,
        padding: "27px 31px",
        ...reveal(t, start, 13),
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 15,
        }}
      >
        <Badge icon="note" tone="green" style={{ fontSize: 20 }}>
          Human call note
        </Badge>
        <Label style={{ fontSize: 21 }}>{draft ? "Draft" : c.noteTime}</Label>
      </div>
      <div
        style={{
          fontSize: size,
          lineHeight: 1.35,
          letterSpacing: -0.55,
          marginTop: 22,
          fontWeight: 420,
        }}
      >
        {draft ? typing(c.note, t, start, 2.1) : c.note}
      </div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 13,
          marginTop: 26,
        }}
      >
        <Avatar name={c.initial} size={41} />
        <div style={{ fontSize: 22 }}>
          {c.agent}{" "}
          <span style={{ color: C.muted }}>
            · {c.date} · {id}
          </span>
        </div>
      </div>
    </div>
  );
};
export const ActivityRow: React.FC<{
  id: CallKey;
  selected?: boolean;
  expand?: number;
  t: number;
  noteStart?: number;
  future?: boolean;
}> = ({ id, selected, expand = 0, t, noteStart = 0, future }) => {
  const c = CALLS[id];
  return (
    <div
      data-call={id}
      style={{ position: "relative", paddingLeft: 59, paddingBottom: 23 }}
    >
      <div
        style={{
          position: "absolute",
          left: 16,
          top: 7,
          width: 26,
          height: 26,
          borderRadius: "50%",
          border: `1.5px solid ${selected ? C.green : C.line}`,
          background: selected ? C.greenSoft : "white",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1,
        }}
      >
        {selected && (
          <span
            style={{
              width: 8,
              height: 8,
              background: C.green,
              borderRadius: "50%",
            }}
          />
        )}
      </div>
      <div
        style={{
          position: "absolute",
          left: 28,
          top: 33,
          bottom: -9,
          width: 1,
          background: C.line,
        }}
      />
      <div
        style={{
          padding: "19px 23px",
          borderRadius: 12,
          background: selected ? "#f3f5f0" : "transparent",
          border: `1px solid ${selected ? "#e2e7de" : "transparent"}`,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 13 }}>
            <Icon name="phone" size={22} color={C.muted} />
            <div style={{ fontSize: 28, fontWeight: 510 }}>{id}</div>
            <Badge style={{ fontSize: 19 }}>
              {future
                ? "Original interaction"
                : id === "CALL-102"
                  ? "Today"
                  : "Previous call"}
            </Badge>
          </div>
          <Icon
            name="down"
            size={20}
            color={C.muted}
            style={{ transform: `rotate(${selected ? 0 : -90}deg)` }}
          />
        </div>
        <div style={{ fontSize: 23, color: C.muted, marginTop: 10 }}>
          {c.date} · {c.time} · {c.agent}
        </div>
        <div style={{ fontSize: 26, marginTop: 12 }}>{c.subject}</div>
        {expand > 0 && (
          <div
            style={{
              height: mix(0, 305, expand),
              overflow: "hidden",
              opacity: expand,
              marginTop: mix(0, 23, expand),
            }}
          >
            <OwnedNote id={id} t={t} start={noteStart} size={31} />
          </div>
        )}
      </div>
    </div>
  );
};
export const ActivityWorkspace: React.FC<{
  t: number;
  selected?: CallKey;
  expandAt?: number;
  future?: boolean;
  style?: React.CSSProperties;
}> = ({ t, selected = "CALL-101", expandAt = 0, future, style }) => (
  <Window
    title="Customer 360 / Call Activities"
    tag="PROPOSED EXPERIENCE"
    style={style}
  >
    <CallStrip
      id={future ? "CALL-103" : "CALL-102"}
      agent={future ? "Youssef" : "Salma"}
    />
    <div style={{ display: "flex" }}>
      <div
        style={{
          width: 355,
          padding: "30px 27px",
          borderRight: `1px solid ${C.line}`,
          background: "#fdfcfa",
        }}
      >
        <PersonHeader small email={false} />
        <div style={{ marginTop: 27, fontSize: 24, lineHeight: 1.5 }}>
          {"+20 10 •••• 4821"}
          <div style={{ fontSize: 22, color: C.muted, marginTop: 7 }}>
            ahmed@example.com
          </div>
        </div>
        <div style={{ marginTop: 27 }}>
          <Badge tone="amber">Elite · demo record</Badge>
        </div>
        <Label style={{ marginTop: 25, fontSize: 20 }}>
          Membership source requires validation.
        </Label>
      </div>
      <div style={{ flex: 1, padding: "0 30px 23px" }}>
        <Tabs items={["Call Activities", "Ticket updates", "AI summaries"]} />
        <div style={{ paddingTop: 22 }}>
          {(future
            ? ["CALL-102", "CALL-101"]
            : ["CALL-102", "CALL-101", "CALL-100"]
          ).map((id, i) => (
            <ActivityRow
              key={id}
              id={id as CallKey}
              selected={selected === id}
              expand={selected === id ? ease(t, expandAt, 0.7) : 0}
              t={t}
              noteStart={expandAt + 0.2}
              future={future}
            />
          ))}
        </div>
      </div>
    </div>
  </Window>
);
