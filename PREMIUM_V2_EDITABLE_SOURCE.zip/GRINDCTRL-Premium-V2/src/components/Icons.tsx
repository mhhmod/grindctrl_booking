import React from "react";
const paths: Record<string, React.ReactNode> = {
  eye: (
    <>
      <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  phone: <path d="M6 3 3 6c-1 6 9 16 15 15l3-3-5-4-3 2-5-5 2-3z" />,
  search: (
    <>
      <circle cx="10" cy="10" r="6" />
      <path d="m15 15 6 6" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21v-3a8 8 0 0 1 16 0v3" />
    </>
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="3" />
      <path d="m3 7 9 6 9-6" />
    </>
  ),
  check: <path d="m5 12 5 5L20 7" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 6v6l4 3" />
    </>
  ),
  note: (
    <>
      <path d="M5 3h11l4 4v14H5z" />
      <path d="M15 3v5h5M8 12h9M8 16h7" />
    </>
  ),
  ticket: (
    <>
      <path d="M3 5h18v5a2 2 0 0 0 0 4v5H3v-5a2 2 0 0 0 0-4z" />
      <path d="M8 5v14" strokeDasharray="2 3" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="10" width="14" height="11" rx="3" />
      <path d="M8 10V6a4 4 0 0 1 8 0v4M12 14v3" />
    </>
  ),
  copy: (
    <>
      <rect x="8" y="7" width="12" height="14" rx="2" />
      <path d="M15 7V3H3v14h5" />
    </>
  ),
  arrow: <path d="M4 12h16m-6-6 6 6-6 6" />,
  chevron: <path d="m9 5 7 7-7 7" />,
  down: <path d="m6 9 6 6 6-6" />,
  mic: (
    <>
      <rect x="9" y="2" width="6" height="13" rx="3" />
      <path d="M5 10a7 7 0 0 0 14 0M12 17v5M8 22h8" />
    </>
  ),
  pause: (
    <>
      <path d="M8 5v14M16 5v14" strokeWidth="3.5" />
    </>
  ),
  more: (
    <>
      <circle cx="4" cy="12" r="1" />
      <circle cx="12" cy="12" r="1" />
      <circle cx="20" cy="12" r="1" />
    </>
  ),
  plus: <path d="M12 4v16M4 12h16" />,
  x: <path d="m6 6 12 12M6 18 18 6" />,
  external: (
    <>
      <path d="M13 3h8v8M21 3l-11 11M9 3H3v18h18v-6" />
    </>
  ),
  upload: (
    <>
      <path d="M12 16V3M7 8l5-5 5 5M3 16v5h18v-5" />
    </>
  ),
  chat: (
    <>
      <path d="M21 15a3 3 0 0 1-3 3H8l-5 4V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3z" />
      <path d="M7 8h10M7 12h7" />
    </>
  ),
  star: (
    <path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z" />
  ),
  spark: (
    <>
      <path d="m12 2 2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z" />
    </>
  ),
  ruler: (
    <>
      <path d="m3 16 13-13 5 5L8 21zM6 13l3 3M10 9l3 3M14 5l3 3" />
    </>
  ),
  bag: (
    <>
      <path d="M4 7h16l1 14H3zM8 7V5a4 4 0 0 1 8 0v2" />
    </>
  ),
  folder: <path d="M3 5h7l2 3h9v13H3z" />,
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <ellipse cx="12" cy="12" rx="4" ry="9" />
      <path d="M3 12h18" />
    </>
  ),
  shield: (
    <>
      <path d="M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6z" />
      <path d="m8 12 3 3 5-6" />
    </>
  ),
  refresh: (
    <>
      <path d="M20 9a8 8 0 1 0 0 7M20 3v6h-6" />
    </>
  ),
};
export const Icon: React.FC<{
  name: string;
  size?: number;
  color?: string;
  stroke?: number;
  style?: React.CSSProperties;
}> = ({ name, size = 26, color = "currentColor", stroke = 1.65, style }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth={stroke}
    strokeLinecap="round"
    strokeLinejoin="round"
    style={style}
  >
    {paths[name] || paths.note}
  </svg>
);
