import { asset } from "./assets";
import React from "react";
import { Img } from "remotion";
import { C, shadow } from "../design-system/tokens";
import { Icon } from "./Icons";
import { ease, mix } from "../motion/primitives";
export const Box: React.FC<{
  x: number;
  y: number;
  w?: number;
  h?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
  className?: string;
}> = ({ x, y, w, h, children, style, className }) => (
  <div
    className={className}
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: w,
      height: h,
      ...style,
    }}
  >
    {children}
  </div>
);
export const Eyebrow: React.FC<{
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ children, style }) => (
  <div
    style={{
      fontSize: 21,
      fontWeight: 500,
      letterSpacing: 2.1,
      textTransform: "uppercase",
      color: C.muted,
      ...style,
    }}
  >
    {children}
  </div>
);
export const Title: React.FC<{
  children: React.ReactNode;
  size?: number;
  style?: React.CSSProperties;
}> = ({ children, size = 64, style }) => (
  <div
    style={{
      fontSize: size,
      lineHeight: 1.08,
      letterSpacing: -size * 0.042,
      fontWeight: 460,
      color: C.ink,
      ...style,
    }}
  >
    {children}
  </div>
);
export const Rule = () => (
  <div style={{ height: 1, background: C.line, width: "100%" }} />
);
export const Label: React.FC<{
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ children, style }) => (
  <div style={{ fontSize: 23, color: C.muted, lineHeight: 1.4, ...style }}>
    {children}
  </div>
);
export const Button: React.FC<{
  children: React.ReactNode;
  icon?: string;
  light?: boolean;
  style?: React.CSSProperties;
}> = ({ children, icon, light, style }) => (
  <div
    style={{
      padding: "16px 25px",
      minHeight: 61,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 14,
      borderRadius: 11,
      fontSize: 26,
      fontWeight: 500,
      color: light ? C.ink : "#fff",
      background: light ? C.soft : C.ink,
      border: `1px solid ${light ? C.line : C.ink}`,
      ...style,
    }}
  >
    {icon && <Icon name={icon} size={25} />}
    {children}
  </div>
);
export const Badge: React.FC<{
  children: React.ReactNode;
  tone?: "green" | "amber" | "neutral" | "red";
  icon?: string;
  style?: React.CSSProperties;
}> = ({ children, tone = "neutral", icon, style }) => {
  const colors = {
    green: [C.green, C.greenSoft],
    amber: [C.amber, C.amberSoft],
    neutral: [C.muted, C.soft],
    red: [C.red, C.redSoft],
  }[tone];
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 9,
        color: colors[0],
        background: colors[1],
        borderRadius: 6,
        padding: "8px 13px",
        fontSize: 22,
        fontWeight: 500,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {icon && <Icon name={icon} size={21} />}
      {children}
    </span>
  );
};
export const Avatar: React.FC<{
  name?: string;
  size?: number;
  warm?: boolean;
}> = ({ name = "AM", size = 66, warm }) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: size * 0.36,
      background: warm ? "#eee5d7" : "#e9eeeb",
      color: warm ? C.amber : C.green,
      fontSize: size * 0.33,
      fontWeight: 500,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      flexShrink: 0,
    }}
  >
    {name}
  </div>
);
export const Logo: React.FC<{
  vendor?: "brand" | "genesys" | "zoho";
  height?: number;
}> = ({ vendor = "brand", height = 30 }) =>
  vendor === "brand" ? (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: height * 0.48,
        whiteSpace: "nowrap",
      }}
    >
      <Img
        src={asset("approved/brand.png")}
        style={{ height, width: height * 1.5, objectFit: "contain" }}
      />
      <span
        style={{
          fontSize: height * 0.96,
          fontWeight: 580,
          letterSpacing: height * 0.09,
          lineHeight: 1,
        }}
      >
        GRINDCTRL
      </span>
    </div>
  ) : (
    <Img
      src={asset("approved/" + vendor + ".png")}
      style={{
        height,
        objectFit: "contain",
        width: vendor === "genesys" ? height * 5.13 : height * 2.33,
        objectPosition: "left center",
      }}
    />
  );
export const Window: React.FC<{
  children: React.ReactNode;
  title?: string;
  vendor?: "genesys" | "zoho";
  style?: React.CSSProperties;
  tag?: string;
  plain?: boolean;
}> = ({ children, title, vendor, style, tag, plain }) => (
  <div
    style={{
      background: C.surface,
      border: `1px solid ${C.line}`,
      borderRadius: 20,
      boxShadow: shadow,
      overflow: "hidden",
      ...style,
    }}
  >
    {!plain && (
      <div
        style={{
          height: 64,
          display: "flex",
          alignItems: "center",
          padding: "0 27px",
          gap: 18,
          borderBottom: `1px solid ${C.line}`,
          background: "#fdfcfb",
        }}
      >
        <div style={{ display: "flex", gap: 6 }}>
          {["#dfd9d0", "#e4dfd7", "#e9e5de"].map((c, i) => (
            <i
              key={i}
              style={{
                display: "block",
                width: 8,
                height: 8,
                borderRadius: 8,
                background: c,
              }}
            />
          ))}
        </div>
        {vendor ? (
          <Logo vendor={vendor} height={24} />
        ) : (
          <span style={{ fontSize: 22, color: C.muted, fontWeight: 500 }}>
            {title}
          </span>
        )}
        <span
          style={{
            marginLeft: "auto",
            fontSize: 18,
            letterSpacing: 1,
            color: C.muted,
          }}
        >
          {tag}
        </span>
      </div>
    )}
    {children}
  </div>
);
export const Tabs: React.FC<{ items: string[]; selected?: number }> = ({
  items,
  selected = 0,
}) => (
  <div
    style={{
      height: 68,
      display: "flex",
      gap: 35,
      alignItems: "stretch",
      borderBottom: `1px solid ${C.line}`,
    }}
  >
    {items.map((s, i) => (
      <div
        key={s}
        style={{
          fontSize: 25,
          color: i === selected ? C.ink : C.muted,
          fontWeight: i === selected ? 550 : 400,
          display: "flex",
          alignItems: "center",
          borderBottom:
            i === selected ? `2px solid ${C.ink}` : "2px solid transparent",
        }}
      >
        {s}
      </div>
    ))}
  </div>
);
export const Header: React.FC<{ film: string }> = ({ film }) => (
  <>
    <Box x={65} y={42}>
      <Logo height={29} />
    </Box>
    <Box x={1250} y={47} w={600} style={{ textAlign: "right" }}>
      <Eyebrow style={{ fontSize: 18, letterSpacing: 1.7 }}>
        {film === "03"
          ? "GRINDCTRL / FASHION COMMERCE"
          : "GRINDCTRL × CONCRETE / " +
            (film === "01" ? "CALLER CONTEXT" : "CALL CONTINUITY")}
      </Eyebrow>
    </Box>
  </>
);
export const Footer: React.FC<{ film: string }> = ({ film }) => (
  <>
    <Box
      x={66}
      y={1039}
      style={{
        fontSize: 17,
        color: "#928a7e",
        letterSpacing: 1.1,
        textTransform: "uppercase",
      }}
    >
      {film === "03"
        ? "Illustrative product experience · synthetic fashion assets"
        : "Proposed experience · fictional records · access checks required"}
    </Box>
    <Box
      x={1740}
      y={1038}
      w={115}
      style={{ textAlign: "right", fontSize: 18, color: C.muted }}
    >
      FILM {film}
    </Box>
  </>
);
export const Ring: React.FC<{ t: number; start: number; size?: number }> = ({
  t,
  start,
  size = 130,
}) => {
  const q = (t - start) % 2.2;
  return (
    <div
      style={{
        position: "relative",
        width: size,
        height: size,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {[0, 0.7, 1.4].map((d) => {
        const p = ((q + d) % 2.2) / 2.2;
        return (
          <div
            key={d}
            style={{
              position: "absolute",
              inset: 0,
              border: `1.3px solid ${C.green}`,
              borderRadius: "50%",
              opacity: (1 - p) * 0.18,
              transform: `scale(${1 + p * 0.8})`,
            }}
          />
        );
      })}
      <div
        style={{
          width: size * 0.75,
          height: size * 0.75,
          borderRadius: "50%",
          background: C.greenSoft,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon name="phone" size={size * 0.31} color={C.green} />
      </div>
    </div>
  );
};
export const Field: React.FC<{
  icon?: string;
  label: string;
  children: React.ReactNode;
  active?: boolean;
}> = ({ icon, label, children, active }) => (
  <div
    style={{
      padding: "16px 0",
      display: "flex",
      gap: 15,
      alignItems: "center",
      borderBottom: `1px solid ${C.line}`,
      background: active ? C.amberSoft : "transparent",
    }}
  >
    {icon && <Icon name={icon} color={C.muted} />}
    <div>
      <Label style={{ fontSize: 20 }}>{label}</Label>
      <div style={{ fontSize: 29, fontWeight: 450, marginTop: 5 }}>
        {children}
      </div>
    </div>
  </div>
);
