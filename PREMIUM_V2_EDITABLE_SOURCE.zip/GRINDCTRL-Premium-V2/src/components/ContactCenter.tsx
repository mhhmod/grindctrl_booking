import React from "react";
import { C } from "../design-system/tokens";
import {
  Box,
  Window,
  Logo,
  Label,
  Avatar,
  Badge,
  Button,
  Tabs,
  Field,
  Ring,
  Title,
} from "./Primitives";
import { Icon } from "./Icons";
import { ease, mix, p, reveal, typing } from "../motion/primitives";
export const PHONE = "+20 10 •••• 4821";
export const CallControls: React.FC<{ size?: number }> = ({ size = 55 }) => (
  <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
    {["mic", "pause", "plus", "phone"].map((n, i) => (
      <div
        key={n}
        style={{
          width: size,
          height: size,
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: i === 3 ? "#f7e7e0" : C.soft,
          color: i === 3 ? C.red : C.muted,
        }}
      >
        <Icon name={n} size={24} />
      </div>
    ))}
  </div>
);
export const CallCard: React.FC<{
  t: number;
  incoming?: boolean;
  compact?: boolean;
  matched?: boolean;
  id?: string;
  style?: React.CSSProperties;
}> = ({ t, incoming, compact, matched, id = "CALL-102", style }) => (
  <Window
    vendor="genesys"
    tag="DEMO"
    style={{ width: compact ? 360 : 590, ...style }}
  >
    <div style={{ padding: compact ? "29px 28px" : "37px 42px" }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Badge tone="green" icon="phone" style={{ fontSize: 20 }}>
          {incoming ? "Incoming call" : "Call connected"}
        </Badge>
        <Label style={{ fontSize: 18 }}>
          {incoming ? "" : "00:" + String(Math.floor(t) % 60).padStart(2, "0")}
        </Label>
      </div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 20,
          marginTop: compact ? 38 : 32,
        }}
      >
        {incoming ? (
          <Ring t={t} start={0} size={compact ? 76 : 100} />
        ) : (
          <Avatar name={matched ? "AM" : "?"} size={compact ? 67 : 90} />
        )}
        <div>
          <Label style={{ fontSize: compact ? 20 : 24 }}>
            {matched ? "Customer record matched" : "Concrete Customer Service"}
          </Label>
          <div
            style={{
              fontSize: compact ? 30 : 42,
              fontWeight: 470,
              letterSpacing: -1,
              marginTop: 9,
            }}
          >
            {matched ? "Ahmed M." : "Incoming caller"}
          </div>
        </div>
      </div>
      <div
        style={{
          fontSize: compact ? 29 : 40,
          fontWeight: 450,
          letterSpacing: -0.8,
          marginTop: 35,
          fontVariantNumeric: "tabular-nums",
        }}
      >
        {PHONE}
      </div>
      <Label style={{ fontSize: 20, marginTop: 9 }}>
        Caller number · lookup key only
      </Label>
      <div
        style={{
          height: 1,
          background: C.line,
          margin: compact ? "30px 0" : "36px 0",
        }}
      />
      <Label style={{ fontSize: 19 }}>Interaction</Label>
      <div style={{ fontSize: 25, marginTop: 6 }}>{id}</div>
      {incoming ? (
        <Button
          icon="phone"
          style={{
            marginTop: 32,
            width: "100%",
            background: C.green,
            borderColor: C.green,
          }}
        >
          Answer call
        </Button>
      ) : (
        <div style={{ marginTop: 35 }}>
          <CallControls size={compact ? 53 : 64} />
        </div>
      )}
      <div style={{ marginTop: 28, fontSize: 19, color: C.muted }}>
        {incoming
          ? "Voice channel is ready"
          : "Voice remains independent of lookup"}
      </div>
    </div>
  </Window>
);
export const CallStrip: React.FC<{
  id?: string;
  agent?: string;
  matched?: boolean;
  right?: React.ReactNode;
}> = ({ id = "CALL-102", agent = "Salma", matched = true, right }) => (
  <div
    style={{
      height: 100,
      display: "flex",
      alignItems: "center",
      gap: 18,
      padding: "0 30px",
      background: C.greenSoft,
      borderBottom: `1px solid #dce7df`,
    }}
  >
    <div
      style={{
        width: 48,
        height: 48,
        borderRadius: "50%",
        background: "#d9e6dc",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Icon name="phone" color={C.green} size={25} />
    </div>
    <div>
      <div style={{ fontSize: 27, fontWeight: 500 }}>{PHONE}</div>
      <Label style={{ fontSize: 19 }}>
        {id} · {agent} · Connected
      </Label>
    </div>
    <div
      style={{
        marginLeft: "auto",
        display: "flex",
        alignItems: "center",
        gap: 20,
      }}
    >
      {right || (
        <Badge
          tone={matched ? "green" : "neutral"}
          icon={matched ? "shield" : "lock"}
        >
          {matched ? "Permitted record" : "Context not yet shown"}
        </Badge>
      )}
      <Icon name="mic" color={C.green} />
    </div>
  </div>
);
export const PersonHeader: React.FC<{
  small?: boolean;
  membership?: boolean;
  email?: boolean;
  unavailable?: boolean;
}> = ({ small, membership, email = true, unavailable }) => (
  <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
    <Avatar size={small ? 66 : 85} />
    <div>
      <div
        style={{
          fontSize: small ? 32 : 42,
          fontWeight: 500,
          letterSpacing: -1,
        }}
      >
        Ahmed M.
      </div>
      <Label style={{ fontSize: small ? 20 : 23 }}>
        Matched customer record
      </Label>
      {email && (
        <div
          style={{
            fontSize: 24,
            marginTop: 8,
            color: unavailable ? C.muted : C.ink,
          }}
        >
          {unavailable ? "Email unavailable" : "ahmed@example.com"}
        </div>
      )}
    </div>
    {membership && (
      <Badge tone="amber" style={{ marginLeft: "auto", fontSize: 25 }}>
        Elite · demo
      </Badge>
    )}
  </div>
);
export const SearchField: React.FC<{
  text?: string;
  focus?: boolean;
  placeholder?: string;
  style?: React.CSSProperties;
}> = ({ text, focus, placeholder = "Search contacts or tickets", style }) => (
  <div
    style={{
      height: 66,
      border: `1.5px solid ${focus ? "#ad9c81" : C.line}`,
      borderRadius: 10,
      display: "flex",
      alignItems: "center",
      gap: 15,
      padding: "0 22px",
      background: focus ? "#fffefb" : C.paper,
      boxShadow: focus ? "0 0 0 4px #a78e6420" : "none",
      fontSize: 27,
      color: text ? C.ink : C.faint,
      ...style,
    }}
  >
    <Icon name="search" size={25} color={C.muted} />
    {text || placeholder}
    {focus && <span style={{ height: 30, width: 1, background: C.ink }} />}
  </div>
);
export const TicketRow: React.FC<{
  selected?: boolean;
  title?: string;
  id?: string;
  status?: string;
  old?: boolean;
}> = ({
  selected,
  title = "Exchange follow-up",
  id = "DESK-2048",
  status = "Pending branch review",
  old,
}) => (
  <div
    data-ticket={id}
    style={{
      minHeight: 126,
      display: "flex",
      gap: 19,
      padding: "25px 27px",
      borderBottom: `1px solid ${C.line}`,
      background: selected ? "#f8f5ef" : "white",
      alignItems: "center",
    }}
  >
    <div
      style={{
        width: 46,
        height: 46,
        borderRadius: 12,
        background: selected ? "#ece2ce" : C.soft,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Icon name="ticket" color={selected ? C.amber : C.muted} />
    </div>
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 28, fontWeight: 480 }}>{title}</div>
      <Label style={{ fontSize: 21, marginTop: 7 }}>
        {id} · {old ? "08 Oct" : "20 Oct, 14:05"}
      </Label>
    </div>
    <Badge tone={old ? "neutral" : "amber"}>{status}</Badge>
    <Icon name="chevron" size={22} color={C.muted} />
  </div>
);
export const TicketNote: React.FC<{
  t: number;
  start?: number;
  large?: boolean;
}> = ({ t, start = 0, large }) => (
  <div
    data-record-status="Pending branch review"
    style={{
      border: `1px solid #e9dfcd`,
      background: "#fcfaf5",
      padding: large ? "35px 39px" : "27px 31px",
      borderRadius: 12,
      ...reveal(t, start, 12),
    }}
  >
    <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
      <Icon name="clock" size={24} color={C.amber} />
      <Label style={{ fontSize: 21, color: C.amber }}>
        Latest recorded update · 20 Oct, 14:05
      </Label>
    </div>
    <div
      style={{
        fontSize: large ? 42 : 34,
        fontWeight: 450,
        letterSpacing: -0.9,
        marginTop: 19,
        lineHeight: 1.2,
      }}
    >
      Awaiting branch review.
    </div>
    <div
      style={{
        fontSize: large ? 29 : 25,
        lineHeight: 1.5,
        color: C.muted,
        marginTop: 16,
      }}
    >
      Exchange request remains pending.
      <br />
      No approval or completed action recorded.
    </div>
  </div>
);
export const TicketWorkspace: React.FC<{
  t: number;
  mode?: "list" | "detail" | "overview";
  revealAt?: number;
  style?: React.CSSProperties;
  label?: string;
}> = ({
  t,
  mode = "detail",
  revealAt = 0,
  style,
  label = "Proposed customer context",
}) => (
  <Window title={label} tag="ILLUSTRATIVE URL WINDOW" style={style}>
    <div style={{ padding: "30px 36px 0" }}>
      <PersonHeader small email={false} />
      <div style={{ marginTop: 20 }}>
        <Tabs items={["Tickets", "Contact details", "Call history"]} />
      </div>
    </div>
    {mode === "list" ? (
      <>
        <TicketRow selected />
        <TicketRow
          title="Product information"
          id="DESK-1981"
          status="Closed"
          old
        />
      </>
    ) : (
      <div style={{ padding: "27px 36px 30px" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            marginBottom: 16,
          }}
        >
          <Icon name="ticket" size={22} color={C.muted} />
          <Label style={{ fontSize: 21 }}>DESK-2048 · Exchange request</Label>
          <Badge tone="amber" style={{ marginLeft: "auto", fontSize: 20 }}>
            Pending branch review
          </Badge>
        </div>
        <TicketNote t={t} start={revealAt} />
      </div>
    )}
  </Window>
);
export const ProfileFields: React.FC<{
  t: number;
  start?: number;
  missing?: boolean;
}> = ({ t, start = 0, missing }) => (
  <>
    <div style={reveal(t, start)}>
      <Field label="Phone number" icon="phone">
        {PHONE}
      </Field>
    </div>
    <div style={reveal(t, start + 0.35)}>
      <Field label="Customer name" icon="user">
        Ahmed M.
      </Field>
    </div>
    <div style={reveal(t, start + 0.7)}>
      <Field label="Email" icon="mail">
        {missing ? (
          <span style={{ color: C.muted }}>Unavailable</span>
        ) : (
          "ahmed@example.com"
        )}
      </Field>
    </div>
  </>
);
