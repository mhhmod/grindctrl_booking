import { asset } from "./assets";
import React from "react";
import { Img } from "remotion";
import { C, shadow } from "../design-system/tokens";
import {
  Badge,
  Button,
  Label,
  Title,
  Avatar,
  Eyebrow,
  Window,
} from "./Primitives";
import { Icon } from "./Icons";
import { ease, mix, p, reveal, typing } from "../motion/primitives";
export const FashionImage: React.FC<{
  kind?: "garment" | "before" | "result";
  style?: React.CSSProperties;
  position?: string;
}> = ({ kind = "garment", style, position = "center" }) => (
  <Img
    src={asset(
      "generated/" +
        {
          garment: "navy-linen-hero",
          before: "shopper-before",
          result: "shopper-result",
        }[kind] +
        ".png",
    )}
    style={{
      width: "100%",
      height: "100%",
      objectFit: kind === "garment" ? "cover" : "contain",
      objectPosition: position,
      background: kind === "garment" ? undefined : "#e9dbc7",
      ...style,
    }}
  />
);
export const StoreHeader = () => (
  <div
    style={{
      height: 68,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 31px",
      borderBottom: `1px solid ${C.line}`,
      background: "#fffdf9",
    }}
  >
    <div style={{ fontSize: 25, letterSpacing: 5, fontWeight: 500 }}>
      THE STUDIO
    </div>
    <div style={{ display: "flex", gap: 32, fontSize: 21, color: C.muted }}>
      <span>Collection</span>
      <span>Clothing</span>
      <span>About</span>
    </div>
    <div style={{ display: "flex", gap: 21 }}>
      <Icon name="search" size={22} />
      <Icon name="bag" size={23} />
    </div>
  </div>
);
export const ProductInfo: React.FC<{
  t?: number;
  start?: number;
  compact?: boolean;
  tryActive?: boolean;
}> = ({ t = 100, start = 0, compact, tryActive }) => (
  <div style={{ padding: "27px 37px" }}>
    <Eyebrow style={{ fontSize: 18, letterSpacing: 1.6 }}>
      The linen edit / fictional product
    </Eyebrow>
    <Title size={44} style={{ marginTop: 14 }}>
      The navy
      <br />
      linen overshirt.
    </Title>
    <Label style={{ fontSize: 24, marginTop: 13, lineHeight: 1.35 }}>
      Washed linen. Easy layering.
      <br />A considered everyday piece.
    </Label>
    <div
      style={{ marginTop: 17, display: "flex", gap: 14, alignItems: "center" }}
    >
      <span
        style={{
          width: 22,
          height: 22,
          borderRadius: "50%",
          background: "#263b54",
          boxShadow: "0 0 0 4px #fff,0 0 0 5px #d5cfc6",
        }}
      />
      <span style={{ fontSize: 23 }}>Midnight navy</span>
    </div>
    <div style={{ marginTop: 17, display: "flex", gap: 12 }}>
      {["S", "M", "L", "XL"].map((s, i) => (
        <div
          key={s}
          style={{
            width: 57,
            height: 45,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            border: `1px solid ${i === 1 ? "#696057" : C.line}`,
            borderRadius: 8,
            fontSize: 23,
            background: i === 1 ? C.soft : "white",
          }}
        >
          {s}
        </div>
      ))}
    </div>
    <div style={{ marginTop: 20 }}>
      <Button
        icon="spark"
        style={{
          width: "100%",
          minHeight: 56,
          padding: "13px 25px",
          background: C.navy,
          borderColor: C.navy,
          boxShadow: tryActive ? "0 0 0 5px #263b5418" : "none",
        }}
      >
        Try it on with AI
      </Button>
    </div>
    <div style={{ marginTop: 10 }}>
      <Button
        icon="chat"
        light
        style={{
          width: "100%",
          minHeight: 50,
          padding: "11px 25px",
          fontSize: 24,
        }}
      >
        Ask Store Chat
      </Button>
    </div>
    <Label style={{ fontSize: 19, marginTop: 12 }}>
      Illustrative Shopify product experience.
    </Label>
  </div>
);
export const ProductPage: React.FC<{
  t: number;
  style?: React.CSSProperties;
  compact?: boolean;
}> = ({ t, style, compact }) => (
  <Window
    title="Shopify storefront / illustrative merchant"
    tag="DEMO"
    style={style}
  >
    <StoreHeader />
    <div style={{ display: "flex" }}>
      <div
        style={{
          width: compact ? "53%" : "57%",
          height: compact ? 550 : 590,
          overflow: "hidden",
          background: "#e5d9c7",
        }}
      >
        <FashionImage position="center 52%" />
      </div>
      <div style={{ flex: 1 }}>
        <ProductInfo t={t} compact={compact} tryActive={t >= 25.568} />
      </div>
    </div>
  </Window>
);
export const ChatMessage: React.FC<{
  from: "shopper" | "assistant" | "human" | "private";
  children: React.ReactNode;
  label?: string;
  style?: React.CSSProperties;
}> = ({ from, children, label, style }) => (
  <div
    style={{
      marginBottom: 17,
      marginLeft: from === "shopper" ? 56 : 0,
      marginRight: from === "shopper" ? 0 : 24,
      padding: "21px 24px",
      background:
        from === "shopper"
          ? "#e9e5dd"
          : from === "private"
            ? "#faf0d8"
            : from === "human"
              ? C.greenSoft
              : "#f5f3ee",
      borderRadius:
        from === "shopper" ? "15px 15px 3px 15px" : "3px 15px 15px 15px",
      fontSize: 27,
      lineHeight: 1.4,
      ...style,
    }}
  >
    {label && (
      <div
        style={{
          fontSize: 18,
          letterSpacing: 0.5,
          color: from === "private" ? C.amber : C.muted,
          marginBottom: 8,
          fontWeight: 550,
        }}
      >
        {label}
      </div>
    )}
    {children}
  </div>
);
export const ChatHeader = () => (
  <div
    style={{
      height: 86,
      padding: "0 26px",
      display: "flex",
      alignItems: "center",
      gap: 14,
      borderBottom: `1px solid ${C.line}`,
    }}
  >
    <div
      style={{
        width: 44,
        height: 44,
        borderRadius: 12,
        background: C.navy,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Icon name="chat" color="white" size={23} />
    </div>
    <div style={{ fontSize: 29, fontWeight: 480 }}>Store Chat</div>
    <span style={{ fontSize: 18, color: C.muted, marginLeft: "auto" }}>
      English / Arabic
    </span>
    <Icon name="x" size={21} />
  </div>
);
export const ChatInput: React.FC<{ text?: string }> = ({ text }) => (
  <div
    style={{
      margin: "15px 24px 22px",
      height: 64,
      border: `1px solid ${C.line}`,
      borderRadius: 10,
      padding: "0 17px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      fontSize: 24,
      color: text ? C.ink : C.faint,
    }}
  >
    {text || "Ask about this piece"}
    <div
      style={{
        width: 35,
        height: 35,
        borderRadius: 9,
        background: C.navy,
        color: "white",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Icon name="arrow" size={20} />
    </div>
  </div>
);
export const ShopperChat: React.FC<{
  t: number;
  answer?: boolean;
  handoff?: boolean;
  style?: React.CSSProperties;
}> = ({ t, answer, handoff, style }) => (
  <div
    style={{
      background: "white",
      border: `1px solid ${C.line}`,
      borderRadius: 17,
      overflow: "hidden",
      boxShadow: shadow,
      ...style,
    }}
  >
    <ChatHeader />
    <div style={{ padding: "23px 26px 7px", minHeight: 350 }}>
      <div
        style={{
          display: "flex",
          gap: 17,
          alignItems: "center",
          padding: "0 0 19px",
          borderBottom: `1px solid ${C.line}`,
          marginBottom: 23,
        }}
      >
        <div
          style={{ width: 60, height: 75, borderRadius: 7, overflow: "hidden" }}
        >
          <FashionImage />
        </div>
        <div>
          <div style={{ fontSize: 23 }}>Navy linen overshirt</div>
          <Label style={{ fontSize: 19, marginTop: 5 }}>
            Selected product context
          </Label>
        </div>
      </div>
      <ChatMessage from="shopper">
        Does this shirt run oversized?
        <br />
        Is there a size guide?
      </ChatMessage>
      {answer && (
        <ChatMessage from="assistant" label="STORE KNOWLEDGE / DEMO CONTENT">
          <span>
            For this demo piece: a relaxed layering cut. Use the merchant’s size
            guide to compare measurements.
          </span>
          <div
            style={{
              display: "flex",
              gap: 12,
              alignItems: "center",
              marginTop: 15,
              color: C.navy,
              fontSize: 24,
            }}
          >
            <Icon name="ruler" size={22} />
            Open size guide
          </div>
        </ChatMessage>
      )}
      {handoff && (
        <div style={{ marginTop: 19 }}>
          <Badge tone="amber" icon="chat">
            A teammate can help
          </Badge>
          <Label style={{ fontSize: 22, marginTop: 15 }}>
            Reason: personal sizing judgment.
            <br />
            Conversation context is preserved.
          </Label>
        </div>
      )}
    </div>
    <ChatInput />
  </div>
);
