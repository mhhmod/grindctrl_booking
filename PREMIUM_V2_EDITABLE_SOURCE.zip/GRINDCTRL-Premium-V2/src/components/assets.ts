import { staticFile } from "remotion";
declare global {
  interface Window {
    __GRINDCTRL_ASSETS?: Record<string, string>;
  }
}
export const asset = (path: string) =>
  typeof window !== "undefined" && window.__GRINDCTRL_ASSETS?.[path]
    ? window.__GRINDCTRL_ASSETS[path]
    : staticFile(path);
