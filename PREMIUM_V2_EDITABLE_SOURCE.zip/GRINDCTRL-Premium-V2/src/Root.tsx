import React from "react";
import { Composition } from "remotion";
import { Film, FilmId } from "./compositions/Film";
import "./design-system/global.css";
export const Root: React.FC = () => (
  <>
    {(["01", "02", "03"] as FilmId[]).map((film) => (
      <Composition
        key={film}
        id={"Film" + film}
        component={Film}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={4500}
        defaultProps={{ film }}
      />
    ))}
  </>
);
