export const C = {
  paper:'#faf8f5', surface:'#ffffff', ink:'#2a2826', muted:'#7e7971', faint:'#aba59b', line:'#e7e3dd', soft:'#f3f0eb',
  green:'#386454',greenSoft:'#edf3ee', amber:'#977844',amberSoft:'#f7f1e5', orange:'#f1a75f',red:'#a06454',redSoft:'#f9eeea', navy:'#263b54',
};
export const shadow = '0 34px 80px -30px rgba(62,52,37,.22), 0 2px 7px rgba(62,52,37,.04)';
export const type = {hero:88,display:68,heading:48,subheading:36,ui:30,body:28,label:23,micro:20};
export const motion = {fast:8,normal:14,editorial:22,damping:25,stiffness:135};
