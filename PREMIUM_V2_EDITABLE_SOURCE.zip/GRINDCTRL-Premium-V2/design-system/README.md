# Visual system and art direction

The implementation lives in src/design-system, src/components and src/motion. This specification is a review aid, not a separate template engine.

- Palette: warm cream #faf8f5, white, charcoal #2a2826, warm muted #7e7971, fine #e7e3dd borders. Pale desaturated green communicates a permitted/active state; restrained amber identifies a recorded pending item or private team note. No gold decoration, black pages or dashboard KPI inventions.
- Typography: local SIL-OFL Geist variable, mostly420–550weight. Editorial display68–88px is reserved for brief openings/closings; workflow headings35–55px; important UI27–42px; metadata20–24px. Caption30px, two lines maximum. Tabular times/IDs. Text remains editable React.
- Grid:1920×1080. Brand at65/42, main story roughly110/185–1810/910. Caption lane950–1020; disclosure footer1039. Eight-point spacing with optical adjustments. Large focused UI occupies most of the frame on workflow shots.
- Surfaces: warm-lit, fine borders, modest radius11–20px, restrained wide shadows. App windows, drawers, timeline expansion, product image/photo surfaces and call controls are distinct components. No repeated row of equally weighted generic cards.
- Icons:24-unit custom line vocabulary,1.65stroke, consistent optical sizes21–33px; state icon and text stay together. The brand symbol and vendor marks use existing source assets.
- Motion: per-frame ease curves and damped springs. Typed search and notes, copy feedback, permission progress, context reveal, call-row expansion, scroll-to-selected call, before/after wipe, upload/photo state, chat/thread handoff and assignment. Cameras only reframe a meaningful source/detail; no random loops or flying logos. Incoming ringing is limited to the incoming-call state.
- Editorial grammar: Film01 moves from a large incoming call, through manual desktop retrieval, to authorized lookup, ticket close-up, uncertainty states and a measured pilot. Film02 prioritises profile, trusted tier data, a timeline-to-call-note close-up and immutable original authorship. Film03 combines new tactile editorial fashion imagery, storefront action, photo upload, shared-image reveal, product information, a contextual chat and shared human inbox.
- Captions: calm warm-white native text overlay, adequate contrast and spacing, no opaque black slab. Short recognition fragments are joined where the spoken clause permits. Spelling follows actual scripts and company names.

## UI components

Window, StoreHeader, Avatar, Badge, Button, SearchField, Field, Tabs, CallCard, CallStrip, PersonHeader, TicketRow, TicketNote, ActivityRow, OwnedNote, ProductInfo, ProductPage, FashionImage, ChatMessage, ShopperChat and Inbox. Selected interaction IDs and original note authors are source data, not decorative text.

## Fidelity

Genesys/Zoho interfaces are vendor-informed illustrative concepts, not screenshots of Concrete. Customer context uses a proposed separate URL window; no unsupported native Genesys panel is asserted. Repository-provided GRINDCTRL Try-On and inbox references are inspected for product vocabulary; no live deployment is established. Every photographed person/product is synthetic, not actual Concrete merchandise or an engine benchmark.
