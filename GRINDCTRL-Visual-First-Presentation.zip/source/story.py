"""Visual-first seven-scene proposal, with one consistent fictional call."""
from pathlib import Path
import json
ROOT=Path(__file__).parent
basis=json.loads((ROOT/'basis.json').read_text())
B=lambda en,ar:dict(en=en,ar=ar)
C=dict(bg='#F8F7F4',paper='#FFFFFF',ink='#262626',muted='#68645E',line='#E6E3DE',accent='#965318',gold='#FFBA65',green='#49654E',soft='#F4F2EE',sage='#EFF4EE',warm='#FFF2DD',shadow='#EDEAE4',white='#FFFFFF')
slides=[]
def add(s,kind,step=None,**kw):
 e=dict(type=kind,step=step,**kw);s['elements'].append(e);return e
def txt(s,x,y,w,h,en,ar=None,size=24,color=None,bold=False,align='start',ltr=False,step=None,role='ui'):
 return add(s,'text',step,x=x,y=y,w=w,h=h,text=B(en,ar if ar is not None else en),size=size,color=color or C['ink'],bold=bold,align=align,ltr=ltr,role=role)
def rect(s,x,y,w,h,fill=None,line=None,radius=8,step=None):return add(s,'rect',step,x=x,y=y,w=w,h=h,fill=fill or C['paper'],line=line or C['line'],radius=radius)
def circ(s,x,y,d,fill=None,line=None,step=None):return add(s,'ellipse',step,x=x,y=y,w=d,h=d,fill=fill or C['soft'],line=line or fill or C['soft'])
def img(s,key,x,y,w,h,step=None):return add(s,'image',step,key=key,x=x,y=y,w=w,h=h)
def line(s,x,y,x2,y2,color=None,width=1,step=None,arrow=False):return add(s,'line',step,x=x,y=y,x2=x2,y2=y2,color=color or C['line'],width=width,arrow=arrow)
def shell(s,x,y,w,h,step=None):
 rect(s,x,y+5,w,h,fill=C['shadow'],line=C['shadow'],radius=12,step=step)
 rect(s,x,y,w,h,radius=12,step=step)
def icon(s,key,x,y,d=28,step=None):img(s,'icon-'+key,x,y,d,d,step)
def avatar(s,x,y,d=48,step=None):
 circ(s,x,y,d,fill=C['warm'],step=step);icon(s,'actor',x+d*.22,y+d*.22,d*.56,step)
def state(s,x,y,w,en,ar,step=None,clock=False):
 if clock:icon(s,'clock',x,y+2,21,step)
 else:circ(s,x+4,y+8,8,fill=C['green'],step=step)
 txt(s,x+30,y,w-30,32,en,ar,size=20,color=C['green'] if not clock else C['accent'],step=step)
def mob(s,key,en,ar,body,bodyar,step=0):s['mobile'].append(dict(key=key,title=B(en,ar),body=B(body,bodyar),step=step))
common=[B('Proposed first collaboration. No existing GRINDCTRL relationship with Concrete or Centro, and no completed implementation. Independent illustrative UI, not screenshots of installed vendor systems. All example records, masked numbers and dialogue are fictional.','مقترح لأول تعاون. لا توجد علاقة حالية لـGRINDCTRL بكونكريت أو Centro ولا تنفيذ سابق. الواجهات تصور مستقل وليست صورًا للأنظمة الفعلية. كل السجلات والأرقام المحجوبة والحوارات أمثلة خيالية.'),B('The user reports that Genesys calls do not automatically expose previous Zoho Desk tickets, but manual phone-number search finds them. This has not been independently tested. A number association is not identity verification; employee permissions and Concrete’s caller-verification procedures apply.','بحسب إفادة المستخدم، تذاكر Zoho Desk السابقة لا تظهر تلقائيًا مع مكالمة Genesys، لكن البحث اليدوي برقم التليفون يجدها. لم نختبر ذلك بشكل مستقل. مطابقة الرقم لا تثبت الهوية، وتظل صلاحيات الموظف وإجراءات التحقق مطلوبة.'),B('This is a read-context proposal. No live connector, backend, AI model, refund decision, ticket mutation or measured performance result. Animation is explanatory pacing, not measured response time. Authorized lookup and suitable matching must be technically validated.','المقترح لإظهار المعلومات. لا يوجد اتصال حي أو backend أو نموذج AI أو قرار استرداد أو تعديل تذاكر أو نتائج أداء مقاسة. توقيت الحركة للشرح وليس قياسًا لسرعة النظام. يجب التحقق تقنيًا من الصلاحيات وطريقة المطابقة.')]
def slide(en,ar,section,sectionar,steps=3):
 s=dict(index=len(slides),title=B(en,ar),section=B(section,sectionar),lead=B('A proposed improvement for Concrete. Fictional example records.','تحسين مقترح لكونكريت. السجلات أمثلة خيالية.'),dark=False,elements=[],mobile=[],notes=common.copy(),motion=dict(steps=steps,interval=1400,fade=520));slides.append(s)
 img(s,'brand',48,27,43,29);txt(s,103,29,180,30,'GRINDCTRL',size=18,bold=True,ltr=True,role='brand')
 txt(s,730,30,502,28,section,sectionar,size=16,color=C['muted'],align='end',role='navigation')
 txt(s,48,93,1184,61,en,ar,size=42,bold=True,role='heading')
 line(s,48,665,1232,665)
 txt(s,48,679,1080,26,'Concrete · Proposed collaboration · Fictional records','كونكريت · تعاون مقترح · سجلات خيالية',size=16,color=C['muted'],role='disclosure')
 txt(s,1160,679,72,26,f'{len(slides):02d} / 07',size=16,color=C['muted'],align='end',ltr=True,role='navigation')
 return s

def call(s,x,y,w=278,h=354,step=0,compact=False):
 # Location stays fixed between scenes 1, 2 and 3.
 img(s,'genesys',x+24,y+16,140,34,step)
 state(s,x+24,y+70,w-40,'Call in progress','مكالمة جارية',step)
 circ(s,x+24,y+116,80,fill=C['sage'],step=step)
 icon(s,'call',x+44,y+136,40,step)
 # Wave bars are spatially attached to the call, not generic decoration.
 for j,hh in enumerate([10,23,36,20,30,14,24]):line(s,x+131+j*12,y+156-hh/2,x+131+j*12,y+156+hh/2,color=C['green'],width=4,step=step)
 txt(s,x+24,y+219,w-40,43,'+20 ••• 410',size=28,bold=True,ltr=True,step=step)
 txt(s,x+24,y+268,w-40,32,'Caller number','رقم المتصل',size=20,color=C['muted'],step=step)
 for j,key in enumerate(['mic','pause','end']):
  xx=x+24+j*65;circ(s,xx,y+310,44,fill=C['soft'],step=step);icon(s,key,xx+11,y+321,22,step)

def context(s,x,y,w=850,steps=(2,3,4),detail=True):
 contact,selected,note=steps
 avatar(s,x+24,y+14,48,contact)
 txt(s,x+88,y+14,300,38,'Contact A','العميل A',size=28,bold=True,step=contact)
 txt(s,x+88,y+58,224,32,'Associated record','سجل مرتبط',size=20,color=C['muted'],step=contact)
 txt(s,x+318,y+58,247,32,'+20 ••• 410',size=20,color=C['muted'],ltr=True,step=contact)
 img(s,'zoho',x+w-184,y+24,79,28)
 txt(s,x+w-90,y+25,68,30,'Desk',size=20,ltr=True)
 line(s,x+24,y+105,x+w-24,y+105,step=contact)
 txt(s,x+24,y+125,270,34,'Previous tickets','التذاكر السابقة',size=22,bold=True,step=contact)
 # Selected row and detail share the same baseline and source identity.
 rect(s,x+16,y+169,280,112,fill=C['soft'],line=C['gold'],radius=8,step=selected)
 icon(s,'case',x+30,y+187,24,selected)
 txt(s,x+67,y+181,213,34,'T101 · Exchange','T101 · استبدال',size=22,bold=True,step=selected)
 txt(s,x+30,y+227,248,39,'Branch review pending','بانتظار مراجعة الفرع',size=20,color=C['accent'],step=selected)
 icon(s,'case',x+30,y+310,24,contact)
 txt(s,x+67,y+303,213,32,'T098 · Size query','T098 · سؤال مقاس',size=20,step=contact)
 txt(s,x+67,y+344,215,29,'Closed','مغلقة',size=18,color=C['muted'],step=contact)
 line(s,x+316,y+125,x+316,y+208,step=contact)
 line(s,x+316,y+254,x+316,y+388,step=contact)
 line(s,x+302,y+231,x+330,y+231,color=C['accent'],width=1.7,step=selected,arrow=True)
 txt(s,x+340,y+125,w-365,36,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=24,bold=True,step=selected)
 state(s,x+340,y+173,w-365,'Waiting on the branch','بانتظار الفرع',selected,clock=True)
 rect(s,x+336,y+223,w-360,142,fill=C['warm'],line=C['warm'],radius=8,step=note)
 icon(s,'file',x+352,y+239,22,note)
 txt(s,x+386,y+237,w-418,30,'Latest recorded note','آخر ملاحظة مسجلة',size=20,color=C['accent'],step=note)
 txt(s,x+352,y+281,w-394,74,'Branch review\nis still pending.','مراجعة الفرع\nلسه مطلوبة.',size=28,bold=True,step=note)

def workspace(s,mode='proposed',animated=False):
 shell(s,48,176,1184,464)
 txt(s,72,191,600,34,'Employee workspace','مساحة عمل الموظف',size=20,bold=True)
 txt(s,856,193,352,31,'Illustrative concept','تصور توضيحي',size=18,color=C['muted'],align='end')
 line(s,48,232,1232,232);line(s,370,232,370,640)
 call(s,48,232,322,396,0)
 context(s,370,240,862,(3,4,5) if animated else (1,1,2))
 if animated:
  # Attention stays in the call before moving into source records.
  # In final static state this subtle outline remains as the association cue.
  add(s,'outline',1,x=66,y=443,w=284,h=59,color=C['gold'],radius=8,width=2)
  line(s,350,473,380,473,color=C['accent'],width=2,step=2,arrow=True)
  icon(s,'link',354,404,25,2)
  txt(s,74,608,270,25,'Authorized lookup','بحث بصلاحيات الموظف',size=16,color=C['muted'],step=2)

s=slide('The call arrives. The history comes with it.','المكالمة توصل. وتاريخ الخدمة يظهر معاها.','The proposed experience','التجربة المقترحة',3)
workspace(s)
mob(s,'genesys','Call in progress','مكالمة جارية','+20 ••• 410','+20 ••• 410')
mob(s,'zoho','Contact A · T101','العميل A · T101','Exchange follow-up · Waiting on the branch','متابعة استبدال · بانتظار الفرع',1)
mob(s,'icon-file','Latest recorded note','آخر ملاحظة مسجلة','Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',2)
s['notes'].append(B('The hero shows the outcome first. Genesys and Zoho Desk remain existing systems; this is one possible employee-facing presentation of existing ticket context, subject to the actual desktop and supported mechanisms.','الافتتاح يعرض النتيجة أولًا. Genesys وZoho Desk أنظمة موجودة؛ هذه طريقة مقترحة لعرض معلومات التذاكر، وتتحدد وفق الواجهة الفعلية وآليات الربط المدعومة.'))

s=slide('The information exists. Finding it takes extra work.','المعلومات موجودة. الوصول لها يحتاج بحث يدوي.','Current workflow · Reported','الوضع الحالي · بحسب الإفادة',4)
# Same call geometry, separated windows make context switching visible.
shell(s,48,176,322,464);txt(s,72,191,270,34,'Call workspace','شاشة المكالمة',size=20,bold=True);line(s,48,232,370,232)
call(s,48,232,322,396)
shell(s,416,208,816,400)
img(s,'zoho',440,225,78,29);txt(s,535,225,260,32,'Desk · ticket search','Desk · بحث التذاكر',size=20,bold=True)
# familiar search control plus typed number + pointer = manual work
rect(s,440,285,768,72,fill=C['paper'],line=C['gold'],radius=8,step=2)
icon(s,'search',458,306,28,2);txt(s,503,304,420,43,'+20 ••• 410',size=28,ltr=True,step=2)
rect(s,1026,297,168,48,fill=C['warm'],line=C['warm'],radius=6,step=2)
txt(s,1043,304,133,36,'Search','بحث',size=24,bold=True,align='center',step=2)
icon(s,'pointer',1154,331,45,2)
# Trace shows the number being manually carried across workspaces.
line(s,336,474,395,474,color=C['accent'],width=2,step=1)
line(s,395,474,395,321,color=C['accent'],width=2,step=1)
line(s,395,321,430,321,color=C['accent'],width=2,step=1,arrow=True)
icon(s,'copy',311,456,22,1)
txt(s,440,378,732,34,'Contact A · Previous tickets','العميل A · التذاكر السابقة',size=22,bold=True,step=3)
rect(s,440,429,768,146,fill=C['warm'],line=C['warm'],radius=8,step=3)
icon(s,'case',460,446,28,3);txt(s,503,441,668,38,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=26,bold=True,step=3)
state(s,460,492,660,'Waiting on the branch','بانتظار الفرع',3,True)
txt(s,460,536,716,32,'Latest note: Branch review is still pending.','آخر ملاحظة: مراجعة الفرع لسه مطلوبة.',size=22,step=3)
txt(s,440,619,752,31,'Manual number search → existing ticket found','بحث يدوي بالرقم ← الوصول للتذكرة الموجودة',size=20,color=C['accent'])
for k,en,ar,b,ba,n in [('genesys','The same call','نفس المكالمة','+20 ••• 410','+20 ••• 410',0),('icon-copy','Take the number','نقل الرقم','Move from the call to Desk','الانتقال من المكالمة إلى Desk',1),('icon-search','Search manually','البحث اليدوي','The phone number finds the record','الرقم يوصل لسجل العميل',2),('zoho','T101 found','ظهور T101','Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',3)]:mob(s,k,en,ar,b,ba,n)

s=slide('Same call. Customer context, already in view.','نفس المكالمة. ومعلومات العميل ظاهرة قدامك.','Proposed workflow','طريقة العمل المقترحة',6)
workspace(s,animated=True)
s['motion']['labels']=[B('Call arrives','وصول المكالمة'),B('Caller number','رقم المتصل'),B('Authorized lookup','بحث بالصلاحيات'),B('Associated records','السجلات المرتبطة'),B('Previous ticket','التذكرة السابقة'),B('Latest source note','آخر ملاحظة مسجلة')]
for k,en,ar,b,ba,n in [('genesys','Call arrives','وصول المكالمة','The employee keeps the call in view','المكالمة تفضل ظاهرة للموظف',0),('icon-link','Authorized lookup','بحث بصلاحيات الموظف','Associate the number with permitted records','ربط الرقم بالسجلات المسموح بها؛ ليس إثباتًا للهوية',2),('zoho','Ticket history appears','تاريخ التذاكر يظهر','Contact A · T101 exchange follow-up','العميل A · T101 متابعة استبدال',4),('icon-file','Latest note is visible','آخر ملاحظة ظاهرة','Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',5)]:mob(s,k,en,ar,b,ba,n)
s['notes'].append(B('The displayed successful association is illustrative. Shared numbers, multiple matches, no number/no match, permissions and unavailable lookup require explicit employee choice or manual fallback while the call continues. Do not promise automatic best-ticket selection without validating selection rules.','المطابقة المعروضة مثال ناجح فقط. الأرقام المشتركة وتعدد السجلات وغياب الرقم أو النتيجة والصلاحيات وتعطل البحث تحتاج اختيار الموظف أو البحث اليدوي مع استمرار المكالمة. لا نفترض اختيار أفضل تذكرة تلقائيًا قبل التحقق من قواعد الاختيار.'))

s=slide('Continue from the latest update.','نكمل الحديث من آخر تحديث.','One fictional exchange follow-up','مثال خيالي لمتابعة استبدال',3)
# Enlarged ticket scene, no abstract architecture or additional actions.
shell(s,48,184,1184,344)
img(s,'genesys',72,205,139,32,0);state(s,72,258,256,'Call in progress','مكالمة جارية',0)
circ(s,72,315,70,fill=C['sage'],step=0);icon(s,'call',91,334,32,0)
txt(s,160,320,215,40,'Contact A','العميل A',size=26,bold=True,step=0)
txt(s,72,420,285,40,'+20 ••• 410',size=27,ltr=True,step=0)
line(s,384,208,384,504)
img(s,'zoho',416,207,76,28);txt(s,512,207,673,39,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=26,bold=True)
state(s,416,268,700,'Waiting on the branch','بانتظار الفرع',1,True)
rect(s,416,328,784,167,fill=C['warm'],line=C['warm'],radius=8,step=1)
icon(s,'file',440,348,27,1);txt(s,481,347,682,35,'Latest recorded note','آخر ملاحظة مسجلة',size=22,color=C['accent'],step=1)
txt(s,440,402,736,59,'Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',size=34,bold=True,step=1)
# Speech cue illustrates employee comprehension, not generated output.
avatar(s,64,564,61,2)
icon(s,'speech',139,566,39,2)
txt(s,194,555,1005,42,'“I can see your exchange request is awaiting branch review.”','«ظاهر عندي إن طلب الاستبدال بانتظار مراجعة الفرع.»',size=27,bold=True,step=2)
txt(s,194,605,1005,30,'Illustrative employee response after caller verification','مثال لرد الموظف بعد التحقق من المتصل',size=19,color=C['muted'],step=2)
mob(s,'genesys','Contact A calls again','العميل A بيتصل تاني','A question about an earlier exchange request','متابعة طلب استبدال سابق')
mob(s,'zoho','T101 · Waiting on the branch','T101 · بانتظار الفرع','Latest note: Branch review is still pending.','آخر ملاحظة: مراجعة الفرع لسه مطلوبة.',1)
mob(s,'icon-actor','Continue from that note','نكمل من الملاحظة','An informed employee response, without changing the ticket','رد الموظف مبني على المعلومات، بدون تعديل التذكرة',2)

s=slide('One call. Two employee experiences.','مكالمة واحدة. وتجربتين مختلفتين للموظف.','Current → proposed','الحالي ← المقترح',2)
# Matched frame sizes but different visual grouping. Keep essential text large.
for right,x in [(False,48),(True,672)]:
 txt(s,x,175,560,42,'Proposed' if right else 'Current','المقترح' if right else 'الحالي',size=26,bold=True,color=C['green'] if right else C['muted'])
 shell(s,x,235,560,366)
 img(s,'genesys',x+22,256,125,30)
 circ(s,x+22,317,57,fill=C['sage']);icon(s,'call',x+37,y=332,d=27)
 txt(s,x+95,319,420,36,'+20 ••• 410',size=25,bold=True,ltr=True)
 if right:
  line(s,x+22,385,x+538,385)
  img(s,'zoho',x+22,405,70,26,1)
  txt(s,x+109,403,428,38,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=22,bold=True,step=1)
  rect(s,x+22,460,516,113,fill=C['warm'],line=C['warm'],radius=8,step=1)
  icon(s,'file',x+39,478,24,1)
  txt(s,x+79,475,411,33,'Latest note','آخر ملاحظة',size=20,color=C['accent'],step=1)
  txt(s,x+39,520,468,37,'Branch review still pending.','بانتظار مراجعة الفرع.',size=25,bold=True,step=1)
 else:
  # Offset secondary window deliberately interrupts the call workspace.
  shell(s,x+80,382,460,201,1)
  img(s,'zoho',x+99,399,66,25,1)
  rect(s,x+100,441,422,54,line=C['gold'],radius=6,step=1)
  icon(s,'search',x+112,455,25,1);txt(s,x+153,450,317,36,'+20 ••• 410',size=25,ltr=True,step=1)
  icon(s,'pointer',x+465,471,37,1)
  txt(s,x+102,520,407,38,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=22,bold=True,step=1)
 txt(s,x+4,622,552,31,'Context beside the call' if right else 'Switch window · search number','المعلومات جنب المكالمة' if right else 'تبديل الشاشة · البحث بالرقم',size=21,color=C['green'] if right else C['muted'])
mob(s,'icon-search','Current: find it manually','الحالي: بحث يدوي','Call → switch to Desk → search → ticket','مكالمة ← الانتقال لـDesk ← البحث ← التذكرة')
mob(s,'icon-call','Proposed: see it together','المقترح: ظاهرين مع بعض','Call + relevant ticket + latest note in one view','المكالمة والتذكرة وآخر ملاحظة في شاشة واحدة',1)

s=slide('Less searching. More attention to the customer.','بحث أقل. وتركيز أكبر مع العميل.','Expected benefits · To validate in a pilot','فوائد متوقعة · نختبرها في تجربة أولية',3)
# One enlarged UI crop; annotations land on exact features instead of benefit cards.
shell(s,48,184,876,438)
img(s,'genesys',72,202,139,31);icon(s,'call',242,206,25)
txt(s,285,202,380,40,'+20 ••• 410',size=27,bold=True,ltr=True)
state(s,688,207,212,'In progress','جارية')
line(s,48,264,924,264)
avatar(s,72,290,48,0);txt(s,140,289,500,42,'Contact A','العميل A',size=28,bold=True,step=0)
txt(s,140,335,686,32,'Associated record · Existing Desk history','سجل مرتبط · تاريخ التذاكر الموجود',size=21,color=C['muted'],step=0)
img(s,'zoho',791,298,83,30,0)
line(s,72,390,900,390)
icon(s,'case',72,414,27,1);txt(s,113,409,737,40,'T101 · Exchange follow-up','T101 · متابعة استبدال',size=26,bold=True,step=1)
state(s,72,460,725,'Waiting on the branch','بانتظار الفرع',1,True)
rect(s,72,515,828,83,fill=C['warm'],line=C['warm'],radius=8,step=2)
icon(s,'file',92,541,29,2);txt(s,137,536,738,45,'Branch review is still pending.','مراجعة الفرع لسه مطلوبة.',size=29,bold=True,step=2)
for n,(yy,target,en,ar) in enumerate([(299,319,'Less manual\nsearching','بحث يدوي\nأقل'),(418,433,'Previous follow-ups\nin view','المتابعات السابقة\nظاهرة'),(535,556,'More informed\nconversations','محادثات بمعلومات\nأوضح')]):
 line(s,930,target,954,target,color=C['accent'],width=2,step=n)
 circ(s,921,target-4,8,fill=C['accent'],step=n)
 txt(s,976,yy,246,79,en,ar,size=24,bold=True,step=n)
txt(s,48,632,1184,28,'Pilot expectations, not measured results.','توقعات نختبرها في التجربة، وليست نتائج مقاسة.',size=18,color=C['muted'])
mob(s,'icon-search','Less manual searching','بحث يدوي أقل','The call and associated record share a view','المكالمة والسجل المرتبط في نفس الشاشة')
mob(s,'icon-case','Visible previous follow-ups','المتابعات السابقة ظاهرة','Existing ticket history is easier to consult','تاريخ التذاكر الموجود أقرب للموظف',1)
mob(s,'icon-file','More informed conversations','محادثات بمعلومات أوضح','Expected benefits to validate during a pilot','فوائد متوقعة تحتاج اختبارًا في التجربة الأولية',2)

s=slide('Start with what is already contracted.','نبدأ بالموجود في العقد.','A practical first step','خطوة أولى عملية',3)
# Contract/document form on left and small meaningful test workspace on right.
shell(s,48,191,356,390)
icon(s,'file',76,217,38)
txt(s,130,219,246,36,'2023 contract','عقد ٢٠٢٣',size=24,bold=True)
for yy,ww in [(288,276),(305,246),(322,265)]:rect(s,76,yy,ww,4,fill=C['line'],line=C['line'],radius=0)
rect(s,68,353,316,128,fill=C['warm'],line=C['warm'],radius=8)
txt(s,88,371,272,86,'“CRM URL pop up\nintegration”',size=27,bold=True,ltr=True)
txt(s,76,517,304,34,'November 2023 · p. 4','نوفمبر ٢٠٢٣ · ص. ٤',size=20,color=C['muted'])
# Sequence is subordinate to a real starting document and target test call.
line(s,422,362,478,362,color=C['accent'],width=2,step=0,arrow=True)
icon(s,'settings',518,240,48,0)
txt(s,488,310,290,86,'Inspect the\nexisting pop-up','نفحص إعدادات\nالـpop-up الموجود',size=27,bold=True,step=0)
txt(s,488,418,290,90,'Choose the smallest\nsupported improvement','نختار أبسط تحسين\nتدعمه الأنظمة',size=22,color=C['muted'],step=1)
line(s,775,362,826,362,color=C['accent'],width=2,step=2,arrow=True)
shell(s,850,235,382,287,2)
icon(s,'call',873,256,27,2);txt(s,916,253,285,38,'Test call','مكالمة اختبار',size=25,bold=True,step=2)
line(s,850,308,1232,308,step=2)
img(s,'zoho',873,331,70,25,2);txt(s,966,328,231,37,'T101',size=25,bold=True,ltr=True,step=2)
rect(s,872,387,338,100,fill=C['warm'],line=C['warm'],radius=8,step=2)
icon(s,'file',891,406,25,2);txt(s,935,405,251,65,'Latest note\nin view','آخر ملاحظة\nظاهرة',size=24,bold=True,step=2)
txt(s,488,589,724,43,'Next: review the setup + authorized test calls','التالي: مراجعة الإعدادات ومكالمات اختبار مصرح بها',size=24,bold=True,step=2)
for k,en,ar,b,ba,n in [('icon-file','Inspect the contracted pop-up','نفحص الـpop-up المتعاقد عليه','2023 contract, page 4: CRM URL pop up integration','عقد ٢٠٢٣، صفحة ٤: CRM URL pop up integration',0),('icon-settings','Smallest supported improvement','أبسط تحسين تدعمه الأنظمة','Configuration first; add infrastructure only if needed','نفحص الإعدادات أولًا، ونضيف ربطًا إذا احتجنا',1),('icon-call','Authorized test calls','مكالمات اختبار مصرح بها','Verify association, permissions and manual fallback','نختبر المطابقة والصلاحيات والرجوع للبحث اليدوي',2)]:mob(s,k,en,ar,b,ba,n)
s['notes'].append(B('The 29 November 2023 contract, PDF page 4, says “CRM URL pop up integration.” Contract scope is not evidence of current installation or reliable behavior. First inspect the actual Genesys edition/desktop, URL configuration, Desk access, number format and supported lookup routes. Validate a suitable minimal change and authorized test calls, including unavailable lookup and multiple matches. No assumption that Zoho CRM is active. The core proposal needs no generative AI.','عقد ٢٩ نوفمبر ٢٠٢٣، صفحة PDF رقم ٤، ينص على “CRM URL pop up integration”. وجود البند لا يثبت التنفيذ أو كفاءة التشغيل الحالية. نراجع نسخة Genesys والواجهة وإعدادات الرابط وصلاحيات Desk وتنسيق الأرقام ومسارات البحث المدعومة، ثم نختبر أقل تغيير مناسب بمكالمات مصرح بها، بما فيها تعطل البحث وتعدد النتائج. لا نفترض تشغيل Zoho CRM. المقترح الأساسي لا يحتاج AI توليدي.'))

assert len(slides)==7
for s in slides:
 for e in s['elements']:
  if e['type']=='rect':assert min(int(e['fill'][i:i+2],16) for i in (1,3,5))>=220
  if e['type']=='text':assert e['size']<=42
story=dict(title=B('GRINDCTRL × Concrete · The call and its context','GRINDCTRL × كونكريت · المكالمة ومعلوماتها'),colors=C,slides=slides,sources=basis['sources'],fixtures=basis['fixtures'])
(ROOT/'story.json').write_text(json.dumps(story,ensure_ascii=False,indent=2))
print('Seven distinct light scenes. One consistent fictional call and ticket. Storyboard and research direction documented first; source access limits are recorded.')
