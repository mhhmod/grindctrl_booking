const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'/workspace/grindctrl_booking/apps/web-next/node_modules/playwright');
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{
 const page=await browser.newPage({viewport:{width:1440,height:1100}}),errors=[],requests=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url());});
 await page.setContent(fs.readFileSync(path.join(__dirname,'index.html'),'utf8'));await page.evaluate(()=>document.fonts.ready);
 await page.evaluate(()=>{go(2);pause();setMotion(800);});
 const op=step=>page.locator(`.scene:not([hidden]) .canvas .phase[data-step="${step}"]`).first().evaluate(x=>Number(x.style.opacity));
 assert.equal(await op(0),1);assert.equal(await op(2),0);assert.equal(await op(4),0);
 await page.evaluate(()=>setMotion(3400));assert.equal(await op(2),1);assert.equal(await op(4),0);assert.match(await page.locator('#event-count').innerText(),/Authorized lookup/);
 await page.evaluate(()=>setMotion(7900));assert.equal(await op(4),1);
 await page.locator('[data-action=replay]').click();await page.evaluate(()=>pause());assert.equal(await op(4),0);
 await page.locator('[data-action=step]').click();assert.equal(await op(0),1);assert.equal(await op(1),0);await page.locator('[data-action=step]').click();assert.equal(await op(1),1);assert.equal(await op(4),0);
 await page.locator('[data-action=all]').click();assert.equal(await op(4),1);assert.equal(await page.evaluate(()=>playing),false);
 await page.locator('[data-action=play]').click();await page.waitForTimeout(160);await page.locator('[data-action=play]').click();
 const stopped=await page.evaluate(()=>millis);await page.waitForTimeout(160);assert.equal(await page.evaluate(()=>millis),stopped);
 const over=[];
 for(const lang of ['en','ar']){
  await page.evaluate(l=>{setLocale(l);showAll();},lang);await page.evaluate(()=>document.fonts.ready);
  for(const width of [320,390,768,1024,1366,1440]){
   await page.setViewportSize({width,height:1100});
   for(let i=0;i<7;i++){
    await page.evaluate(i=>{go(i);showAll();},i);
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,`${lang} ${width} ${i} horizontal overflow`);
    if(width===1440){const clipped=await page.locator('.scene:not([hidden]) .text').evaluateAll(nodes=>nodes.filter(n=>n.scrollHeight>n.clientHeight+2||n.scrollWidth>n.clientWidth+2).map(n=>({text:n.textContent,h:n.clientHeight,actual:n.scrollHeight})));if(clipped.length)over.push({lang,i,clipped});}
   }
  }
  await page.setViewportSize({width:1440,height:1100});
  for(let i=0;i<7;i++){await page.evaluate(i=>{go(i);showAll();},i);await page.locator('.scene:not([hidden]) .canvas').screenshot({path:path.join(__dirname,`slide-${i+1}-${lang}.png`)});
   if(lang==='en'){await page.addStyleTag({content:'.canvas foreignObject{visibility:hidden!important}'}).then(async tag=>{await page.locator('.scene:not([hidden]) .canvas').screenshot({path:path.join(__dirname,`no-text-${i+1}.png`)});await tag.evaluate(x=>x.remove());});await page.addStyleTag({content:'.canvas{filter:blur(5px)}'}).then(async tag=>{await page.locator('.scene:not([hidden]) .canvas').screenshot({path:path.join(__dirname,`squint-${i+1}.png`)});await tag.evaluate(x=>x.remove());});}}
  await page.evaluate(()=>{document.querySelectorAll('.phase').forEach(x=>{x.style.opacity=1;x.style.transform='none';});document.querySelectorAll('line[data-x2]').forEach(x=>{x.setAttribute('x2',x.dataset.x2);x.setAttribute('y2',x.dataset.y2);});});
  await page.emulateMedia({media:'print'});assert.equal(await page.locator('.canvas:visible').count(),7);
  await page.pdf({path:path.join(__dirname,'..',`grindctrl-visual-first-proposal-${lang}.pdf`),preferCSSPageSize:true,printBackground:true});await page.emulateMedia({media:'screen'});
 }
 if(over.length){fs.writeFileSync(path.join(__dirname,'overflow.json'),JSON.stringify(over,null,2));assert.fail(JSON.stringify(over));}
 await page.setViewportSize({width:390,height:844});await page.evaluate(()=>{setLocale('ar');go(0);showAll();});await page.screenshot({path:path.join(__dirname,'mobile-ar.png'),fullPage:true});
 await page.locator('[data-action=notes]').click();assert.match(await page.locator('dialog').innerText(),/CRM URL pop up integration/);await page.keyboard.press('Escape');
 await page.keyboard.press('ArrowLeft');assert.equal(await page.evaluate(()=>current),1);
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 const markerMatch=await page.locator('line[marker-end]').evaluateAll(ns=>ns.every(n=>{const id=n.getAttribute('marker-end').slice(5,-1);return document.getElementById(id)?.querySelector('path')?.getAttribute('fill')===n.getAttribute('stroke')}));assert.equal(markerMatch,true,'Arrowheads match their connectors');
 const reducedPage=await browser.newPage({viewport:{width:390,height:844},reducedMotion:'reduce'});await reducedPage.setContent(fs.readFileSync(path.join(__dirname,'index.html'),'utf8'));await reducedPage.evaluate(()=>document.fonts.ready);assert.equal(await reducedPage.evaluate(()=>playing),false);assert.equal(await reducedPage.evaluate(()=>millis),await reducedPage.evaluate(()=>duration()));
 console.log('PASS: causal sequence; replay; pause; event stepping; show-all; reduced motion; 7 visual-first EN/AR slides at 6 widths; no text clipping; notes; offline; EN/AR PDF export.');
 }finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
