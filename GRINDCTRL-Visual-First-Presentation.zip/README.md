# GRINDCTRL × Concrete: the call and its context

Seven newly composed product scenes explain a proposed Genesys + Zoho Desk improvement: employee ticket context appears beside the call instead of requiring a separate manual phone-number search.

## Files

- **English / Arabic PPTX**: editable text, shapes and source notes; timed native fades. Start Slide Show to play.
- **English / Arabic PDF**: seven complete static pages in each language.
- **English / Arabic MP4**: silent, seven-scene product walkthrough.
- **Bilingual HTML**: download and open in a browser; works offline. Pause, replay, next event, show all, language switching and reduced-motion support. The HTML file is not a hosted application or live integration.
- **Source and review**: research/access report, storyboard written before generation, design review, generators, shared scene data, font licenses and visual-review evidence.

## What changed

One large employee workspace is the opening scene. The same masked number and ticket persist through current and proposed experiences. The manual scenario uses a separate search window and pointer; the proposed scenario reveals the record within the call workspace. A ticket close-up makes the fictional exchange follow-up tangible. The comparison shows the structural difference, and expected benefits point directly to interface improvements. The final scene starts with the existing contracted URL pop-up.

All slides are light, using the GRINDCTRL cream/charcoal direction with a restrained warm accent. English uses Manrope; Arabic uses IBM Plex Sans Arabic. Main headings are 31.5 pt; important UI is generally 18–21 pt, with larger type for the focused source note. Native content remains editable.

## Grounding

This is a proposed first collaboration. GRINDCTRL has not implemented Concrete's existing systems and has no current Concrete/Centro relationship. The user reports manual phone-number lookup works but history is not automatically visible with calls. This has not been independently tested.

The November 2023 contract, PDF page 4, includes “CRM URL pop up integration.” Inspect that configuration before deciding whether additional integration infrastructure is needed. The proposal does not assume active Zoho CRM or require generative AI.

All records and conversation examples are fictional. A phone-number association is not verified identity. Authorized employee access and caller verification still apply. Shared numbers, multiple/no matches and lookup failure require validated handling and manual fallback. No refund decision, ticket update, live backend, model, cost saving or measured time improvement is demonstrated.

## Research honesty

The 12 requested URLs were blocked by the environment network. They were not read. Accessible primary alternatives were read from W3C COGA, IBM Carbon and Microsoft Fluent's source repositories; Chatwoot's own light UI screenshot was visually inspected. Detailed source links, actual access outcomes, applied decisions and gaps (including the unavailable Cambridge/Mayer primary chapter) are in `RESEARCH-AND-DIRECTION.md`. Research coverage is partial, not a complete literature or vendor review.

## Review and limitations

The actual scenes were reviewed full-size, at thumbnail size, with text hidden and blurred. These are internal design heuristics, not external participant testing. See `DESIGN-REVIEW.md`.

Browser functionality, two languages at six widths, static PDF output and native LibreOffice rendering were checked. Native animation effects survived a LibreOffice round trip. Microsoft PowerPoint, Google Slides and Keynote playback were not directly tested; no Morph support is claimed. Use HTML or MP4 for the directly rendered motion experience.

## Rebuild

From the `source/` folder:

```bash
python story.py
python prepare-fonts.py
python build-pptx.py
python build-preview.py
node verify-export.cjs
node record-motion.cjs
```

Python dependencies: python-pptx, Pillow, lxml, fontTools, brotli, PyMuPDF. Node requires Playwright (set `PLAYWRIGHT_MODULE` if outside the existing workspace); Chromium at `/usr/bin/chromium`, FFmpeg and LibreOffice for native checks. Editable TTF font files and their licenses are included. Generated outputs go in the parent directory. Source icons are provided; `make-icons.cjs` rebuilds the six additional interface icons.

## العربية

عرض جديد من ٧ مشاهد يوضح التغيير من البحث اليدوي إلى ظهور معلومات التذاكر بجوار المكالمة. ملفات إنجليزي وعربي، ونسخة HTML ثنائية اللغة وفيديوهات. السجلات خيالية والربط مقترح، وليس تنفيذًا قائمًا. لا توجد نتائج أداء مقاسة. ابدأ بفحص الـpop-up الموجود في العقد ثم اختبار تجربة الموظف بصلاحيات مناسبة.
